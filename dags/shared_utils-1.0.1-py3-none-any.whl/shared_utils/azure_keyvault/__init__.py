"""
Azure Key Vault utilities for AIML platform modules.

Provides standardized access to Azure Key Vault for secret management
with authentication, caching, and error handling.
"""

from .client import KeyVaultClient
from .exceptions import AuthenticationError, KeyVaultError, SecretNotFoundError

__all__ = ["AuthenticationError", "KeyVaultClient", "KeyVaultError", "SecretNotFoundError"]
