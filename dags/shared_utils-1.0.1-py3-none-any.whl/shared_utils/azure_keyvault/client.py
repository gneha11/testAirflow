"""
Azure Key Vault client for AIML platform.

Provides a standardized interface for accessing Azure Key Vault secrets
with authentication, caching, retry logic, and comprehensive error handling.
"""

import os
import time
from datetime import datetime
from typing import Any, List, Optional

from azure.core.exceptions import ClientAuthenticationError, HttpResponseError, ResourceNotFoundError
from azure.identity import AzureCliCredential, ClientSecretCredential, DefaultAzureCredential, ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient

from ..logger import get_logger
from .exceptions import (
    AuthenticationError,
    KeyVaultError,
    PermissionDeniedError,
    SecretNotFoundError,
    SecretVersionError,
    VaultNotFoundError,
)


class KeyVaultClient:
    """
    Azure Key Vault client with caching and error handling.

    Features:
    - Multiple authentication methods
    - Secret caching with TTL
    - Retry logic for transient failures
    - Comprehensive error handling
    - Performance monitoring
    """

    def __init__(
        self,
        vault_url: str,
        credential: Optional[Any] = None,
        cache_ttl_seconds: int = 300,  # 5 minutes
        max_retries: int = 3,
        retry_delay: float = 1.0,
    ):
        """
        Initialize Key Vault client.

        Args:
            vault_url: Azure Key Vault URL (e.g., https://myvault.vault.azure.net/)
            credential: Azure credential object (optional, uses DefaultAzureCredential if None)
            cache_ttl_seconds: Cache TTL in seconds
            max_retries: Maximum number of retries for failed requests
            retry_delay: Delay between retries in seconds
        """
        self.vault_url = vault_url.rstrip("/")
        self.cache_ttl_seconds = cache_ttl_seconds
        self.max_retries = max_retries
        self.retry_delay = retry_delay

        # Initialize logger
        self.logger = get_logger(__name__)

        # Secret cache
        self._cache: dict[str, dict[str, Any]] = {}

        # Initialize credential
        if credential is None:
            credential = self._get_default_credential()

        try:
            self.client = SecretClient(vault_url=vault_url, credential=credential)
            self.logger.info(f"Initialized Key Vault client for {vault_url}")
        except Exception as e:
            self.logger.error(f"Failed to initialize Key Vault client: {e!s}")
            raise AuthenticationError(f"Failed to initialize Key Vault client: {e!s}")

    def _get_default_credential(self):
        """Get default Azure credential with fallback chain."""
        # Try different credential types in order of preference
        credentials_to_try = []

        # 1. Client Secret Credential (for service principals)
        if all(os.getenv(var) for var in ["AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET", "AZURE_TENANT_ID"]):
            credentials_to_try.append(
                ClientSecretCredential(
                    tenant_id=os.getenv("AZURE_TENANT_ID"),
                    client_id=os.getenv("AZURE_CLIENT_ID"),
                    client_secret=os.getenv("AZURE_CLIENT_SECRET"),
                )
            )

        # 2. Managed Identity (for Azure resources)
        if os.getenv("AZURE_CLIENT_ID"):
            credentials_to_try.append(ManagedIdentityCredential(client_id=os.getenv("AZURE_CLIENT_ID")))
        else:
            credentials_to_try.append(ManagedIdentityCredential())

        # 3. Azure CLI (for development)
        credentials_to_try.append(AzureCliCredential())

        # 4. Default credential chain
        credentials_to_try.append(DefaultAzureCredential())

        return DefaultAzureCredential()

    def _is_cache_valid(self, cache_entry: dict[str, Any]) -> bool:
        """Check if cache entry is still valid."""
        if not cache_entry:
            return False

        cached_time = cache_entry.get("cached_at")
        if not cached_time:
            return False

        return (datetime.now() - cached_time).total_seconds() < self.cache_ttl_seconds

    def _cache_secret(self, secret_name: str, value: str, version: str = None):
        """Cache secret value."""
        cache_key = f"{secret_name}:{version}" if version else secret_name
        self._cache[cache_key] = {"value": value, "version": version, "cached_at": datetime.now()}

    def _get_cached_secret(self, secret_name: str, version: str = None) -> Optional[str]:
        """Get secret from cache if valid."""
        cache_key = f"{secret_name}:{version}" if version else secret_name
        cache_entry = self._cache.get(cache_key)

        if self._is_cache_valid(cache_entry):
            self.logger.debug(f"Retrieved secret '{secret_name}' from cache")
            return cache_entry["value"]

        # Remove expired cache entry
        if cache_key in self._cache:
            del self._cache[cache_key]

        return None

    def _execute_with_retry(self, operation, *args, **kwargs):
        """Execute operation with retry logic."""
        last_exception = None

        for attempt in range(self.max_retries + 1):
            try:
                return operation(*args, **kwargs)
            except (HttpResponseError, ClientAuthenticationError) as e:
                last_exception = e

                if attempt < self.max_retries:
                    self.logger.warning(f"Attempt {attempt + 1} failed, retrying in {self.retry_delay}s: {e!s}")
                    time.sleep(self.retry_delay * (2**attempt))  # Exponential backoff
                else:
                    break
            except ResourceNotFoundError:
                # Don't retry for not found errors
                raise
            except Exception as e:
                # Don't retry for unexpected errors
                self.logger.error(f"Unexpected error in Key Vault operation: {e!s}")
                raise KeyVaultError(f"Unexpected error: {e!s}")

        # All retries failed
        if isinstance(last_exception, ClientAuthenticationError):
            raise AuthenticationError(f"Authentication failed: {last_exception!s}")
        elif isinstance(last_exception, HttpResponseError):
            if last_exception.status_code == 403:
                raise PermissionDeniedError("Unknown", "access")
            elif last_exception.status_code == 404:
                raise VaultNotFoundError(self.vault_url)
            else:
                raise KeyVaultError(f"HTTP error {last_exception.status_code}: {last_exception!s}")
        else:
            raise KeyVaultError(f"Operation failed after {self.max_retries} retries: {last_exception!s}")

    def get_secret(self, secret_name: str, version: str = None) -> str:
        """
        Get secret value from Key Vault.

        Args:
            secret_name: Name of the secret
            version: Specific version of the secret (optional)

        Returns:
            Secret value as string

        Raises:
            SecretNotFoundError: If secret is not found
            AuthenticationError: If authentication fails
            PermissionDeniedError: If access is denied
            KeyVaultError: For other errors
        """
        start_time = time.time()

        try:
            # Check cache first
            cached_value = self._get_cached_secret(secret_name, version)
            if cached_value is not None:
                return cached_value

            # Retrieve from Key Vault
            def _get_secret():
                if version:
                    return self.client.get_secret(secret_name, version)
                else:
                    return self.client.get_secret(secret_name)

            secret = self._execute_with_retry(_get_secret)

            # Cache the secret
            self._cache_secret(secret_name, secret.value, secret.properties.version)

            self.logger.info(f"Retrieved secret '{secret_name}' from Key Vault")
            return secret.value

        except ResourceNotFoundError:
            if version:
                raise SecretVersionError(secret_name, version)
            else:
                raise SecretNotFoundError(secret_name, self.vault_url)
        except (AuthenticationError, PermissionDeniedError, KeyVaultError):
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error retrieving secret '{secret_name}': {e!s}")
            raise KeyVaultError(f"Failed to retrieve secret: {e!s}")
        finally:
            duration = time.time() - start_time
            self.logger.performance("get_secret", duration, secret_name=secret_name)

    def get_secrets(self, secret_names: List[str]) -> dict[str, str]:
        """
        Get multiple secrets from Key Vault.

        Args:
            secret_names: List of secret names

        Returns:
            Dictionary mapping secret names to values
        """
        results = {}
        errors = {}

        for secret_name in secret_names:
            try:
                results[secret_name] = self.get_secret(secret_name)
            except Exception as e:
                errors[secret_name] = str(e)
                self.logger.error(f"Failed to retrieve secret '{secret_name}': {e!s}")

        if errors:
            self.logger.warning(f"Failed to retrieve {len(errors)} out of {len(secret_names)} secrets")

        return results

    def list_secrets(self) -> List[str]:
        """
        List all secret names in the Key Vault.

        Returns:
            List of secret names
        """
        try:

            def _list_secrets():
                return list(self.client.list_properties_of_secrets())

            secret_properties = self._execute_with_retry(_list_secrets)
            secret_names = [prop.name for prop in secret_properties]

            self.logger.info(f"Listed {len(secret_names)} secrets from Key Vault")
            return secret_names

        except Exception as e:
            self.logger.error(f"Failed to list secrets: {e!s}")
            raise KeyVaultError(f"Failed to list secrets: {e!s}")

    def secret_exists(self, secret_name: str) -> bool:
        """
        Check if a secret exists in Key Vault.

        Args:
            secret_name: Name of the secret

        Returns:
            True if secret exists, False otherwise
        """
        try:
            self.get_secret(secret_name)
            return True
        except SecretNotFoundError:
            return False

    def clear_cache(self, secret_name: str = None):
        """
        Clear secret cache.

        Args:
            secret_name: Specific secret to clear from cache (optional, clears all if None)
        """
        if secret_name:
            # Clear specific secret from cache
            keys_to_remove = [
                key for key in self._cache.keys() if key.startswith(f"{secret_name}:") or key == secret_name
            ]
            for key in keys_to_remove:
                del self._cache[key]
            self.logger.debug(f"Cleared cache for secret '{secret_name}'")
        else:
            # Clear entire cache
            self._cache.clear()
            self.logger.debug("Cleared entire secret cache")

    def get_cache_stats(self) -> dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Dictionary with cache statistics
        """
        total_entries = len(self._cache)
        valid_entries = sum(1 for entry in self._cache.values() if self._is_cache_valid(entry))

        return {
            "total_entries": total_entries,
            "valid_entries": valid_entries,
            "expired_entries": total_entries - valid_entries,
            "cache_ttl_seconds": self.cache_ttl_seconds,
        }
