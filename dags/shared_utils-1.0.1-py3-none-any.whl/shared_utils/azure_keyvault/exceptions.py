"""
Custom exceptions for Azure Key Vault operations.

Provides specific exception types for different Key Vault error scenarios
to enable proper error handling in client applications.
"""


class KeyVaultError(Exception):
    """Base exception for Key Vault operations."""

    def __init__(self, message: str, error_code: str = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code


class SecretNotFoundError(KeyVaultError):
    """Exception raised when a secret is not found in Key Vault."""

    def __init__(self, secret_name: str, vault_url: str = None):
        message = f"Secret '{secret_name}' not found"
        if vault_url:
            message += f" in vault '{vault_url}'"
        super().__init__(message, "SECRET_NOT_FOUND")
        self.secret_name = secret_name
        self.vault_url = vault_url


class AuthenticationError(KeyVaultError):
    """Exception raised when authentication to Key Vault fails."""

    def __init__(self, message: str = "Failed to authenticate with Azure Key Vault"):
        super().__init__(message, "AUTHENTICATION_FAILED")


class PermissionDeniedError(KeyVaultError):
    """Exception raised when access to a secret is denied."""

    def __init__(self, secret_name: str, operation: str = "read"):
        message = f"Permission denied to {operation} secret '{secret_name}'"
        super().__init__(message, "PERMISSION_DENIED")
        self.secret_name = secret_name
        self.operation = operation


class VaultNotFoundError(KeyVaultError):
    """Exception raised when Key Vault is not found."""

    def __init__(self, vault_url: str):
        message = f"Key Vault not found: '{vault_url}'"
        super().__init__(message, "VAULT_NOT_FOUND")
        self.vault_url = vault_url


class SecretVersionError(KeyVaultError):
    """Exception raised when a specific secret version is not found."""

    def __init__(self, secret_name: str, version: str):
        message = f"Version '{version}' of secret '{secret_name}' not found"
        super().__init__(message, "SECRET_VERSION_NOT_FOUND")
        self.secret_name = secret_name
        self.version = version
