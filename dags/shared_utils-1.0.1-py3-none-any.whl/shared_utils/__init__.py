"""
Shared utilities for AIML platform modules.

This package provides comprehensive utilities for logging, configuration management,
database operations, Azure integration, and common helper functions.

Key Components:
- Logging: Structured logging with multiple formats and contexts
- Configuration: Multi-source configuration with validation
- Database: SQLAlchemy integration with repository pattern
- Azure: Key Vault integration for secret management
- Database Logging: Comprehensive batch job tracking (NEW!)
- Utils: Decorators, validators, and helper functions
- Data Foundation Logging: Microsoft Fabric specific logging with Lakehouse integration (NEW!)

Quick Start:
    from shared_utils import get_logger, ConfigManager, DatabaseManager
    from shared_utils.database_logging import DatabaseLogger, log_batch_job
    from shared_utils import df_get_logger, df_save_log_to_lakehouse  # Data Foundation logging
"""

__version__ = "1.0.1"

# Core imports
from .azure_keyvault import KeyVaultClient
from .config import (
    ConfigManager,
    # Data Foundation specific configuration functions and class
    DFConfigLoader,
    df_load_config,
)
from .database import (
    BaseModel,
    BaseRepository,
    DatabaseManager,
    # Data Foundation specific database functions and class
    DFDatabaseManager,
    df_get_postgres_connection,
    df_get_cosmos_container,
    df_get_mongodb_collection,
)

# Database logging imports
from .database_logging import (
    BatchStatus,
    DatabaseLogger,
    EventDetails,
    EventDetailsRepository,
    EventMaster,
    EventMasterRepository,
    EventStatus,
    EventType,
    log_batch_job,
    log_database_operation,
    log_external_api_call,
    log_processing_step,
    log_record_processing,
    # Data Foundation specific pipeline tracking functions and class
    DFPipelineManager,
    df_get_execution_time_window,
    df_track_pipeline_execution,
    df_update_pipeline_failed_status,
    df_update_pipeline_completed_status,
    # Data Foundation specific utility functions (NEW!)
    df_capture_schema,
    df_load_execution_details,
    df_compare_schemas,
)
from .logger import (
    LogLevel, 
    configure_logging, 
    get_logger,
    # Data Foundation specific logging functions
    DFLogger,
    df_get_logger,
    df_save_log_to_lakehouse,
    df_create_log_session_id,
)

# Utility imports
from .utils import (
    ensure_directory,
    generate_uuid,
    get_utc_now,
    rate_limit,
    retry,
    safe_file_write,
    timeout,
    validate_email,
    # Data Foundation specific JSON exploder functions and class
    DFJSONExploder,
    df_flatten_json,
    df_save_with_schema_evolution,
    df_save_with_schema_evolution_deduplication,
)

__all__ = [
    # Logging
    "get_logger",
    "configure_logging",
    "LogLevel",
    # Data Foundation Logging (NEW!)
    "DFLogger",
    "df_get_logger",
    "df_save_log_to_lakehouse",
    "df_create_log_session_id",
    # Configuration
    "ConfigManager",
    # Data Foundation Configuration (NEW!)
    "DFConfigLoader",
    "df_load_config",
    # Azure Key Vault
    "KeyVaultClient",
    # Database
    "DatabaseManager",
    "BaseRepository",
    "BaseModel",
    # Data Foundation Database (NEW!)
    "DFDatabaseManager",
    "df_get_postgres_connection",
    "df_get_cosmos_container",
    "df_get_mongodb_collection",
    # Database Logging (NEW!)
    "DatabaseLogger",
    "EventMaster",
    "EventDetails",
    "EventMasterRepository",
    "EventDetailsRepository",
    "BatchStatus",
    "EventStatus",
    "EventType",
    "log_batch_job",
    "log_processing_step",
    "log_record_processing",
    "log_external_api_call",
    "log_database_operation",
    # Data Foundation Pipeline Tracking (NEW!)
    "DFPipelineManager",
    "df_get_execution_time_window",
    "df_track_pipeline_execution",
    "df_update_pipeline_failed_status",
    "df_update_pipeline_completed_status",
    "df_capture_schema",
    "df_load_execution_details",
    "df_compare_schemas",
    # Utils
    "generate_uuid",
    "validate_email",
    "retry",
    "timeout",
    "rate_limit",
    "get_utc_now",
    "ensure_directory",
    "safe_file_write",
    # Data Foundation JSON Exploder (NEW!)
    "DFJSONExploder",
    "df_flatten_json",
    "df_save_with_schema_evolution",
    "df_save_with_schema_evolution_deduplication",
]
