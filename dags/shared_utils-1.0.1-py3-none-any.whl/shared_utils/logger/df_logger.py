"""
Logger Module for Microsoft Fabric Data Foundation.

This module provides a reusable logger setup for notebooks and scripts running inside Microsoft Fabric.
It supports both console and file-based logging, with optional upload of log files to the Lakehouse
for centralized tracking and auditing.

All functions are prefixed with 'df_' to identify them as Data Foundation specific functions.
"""

import logging
import os
from datetime import datetime
from typing import Optional


class DFLogger:
    """
    Data Foundation Logger class for Microsoft Fabric integration.
    
    This class provides tenant-aware logging with Lakehouse integration capabilities.
    """
    
    def __init__(self):
        """Initialize the DFLogger with empty state."""
        self._shared_file_handler = None
        self._shared_log_file_path = None
        self._current_log_session_id = None
        self._last_saved_position = 0
        self._application_loggers = set()
    
    def reset_logger_globals(self) -> None:
        """Reset global variables to allow new log sessions."""
        self._shared_file_handler = None
        self._shared_log_file_path = None
        self._current_log_session_id = None
        self._application_loggers.clear()
    
    def get_logger(
        self,
        tenant_id: str,
        enterprise_id: str,
        log_session_id: str,
        name: str = __name__,
        level: int = logging.INFO,
        log_to_file: bool = False,
        local_log_dir: str = "/tmp/logs",
    ) -> logging.Logger:
        """
        Creates and returns a logger instance with optional console and shared file handlers.
        All loggers with the same log_session_id will write to the same file.
        
        Args:
            tenant_id: Tenant identifier (mandatory)
            enterprise_id: Enterprise identifier (mandatory)
            log_session_id: Log session identifier (mandatory)
            name: Logger name (default: module name)
            level: Logging level (default: INFO)
            log_to_file: Whether to log to file (default: False)
            local_log_dir: Local directory for log files (default: /tmp/logs)
            
        Returns:
            Configured logger instance
            
        Raises:
            ValueError: If mandatory parameters are missing
        """
        # Validate mandatory parameters
        if not tenant_id:
            raise ValueError("tenant_id is mandatory")
        if not enterprise_id:
            raise ValueError("enterprise_id is mandatory")
        if not log_session_id:
            raise ValueError("log_session_id is mandatory")

        # Reset globals if this is a new session
        if self._current_log_session_id != log_session_id:
            self.reset_logger_globals()
            self._current_log_session_id = log_session_id

        logger = logging.getLogger(name)
        logger.setLevel(level)

        formatter = logging.Formatter(
            "[%(asctime)s] [%(levelname)s] [%(name)s] - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )

        # Clear existing handlers to avoid duplicates
        logger.handlers.clear()

        # Always add console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

        if log_to_file:
            if self._shared_file_handler is None:
                os.makedirs(local_log_dir, exist_ok=True)

                if not log_session_id:
                    raise ValueError("log_session_id must be provided for shared logging.")

                log_file_name = f"{tenant_id}_{enterprise_id}_{log_session_id}.log"
                self._shared_log_file_path = os.path.join(local_log_dir, log_file_name)

                self._shared_file_handler = logging.FileHandler(self._shared_log_file_path)
                self._shared_file_handler.setFormatter(formatter)

            # Add the shared file handler
            logger.addHandler(self._shared_file_handler)
            logger.debug(f"📝 Added file handler for logger '{name}' to {self._shared_log_file_path}")

        # Add metadata attributes to logger
        logger.log_file_path = self._shared_log_file_path
        logger.tenant_id = tenant_id
        logger.enterprise_id = enterprise_id
        logger.log_session_id = log_session_id

        # Track this logger as an application logger
        self._application_loggers.add(logger)

        return logger
    
    def save_log_to_lakehouse(
        self,
        logger: logging.Logger,
        lakehouse_root: str = "/lakehouse/default/Files/logs"
    ) -> None:
        """
        Copies the logger's local log file to a structured Lakehouse path and removes the local copy.
        Renames the file to HH_MM_SS_epoch.log during the move.

        Args:
            logger: Logger instance with log_file_path attribute
            lakehouse_root: Root path for Lakehouse log storage

        Example:
            >>> df_logger = DFLogger()
            >>> logger = df_logger.get_logger(log_to_file=True, log_session_id="20231201_143022")
            >>> # ... perform operations ...
            >>> df_logger.save_log_to_lakehouse(logger)
        """
        # Flush all handlers to ensure all logs are written to file
        for handler in logger.handlers:
            if hasattr(handler, 'flush'):
                handler.flush()
        
        if not hasattr(logger, "log_file_path") or not logger.log_file_path:
            logger.warning("⚠️ logger.log_file_path not set. Skipping upload.")
            return

        try:
            tenant_id = getattr(logger, "tenant_id", "unknown_tenant")
            enterprise_id = getattr(logger, "enterprise_id", "unknown_enterprise")
            log_session_id = getattr(logger, "log_session_id", None)

            if not log_session_id:
                raise ValueError("log_session_id not found on logger.")

            # Try different formats for log_session_id
            timestamp = None
            try:
                # Try ISO format first (e.g., "2025-01-29T16:57:36")
                timestamp = datetime.fromisoformat(log_session_id)
            except ValueError:
                try:
                    # Try the original format (e.g., "20250129_165736")
                    timestamp = datetime.strptime(log_session_id, "%Y%m%d_%H%M%S")
                except ValueError:
                    # If both fail, use current time
                    logger.warning(f"⚠️ Could not parse log_session_id '{log_session_id}'. Using current time.")
                    timestamp = datetime.now()

            year = timestamp.strftime("%Y")
            month = timestamp.strftime("%m")
            day = timestamp.strftime("%d")
            time_str = timestamp.strftime("%H_%M_%S")
            epoch = int(timestamp.timestamp())

            dst_dir = os.path.join(lakehouse_root, tenant_id, enterprise_id, year, month)
            os.makedirs(dst_dir, exist_ok=True)

            dst_file_name = f"{day}_{time_str}_{epoch}.log"
            dst_path = os.path.join(dst_dir, dst_file_name)

            # Check if source file exists
            if not os.path.exists(logger.log_file_path):
                #logger.warning(f"⚠️ Log file not found: {logger.log_file_path}")
                return

            # Append to Lakehouse file (don't overwrite)
            with open(logger.log_file_path, "r", encoding="utf-8") as src, open(dst_path, "a", encoding="utf-8") as dst:
                dst.write(src.read())
            logger.info(f"✅ Log appended to Lakehouse: {dst_path}")

            # Delete local file and create a new file handler for subsequent logs
            os.remove(logger.log_file_path)
            logger.info(f"🧹 Temp log file deleted: {logger.log_file_path}")
            
            # Create a new file handler for subsequent logs in the same session
            if self._shared_file_handler is not None:
                try:
                    self._shared_file_handler.close()
                except:
                    pass
            
            # Create a new log file for the same session
            log_file_name = f"{tenant_id}_{enterprise_id}_{log_session_id}.log"
            self._shared_log_file_path = os.path.join("/tmp/logs", log_file_name)
            
            formatter = logging.Formatter(
                "[%(asctime)s] [%(levelname)s] [%(name)s] - %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )
            
            self._shared_file_handler = logging.FileHandler(self._shared_log_file_path)
            self._shared_file_handler.setFormatter(formatter)
            
            # Update only application loggers to use the new file handler
            # This ensures only our logger instances can continue writing after a save
            for app_logger in self._application_loggers:
                # Remove old file handlers and add the new shared handler
                for handler in app_logger.handlers[:]:
                    if isinstance(handler, logging.FileHandler):
                        app_logger.removeHandler(handler)
                app_logger.addHandler(self._shared_file_handler)

        except Exception as e:
            logger.error(f"❌ Failed to save log file: {e}")
            # Don't raise the exception to avoid breaking the main flow
    
    def create_log_session_id(self) -> str:
        """
        Create a unique log session identifier based on current UTC timestamp.

        Returns:
            Session ID in format 'yyyyMMdd_HHmmss' using UTC time

        Example:
            >>> df_logger = DFLogger()
            >>> session_id = df_logger.create_log_session_id()
            >>> # Returns: '20231201_143022' (UTC time)
        """
        return datetime.utcnow().strftime("%Y%m%d_%H%M%S")


# Global instance for backward compatibility
_df_logger_instance = DFLogger()


# Backward compatibility functions - these maintain the exact same functionality
def df_reset_logger_globals() -> None:
    """Reset global variables to allow new log sessions."""
    _df_logger_instance.reset_logger_globals()


def df_get_logger(
    tenant_id: str,
    enterprise_id: str,
    log_session_id: str,
    name: str = __name__,
    level: int = logging.INFO,
    log_to_file: bool = False,
    local_log_dir: str = "/tmp/logs",
) -> logging.Logger:
    """
    Creates and returns a logger instance with optional console and shared file handlers.
    All loggers with the same log_session_id will write to the same file.
    
    Args:
        tenant_id: Tenant identifier (mandatory)
        enterprise_id: Enterprise identifier (mandatory)
        log_session_id: Log session identifier (mandatory)
        name: Logger name (default: module name)
        level: Logging level (default: INFO)
        log_to_file: Whether to log to file (default: False)
        local_log_dir: Local directory for log files (default: /tmp/logs)
        
    Returns:
        Configured logger instance
        
    Raises:
        ValueError: If mandatory parameters are missing
    """
    return _df_logger_instance.get_logger(
        tenant_id=tenant_id,
        enterprise_id=enterprise_id,
        log_session_id=log_session_id,
        name=name,
        level=level,
        log_to_file=log_to_file,
        local_log_dir=local_log_dir
    )


def df_save_log_to_lakehouse(
    logger: logging.Logger,
    lakehouse_root: str = "/lakehouse/default/Files/logs"
) -> None:
    """
    Copies the logger's local log file to a structured Lakehouse path and removes the local copy.
    Renames the file to HH_MM_SS_epoch.log during the move.

    Args:
        logger: Logger instance with log_file_path attribute
        lakehouse_root: Root path for Lakehouse log storage

    Example:
        >>> logger = df_get_logger(log_to_file=True, log_session_id="20231201_143022")
        >>> # ... perform operations ...
        >>> df_save_log_to_lakehouse(logger)
    """
    _df_logger_instance.save_log_to_lakehouse(logger, lakehouse_root)


def df_create_log_session_id() -> str:
    """
    Create a unique log session identifier based on current UTC timestamp.

    Returns:
        Session ID in format 'yyyyMMdd_HHmmss' using UTC time

    Example:
        >>> session_id = df_create_log_session_id()
        >>> # Returns: '20231201_143022' (UTC time)
    """
    return _df_logger_instance.create_log_session_id()


# Log level reference table for documentation
LOG_LEVELS = {
    "DEBUG": "DEBUG, INFO, WARNING, ERROR, CRITICAL",
    "INFO": "INFO, WARNING, ERROR, CRITICAL (skips DEBUG)",
    "WARNING": "WARNING, ERROR, CRITICAL (skips DEBUG, INFO)",
    "ERROR": "ERROR, CRITICAL (skips DEBUG, INFO, WARNING)",
    "CRITICAL": "Only CRITICAL (skips all lower levels)"
} 