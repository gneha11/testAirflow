"""
Main logging module providing standardized logging for AIML platform.

Features:
- Structured logging with JSON output
- Colored console output for development
- Configurable log levels and handlers
- Context-aware logging with correlation IDs
- Performance logging utilities
- Configuration-driven setup
- Security and audit logging
- Request/Response logging
- Health check logging
"""

import logging
import logging.config
import os
import sys
import uuid
from enum import Enum
from typing import Any, Optional, Union

import structlog
import yaml

from .formatters import AuditFormatter, ColoredFormatter, PerformanceFormatter, StructuredFormatter


class LogLevel(Enum):
    """Enumeration of available log levels."""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class AIMLLogger:
    """
    Enhanced logger wrapper providing additional functionality for AIML platform.
    """

    def __init__(self, name: str, logger: logging.Logger):
        self.name = name
        self._logger = logger
        self._context = {}
        self._correlation_id = None

    def with_context(self, **kwargs) -> "AIMLLogger":
        """Add context to all log messages."""
        new_logger = AIMLLogger(self.name, self._logger)
        new_logger._context = {**self._context, **kwargs}
        new_logger._correlation_id = self._correlation_id
        return new_logger

    def with_correlation_id(self, correlation_id: str) -> "AIMLLogger":
        """Add correlation ID for request tracking."""
        new_logger = AIMLLogger(self.name, self._logger)
        new_logger._context = self._context.copy()
        new_logger._correlation_id = correlation_id
        return new_logger

    def _log_with_context(self, level: int, msg: str, *args, **kwargs):
        """Log message with context information."""
        extra = kwargs.get("extra", {})
        extra.update(self._context)

        # Add correlation ID if available
        if self._correlation_id:
            extra["correlation_id"] = self._correlation_id

        kwargs["extra"] = extra
        self._logger.log(level, msg, *args, **kwargs)

    def debug(self, msg: str, *args, **kwargs):
        """Log debug message."""
        self._log_with_context(logging.DEBUG, msg, *args, **kwargs)

    def info(self, msg: str, *args, **kwargs):
        """Log info message."""
        self._log_with_context(logging.INFO, msg, *args, **kwargs)

    def warning(self, msg: str, *args, **kwargs):
        """Log warning message."""
        self._log_with_context(logging.WARNING, msg, *args, **kwargs)

    def error(self, msg: str, *args, **kwargs):
        """Log error message."""
        self._log_with_context(logging.ERROR, msg, *args, **kwargs)

    def critical(self, msg: str, *args, **kwargs):
        """Log critical message."""
        self._log_with_context(logging.CRITICAL, msg, *args, **kwargs)

    def exception(self, msg: str, *args, **kwargs):
        """Log exception with traceback."""
        kwargs["exc_info"] = True
        self.error(msg, *args, **kwargs)

    def performance(self, operation: str, duration: float, **kwargs):
        """Log performance metrics."""
        self.info(
            f"Performance: {operation}",
            extra={"operation": operation, "duration_ms": round(duration * 1000, 2), "performance_log": True, **kwargs},
        )

    def audit(self, action: str, user: str, resource: str, result: str = "success", **kwargs):
        """Log audit trail entry."""
        self.info(
            f"Audit: {action} on {resource} by {user} - {result}",
            extra={"action": action, "user": user, "resource": resource, "result": result, "audit_log": True, **kwargs},
        )

    def security(self, event: str, user: Optional[str] = None, ip_address: Optional[str] = None, **kwargs):
        """Log security events."""
        self.warning(
            f"Security: {event}",
            extra={"security_event": event, "user": user, "ip_address": ip_address, "security_log": True, **kwargs},
        )

    def request(self, method: str, url: str, status_code: int, duration: float, **kwargs):
        """Log HTTP request/response."""
        self.info(
            f"Request: {method} {url} - {status_code} ({duration:.3f}s)",
            extra={
                "request_method": method,
                "request_url": url,
                "response_status": status_code,
                "duration_ms": round(duration * 1000, 2),
                "request_log": True,
                **kwargs,
            },
        )

    def database(self, operation: str, table: str, duration: float, **kwargs):
        """Log database operations."""
        self.info(
            f"Database: {operation} on {table} ({duration:.3f}s)",
            extra={
                "db_operation": operation,
                "db_table": table,
                "duration_ms": round(duration * 1000, 2),
                "database_log": True,
                **kwargs,
            },
        )

    def health(self, component: str, status: str, details: Optional[str] = None, **kwargs):
        """Log health check information."""
        self.info(
            f"Health: {component} - {status}",
            extra={
                "health_component": component,
                "health_status": status,
                "health_details": details,
                "health_log": True,
                **kwargs,
            },
        )


def load_config(config_path: str = "config.yaml") -> dict[str, Any]:
    """Load logging configuration from YAML file."""
    try:
        with open(config_path) as file:
            config = yaml.safe_load(file)
        return config.get("aimp_platform", {}).get("logging", {})
    except FileNotFoundError:
        print(f"Warning: Config file {config_path} not found, using defaults")
        return {}
    except yaml.YAMLError as e:
        print(f"Warning: Error parsing config file: {e}, using defaults")
        return {}


def get_environment_config(config: dict[str, Any], environment: Optional[str] = None) -> dict[str, Any]:
    """Get environment-specific configuration."""
    if environment is None:
        environment = os.getenv("ENVIRONMENT", "development")

    env_config = config.get("environments", {}).get(environment, {})
    global_config = config.get("global", {})

    # Merge global config with environment-specific config
    merged_config = global_config.copy()
    merged_config.update(env_config)

    return merged_config


def configure_logging_from_config(
    config_path: str = "config.yaml", environment: Optional[str] = None, component: Optional[str] = None
) -> None:
    """
    Configure logging from YAML configuration file.

    Args:
        config_path: Path to configuration file
        environment: Environment name (dev/staging/prod)
        component: Component name for component-specific config
    """
    config = load_config(config_path)
    env_config = get_environment_config(config, environment)

    # Get component-specific config if provided
    if component:
        component_config = config.get("components", {}).get(component, {})
        env_config.update(component_config)

    # Extract configuration parameters
    level = env_config.get("level", "INFO")
    format_type = env_config.get("format_type", "structured")
    enable_console = env_config.get("enable_console", True)
    enable_colors = env_config.get("enable_colors", True)
    enable_file = env_config.get("enable_file", False)

    # File configuration
    file_config = config.get("file", {})
    log_file = None
    if enable_file and file_config.get("enabled", False):
        log_file = file_config.get("path", "logs/aimp.log")
        # Ensure log directory exists
        os.makedirs(os.path.dirname(log_file), exist_ok=True)

    # Configure logging
    configure_logging(
        level=level,
        format_type=format_type,
        log_file=log_file,
        enable_console=enable_console,
        enable_colors=enable_colors,
        max_bytes=file_config.get("max_bytes", 10 * 1024 * 1024),
        backup_count=file_config.get("backup_count", 5),
    )


def configure_logging(
    level: Union[str, LogLevel] = LogLevel.INFO,
    format_type: str = "structured",
    log_file: Optional[str] = None,
    enable_console: bool = True,
    enable_colors: bool = True,
    max_bytes: int = 10 * 1024 * 1024,  # 10MB
    backup_count: int = 5,
) -> None:
    """
    Configure logging for the application.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format_type: Format type ('structured' for JSON, 'colored' for colored text)
        log_file: Path to log file (optional)
        enable_console: Whether to enable console logging
        enable_colors: Whether to enable colored output (console only)
        max_bytes: Maximum log file size before rotation
        backup_count: Number of backup files to keep
    """
    # Convert LogLevel enum to string if needed
    if isinstance(level, LogLevel):
        level = level.value

    # Clear existing handlers
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    # Set root logger level
    root_logger.setLevel(getattr(logging, level.upper()))

    handlers = []

    # Console handler
    if enable_console:
        console_handler = logging.StreamHandler(sys.stdout)
        if format_type == "structured":
            console_handler.setFormatter(StructuredFormatter())
        elif format_type == "audit":
            console_handler.setFormatter(AuditFormatter())
        elif format_type == "performance":
            console_handler.setFormatter(PerformanceFormatter())
        else:
            console_handler.setFormatter(ColoredFormatter(enable_colors=enable_colors))
        handlers.append(console_handler)

    # File handler
    if log_file:
        from logging.handlers import RotatingFileHandler

        file_handler = RotatingFileHandler(log_file, maxBytes=max_bytes, backupCount=backup_count)
        file_handler.setFormatter(StructuredFormatter())
        handlers.append(file_handler)

    # Add handlers to root logger
    for handler in handlers:
        handler.setLevel(getattr(logging, level.upper()))
        root_logger.addHandler(handler)

    # Configure structlog if using structured logging
    if format_type == "structured":
        structlog.configure(
            processors=[
                structlog.stdlib.filter_by_level,
                structlog.stdlib.add_logger_name,
                structlog.stdlib.add_log_level,
                structlog.stdlib.PositionalArgumentsFormatter(),
                structlog.processors.TimeStamper(fmt="iso"),
                structlog.processors.StackInfoRenderer(),
                structlog.processors.format_exc_info,
                structlog.processors.UnicodeDecoder(),
                structlog.processors.JSONRenderer(),
            ],
            context_class=dict,
            logger_factory=structlog.stdlib.LoggerFactory(),
            wrapper_class=structlog.stdlib.BoundLogger,
            cache_logger_on_first_use=True,
        )


def get_logger(name: Optional[str] = None) -> AIMLLogger:
    """
    Get a logger instance for the specified name.

    Args:
        name: Logger name (defaults to calling module name)

    Returns:
        AIMLLogger instance
    """
    if name is None:
        # Get the calling module name
        import inspect

        frame = inspect.currentframe().f_back
        name = frame.f_globals.get("__name__", "aiml")

    # Get standard logger
    logger = logging.getLogger(name)

    # Return wrapped logger
    return AIMLLogger(name, logger)


def generate_correlation_id() -> str:
    """Generate a unique correlation ID for request tracking."""
    return str(uuid.uuid4())


def setup_default_logging():
    """Setup default logging configuration for AIML platform."""
    # Try to load from config first
    try:
        configure_logging_from_config()
    except Exception as e:
        print(f"Warning: Could not load config, using environment variables: {e}")

        # Fall back to environment variables
        log_level = os.getenv("LOG_LEVEL", "INFO").upper()
        log_format = os.getenv("LOG_FORMAT", "structured")
        log_file = os.getenv("LOG_FILE")

        configure_logging(
            level=log_level,
            format_type=log_format,
            log_file=log_file,
            enable_console=True,
            enable_colors=os.getenv("LOG_COLORS", "true").lower() == "true",
        )
