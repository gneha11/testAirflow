"""
Custom logging formatters for AIML platform.

Provides structured JSON formatting and colored console formatting
with consistent timestamp and context information.
"""

import json
import logging
from datetime import datetime

import colorlog


class StructuredFormatter(logging.Formatter):
    """
    JSON formatter for structured logging.

    Outputs log records as JSON with consistent fields:
    - timestamp: ISO format timestamp
    - level: Log level name
    - logger: Logger name
    - message: Log message
    - module: Module name
    - function: Function name
    - line: Line number
    - context: Additional context data
    """

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        # Create base log entry
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        # Add extra context from record
        extra_fields = {}
        for key, value in record.__dict__.items():
            if key not in {
                "name",
                "msg",
                "args",
                "levelname",
                "levelno",
                "pathname",
                "filename",
                "module",
                "lineno",
                "funcName",
                "created",
                "msecs",
                "relativeCreated",
                "thread",
                "threadName",
                "processName",
                "process",
                "getMessage",
                "exc_info",
                "exc_text",
                "stack_info",
            }:
                extra_fields[key] = value

        if extra_fields:
            log_entry["context"] = extra_fields

        return json.dumps(log_entry, default=str, ensure_ascii=False)


class ColoredFormatter(colorlog.ColoredFormatter):
    """
    Colored formatter for console output.

    Provides colored log levels and timestamps for better readability
    during development and debugging.
    """

    def __init__(self, enable_colors: bool = True):
        """
        Initialize colored formatter.

        Args:
            enable_colors: Whether to enable colored output
        """
        if enable_colors:
            log_colors = {
                "DEBUG": "cyan",
                "INFO": "green",
                "WARNING": "yellow",
                "ERROR": "red",
                "CRITICAL": "red,bg_white",
            }

            format_string = (
                "%(log_color)s%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s%(reset)s"
            )

            super().__init__(
                fmt=format_string, datefmt="%Y-%m-%d %H:%M:%S", log_colors=log_colors, reset=True, style="%"
            )
        else:
            # No colors, plain format
            format_string = "%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s"

            super().__init__(fmt=format_string, datefmt="%Y-%m-%d %H:%M:%S", style="%")


class PerformanceFormatter(logging.Formatter):
    """
    Specialized formatter for performance logs.

    Formats performance-related log entries with metrics
    and timing information.
    """

    def format(self, record: logging.LogRecord) -> str:
        """Format performance log record."""
        if hasattr(record, "performance_log") and record.performance_log:
            # This is a performance log
            context = getattr(record, "context", {})
            operation = context.get("operation", "unknown")
            duration = context.get("duration_ms", 0)

            performance_data = {
                "timestamp": datetime.fromtimestamp(record.created).isoformat(),
                "type": "performance",
                "operation": operation,
                "duration_ms": duration,
                "logger": record.name,
                "module": record.module,
                "function": record.funcName,
            }

            # Add any additional context
            for key, value in context.items():
                if key not in {"operation", "duration_ms", "performance_log"}:
                    performance_data[key] = value

            return json.dumps(performance_data, default=str, ensure_ascii=False)
        else:
            # Fall back to structured format
            return StructuredFormatter().format(record)


class AuditFormatter(logging.Formatter):
    """
    Specialized formatter for audit logs.

    Formats audit trail entries with user, action, and resource information.
    """

    def format(self, record: logging.LogRecord) -> str:
        """Format audit log record."""
        if hasattr(record, "audit_log") and record.audit_log:
            context = getattr(record, "context", {})

            audit_data = {
                "timestamp": datetime.fromtimestamp(record.created).isoformat(),
                "type": "audit",
                "message": record.getMessage(),
                "user": context.get("user", "unknown"),
                "action": context.get("action", "unknown"),
                "resource": context.get("resource", "unknown"),
                "result": context.get("result", "unknown"),
                "logger": record.name,
            }

            # Add IP address if available
            if "ip_address" in context:
                audit_data["ip_address"] = context["ip_address"]

            # Add session ID if available
            if "session_id" in context:
                audit_data["session_id"] = context["session_id"]

            return json.dumps(audit_data, default=str, ensure_ascii=False)
        else:
            # Fall back to structured format
            return StructuredFormatter().format(record)
