"""
Utility decorators for AIML platform.

Provides common decorators for retry logic, timeouts, rate limiting,
and other cross-cutting concerns.
"""

import functools
import threading
import time
from collections import defaultdict, deque
from typing import Any, Callable, Optional, Tuple, Type, Union

from ..logger import get_logger


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: Union[Type[Exception], Tuple[Type[Exception], ...]] = Exception,
    on_retry: Optional[Callable] = None,
):
    """
    Retry decorator with exponential backoff.

    Args:
        max_attempts: Maximum number of retry attempts
        delay: Initial delay between retries (seconds)
        backoff: Backoff multiplier for delay
        exceptions: Exception types to catch and retry
        on_retry: Callback function called on each retry

    Example:
        @retry(max_attempts=3, delay=1.0, backoff=2.0)
        def unreliable_function():
            # Function that might fail
            pass
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            logger = get_logger(f"{func.__module__}.{func.__name__}")

            last_exception = None
            current_delay = delay

            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e

                    if attempt < max_attempts - 1:
                        logger.warning(f"Attempt {attempt + 1} failed, retrying in {current_delay}s: {e!s}")

                        if on_retry:
                            on_retry(attempt + 1, e, current_delay)

                        time.sleep(current_delay)
                        current_delay *= backoff
                    else:
                        logger.error(f"All {max_attempts} attempts failed: {e!s}")

            # All attempts failed, raise the last exception
            raise last_exception

        return wrapper

    return decorator


def timeout(seconds: float):
    """
    Timeout decorator for function execution.

    Args:
        seconds: Timeout in seconds

    Example:
        @timeout(30.0)
        def long_running_function():
            # Function that might take too long
            pass
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            import signal

            def timeout_handler(signum, frame):
                raise TimeoutError(f"Function '{func.__name__}' timed out after {seconds} seconds")

            # Set up the timeout
            old_handler = signal.signal(signal.SIGALRM, timeout_handler)
            signal.alarm(int(seconds))

            try:
                result = func(*args, **kwargs)
                return result
            finally:
                # Clean up
                signal.alarm(0)
                signal.signal(signal.SIGALRM, old_handler)

        return wrapper

    return decorator


class RateLimiter:
    """
    Rate limiter implementation using token bucket algorithm.
    """

    def __init__(self, max_calls: int, time_window: float):
        """
        Initialize rate limiter.

        Args:
            max_calls: Maximum number of calls allowed
            time_window: Time window in seconds
        """
        self.max_calls = max_calls
        self.time_window = time_window
        self.calls = deque()
        self.lock = threading.Lock()

    def is_allowed(self) -> bool:
        """Check if a call is allowed within the rate limit."""
        with self.lock:
            now = time.time()

            # Remove old calls outside the time window
            while self.calls and self.calls[0] <= now - self.time_window:
                self.calls.popleft()

            # Check if we can make another call
            if len(self.calls) < self.max_calls:
                self.calls.append(now)
                return True

            return False

    def wait_time(self) -> float:
        """Get the time to wait before the next call is allowed."""
        with self.lock:
            if not self.calls:
                return 0.0

            oldest_call = self.calls[0]
            wait_time = oldest_call + self.time_window - time.time()
            return max(0.0, wait_time)


# Global rate limiters for different functions
_rate_limiters = defaultdict(lambda: None)
_rate_limiter_lock = threading.Lock()


def rate_limit(max_calls: int, time_window: float, per_instance: bool = False):
    """
    Rate limiting decorator.

    Args:
        max_calls: Maximum number of calls allowed
        time_window: Time window in seconds
        per_instance: Whether to apply rate limiting per instance (for methods)

    Example:
        @rate_limit(max_calls=10, time_window=60.0)
        def api_call():
            # Function that should be rate limited
            pass
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            logger = get_logger(f"{func.__module__}.{func.__name__}")

            # Determine rate limiter key
            if per_instance and args:
                # Use instance id for per-instance rate limiting
                limiter_key = f"{func.__name__}_{id(args[0])}"
            else:
                # Global rate limiting for the function
                limiter_key = func.__name__

            with _rate_limiter_lock:
                if limiter_key not in _rate_limiters or _rate_limiters[limiter_key] is None:
                    _rate_limiters[limiter_key] = RateLimiter(max_calls, time_window)

                rate_limiter = _rate_limiters[limiter_key]

            # Check if call is allowed
            if not rate_limiter.is_allowed():
                wait_time = rate_limiter.wait_time()
                logger.warning(f"Rate limit exceeded for '{func.__name__}', waiting {wait_time:.2f}s")
                time.sleep(wait_time)

                # Try again after waiting
                if not rate_limiter.is_allowed():
                    raise RuntimeError(f"Rate limit exceeded for function '{func.__name__}'")

            return func(*args, **kwargs)

        return wrapper

    return decorator


def cache(ttl: Optional[float] = None, max_size: int = 128):
    """
    Simple caching decorator with TTL support.

    Args:
        ttl: Time to live in seconds (None for no expiration)
        max_size: Maximum cache size

    Example:
        @cache(ttl=300.0, max_size=100)
        def expensive_function(arg1, arg2):
            # Expensive computation
            return result
    """

    def decorator(func: Callable) -> Callable:
        cache_data = {}
        cache_times = {}
        cache_lock = threading.Lock()

        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            # Create cache key
            key = str(args) + str(sorted(kwargs.items()))

            with cache_lock:
                now = time.time()

                # Check if cached value exists and is still valid
                if key in cache_data:
                    if ttl is None or (now - cache_times[key]) < ttl:
                        return cache_data[key]
                    else:
                        # Remove expired entry
                        del cache_data[key]
                        del cache_times[key]

                # Check cache size limit
                if len(cache_data) >= max_size:
                    # Remove oldest entry
                    oldest_key = min(cache_times.keys(), key=lambda k: cache_times[k])
                    del cache_data[oldest_key]
                    del cache_times[oldest_key]

                # Compute and cache result
                result = func(*args, **kwargs)
                cache_data[key] = result
                cache_times[key] = now

                return result

        # Add cache management methods
        def clear_cache():
            with cache_lock:
                cache_data.clear()
                cache_times.clear()

        def cache_info():
            with cache_lock:
                return {"size": len(cache_data), "max_size": max_size, "ttl": ttl}

        wrapper.clear_cache = clear_cache
        wrapper.cache_info = cache_info

        return wrapper

    return decorator


def measure_time(logger_name: Optional[str] = None):
    """
    Decorator to measure and log function execution time.

    Args:
        logger_name: Custom logger name (uses function name if None)

    Example:
        @measure_time()
        def slow_function():
            # Function to measure
            pass
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            logger = get_logger(logger_name or f"{func.__module__}.{func.__name__}")

            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                return result
            finally:
                duration = time.time() - start_time
                logger.performance(func.__name__, duration)

        return wrapper

    return decorator


def singleton(cls):
    """
    Singleton decorator for classes.

    Example:
        @singleton
        class MyClass:
            pass
    """
    instances = {}
    lock = threading.Lock()

    @functools.wraps(cls)
    def get_instance(*args, **kwargs):
        if cls not in instances:
            with lock:
                if cls not in instances:
                    instances[cls] = cls(*args, **kwargs)
        return instances[cls]

    return get_instance
