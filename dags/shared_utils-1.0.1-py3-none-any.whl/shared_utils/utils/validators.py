"""
Validation utilities for AIML platform.

Provides common validation functions for emails, URLs, UUIDs,
and other data types commonly used across the platform.
"""

import re
import uuid
from typing import Any, Optional
from urllib.parse import urlparse


def validate_email(email: str) -> bool:
    """
    Validate email address format.

    Args:
        email: Email address to validate

    Returns:
        True if email is valid, False otherwise
    """
    if not email or not isinstance(email, str):
        return False

    # RFC 5322 compliant email regex (simplified)
    email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

    return bool(re.match(email_pattern, email.strip()))


def validate_url(url: str, schemes: Optional[list] = None) -> bool:
    """
    Validate URL format.

    Args:
        url: URL to validate
        schemes: List of allowed schemes (default: ['http', 'https'])

    Returns:
        True if URL is valid, False otherwise
    """
    if not url or not isinstance(url, str):
        return False

    if schemes is None:
        schemes = ["http", "https"]

    try:
        parsed = urlparse(url.strip())
        return parsed.scheme in schemes and bool(parsed.netloc) and len(parsed.netloc) > 0
    except Exception:
        return False


def validate_uuid(uuid_string: str, version: Optional[int] = None) -> bool:
    """
    Validate UUID format.

    Args:
        uuid_string: UUID string to validate
        version: Specific UUID version to validate (1-5, None for any)

    Returns:
        True if UUID is valid, False otherwise
    """
    if not uuid_string or not isinstance(uuid_string, str):
        return False

    try:
        uuid_obj = uuid.UUID(uuid_string.strip())

        if version is not None:
            return uuid_obj.version == version

        return True
    except (ValueError, AttributeError):
        return False


def validate_phone_number(phone: str, country_code: Optional[str] = None) -> bool:
    """
    Validate phone number format.

    Args:
        phone: Phone number to validate
        country_code: Country code for validation (e.g., 'US', 'UK')

    Returns:
        True if phone number is valid, False otherwise
    """
    if not phone or not isinstance(phone, str):
        return False

    # Remove common formatting characters
    cleaned = re.sub(r"[^\d+]", "", phone.strip())

    # Basic validation - should start with + or digit and be 7-15 digits
    if country_code == "US":
        # US phone number validation (10 digits, optional +1)
        us_pattern = r"^(\+1)?[2-9]\d{2}[2-9]\d{2}\d{4}$"
        return bool(re.match(us_pattern, cleaned))
    else:
        # International format - 7 to 15 digits, optional +
        intl_pattern = r"^(\+\d{1,3})?\d{7,14}$"
        return bool(re.match(intl_pattern, cleaned))


def validate_ip_address(ip: str, version: Optional[int] = None) -> bool:
    """
    Validate IP address format.

    Args:
        ip: IP address to validate
        version: IP version (4 or 6, None for either)

    Returns:
        True if IP address is valid, False otherwise
    """
    if not ip or not isinstance(ip, str):
        return False

    import ipaddress

    try:
        ip_obj = ipaddress.ip_address(ip.strip())

        if version == 4:
            return isinstance(ip_obj, ipaddress.IPv4Address)
        elif version == 6:
            return isinstance(ip_obj, ipaddress.IPv6Address)
        else:
            return True
    except ValueError:
        return False


def validate_json(json_string: str) -> bool:
    """
    Validate JSON string format.

    Args:
        json_string: JSON string to validate

    Returns:
        True if JSON is valid, False otherwise
    """
    if not json_string or not isinstance(json_string, str):
        return False

    import json

    try:
        json.loads(json_string.strip())
        return True
    except (json.JSONDecodeError, ValueError):
        return False


def validate_password_strength(password: str) -> dict:
    """
    Validate password strength.

    Args:
        password: Password to validate

    Returns:
        Dictionary with validation results and score
    """
    if not password or not isinstance(password, str):
        return {"is_valid": False, "score": 0, "errors": ["Password is required"]}

    errors = []
    score = 0

    # Length check
    if len(password) < 8:
        errors.append("Password must be at least 8 characters long")
    else:
        score += 1

    # Uppercase letter check
    if not re.search(r"[A-Z]", password):
        errors.append("Password must contain at least one uppercase letter")
    else:
        score += 1

    # Lowercase letter check
    if not re.search(r"[a-z]", password):
        errors.append("Password must contain at least one lowercase letter")
    else:
        score += 1

    # Digit check
    if not re.search(r"\d", password):
        errors.append("Password must contain at least one digit")
    else:
        score += 1

    # Special character check
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        errors.append("Password must contain at least one special character")
    else:
        score += 1

    # Additional strength checks
    if len(password) >= 12:
        score += 1

    if len(set(password)) >= len(password) * 0.7:  # Character diversity
        score += 1

    return {
        "is_valid": len(errors) == 0,
        "score": score,
        "max_score": 7,
        "strength": "weak" if score < 3 else "medium" if score < 5 else "strong",
        "errors": errors,
    }


def validate_credit_card(card_number: str) -> dict:
    """
    Validate credit card number using Luhn algorithm.

    Args:
        card_number: Credit card number to validate

    Returns:
        Dictionary with validation results and card type
    """
    if not card_number or not isinstance(card_number, str):
        return {"is_valid": False, "card_type": None, "error": "Card number is required"}

    # Remove spaces and hyphens
    cleaned = re.sub(r"[\s-]", "", card_number.strip())

    # Check if all characters are digits
    if not cleaned.isdigit():
        return {"is_valid": False, "card_type": None, "error": "Card number must contain only digits"}

    # Luhn algorithm validation
    def luhn_check(num_str):
        digits = [int(d) for d in num_str]
        for i in range(len(digits) - 2, -1, -2):
            digits[i] *= 2
            if digits[i] > 9:
                digits[i] -= 9
        return sum(digits) % 10 == 0

    # Determine card type
    card_type = None
    if cleaned.startswith("4"):
        card_type = "Visa"
    elif cleaned.startswith(("51", "52", "53", "54", "55")):
        card_type = "MasterCard"
    elif cleaned.startswith(("34", "37")):
        card_type = "American Express"
    elif cleaned.startswith("6011"):
        card_type = "Discover"

    is_valid = luhn_check(cleaned) and len(cleaned) in [13, 14, 15, 16, 17, 18, 19]

    return {"is_valid": is_valid, "card_type": card_type, "error": None if is_valid else "Invalid card number"}


def validate_date_format(date_string: str, format_string: str = "%Y-%m-%d") -> bool:
    """
    Validate date string format.

    Args:
        date_string: Date string to validate
        format_string: Expected date format (default: YYYY-MM-DD)

    Returns:
        True if date format is valid, False otherwise
    """
    if not date_string or not isinstance(date_string, str):
        return False

    from datetime import datetime

    try:
        datetime.strptime(date_string.strip(), format_string)
        return True
    except ValueError:
        return False


def validate_range(value: Any, min_value: Any = None, max_value: Any = None) -> bool:
    """
    Validate that a value is within a specified range.

    Args:
        value: Value to validate
        min_value: Minimum allowed value (inclusive)
        max_value: Maximum allowed value (inclusive)

    Returns:
        True if value is within range, False otherwise
    """
    try:
        if min_value is not None and value < min_value:
            return False
        if max_value is not None and value > max_value:
            return False
        return True
    except TypeError:
        return False


def validate_length(text: str, min_length: int = None, max_length: int = None) -> bool:
    """
    Validate text length.

    Args:
        text: Text to validate
        min_length: Minimum allowed length
        max_length: Maximum allowed length

    Returns:
        True if length is valid, False otherwise
    """
    if not isinstance(text, str):
        return False

    length = len(text)

    if min_length is not None and length < min_length:
        return False
    if max_length is not None and length > max_length:
        return False

    return True
