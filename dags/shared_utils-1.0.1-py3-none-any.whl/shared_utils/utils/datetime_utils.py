"""
DateTime utilities for AIML platform.

Provides common datetime operations, timezone handling, and formatting
functions used across the platform.
"""

import time
from datetime import datetime, timedelta, timezone
from typing import Optional


def get_utc_now() -> datetime:
    """
    Get current UTC datetime.

    Returns:
        Current UTC datetime
    """
    return datetime.now(timezone.utc)


def parse_datetime(date_string: str, format_string: Optional[str] = None, timezone_aware: bool = True) -> datetime:
    """
    Parse datetime string with optional format.

    Args:
        date_string: DateTime string to parse
        format_string: Expected format (auto-detect if None)
        timezone_aware: Whether to make timezone-aware (UTC if no timezone info)

    Returns:
        Parsed datetime object
    """
    if format_string:
        dt = datetime.strptime(date_string, format_string)
    else:
        # Try common formats
        formats = [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%d",
            "%d/%m/%Y",
            "%m/%d/%Y",
            "%Y-%m-%d %H:%M",
            "%d-%m-%Y %H:%M:%S",
        ]

        dt = None
        for fmt in formats:
            try:
                dt = datetime.strptime(date_string, fmt)
                break
            except ValueError:
                continue

        if dt is None:
            raise ValueError(f"Unable to parse datetime string: {date_string}")

    # Make timezone-aware if requested and not already aware
    if timezone_aware and dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    return dt


def format_datetime(dt: datetime, format_string: str = "%Y-%m-%d %H:%M:%S", timezone_name: Optional[str] = None) -> str:
    """
    Format datetime object as string.

    Args:
        dt: DateTime object to format
        format_string: Output format string
        timezone_name: Target timezone name (e.g., 'US/Eastern')

    Returns:
        Formatted datetime string
    """
    if timezone_name:
        import pytz

        target_tz = pytz.timezone(timezone_name)
        if dt.tzinfo is None:
            # Assume UTC if no timezone info
            dt = dt.replace(tzinfo=timezone.utc)
        dt = dt.astimezone(target_tz)

    return dt.strftime(format_string)


def datetime_to_timestamp(dt: datetime) -> float:
    """
    Convert datetime to Unix timestamp.

    Args:
        dt: DateTime object

    Returns:
        Unix timestamp
    """
    return dt.timestamp()


def timestamp_to_datetime(timestamp: float, timezone_aware: bool = True) -> datetime:
    """
    Convert Unix timestamp to datetime.

    Args:
        timestamp: Unix timestamp
        timezone_aware: Whether to return timezone-aware datetime (UTC)

    Returns:
        DateTime object
    """
    if timezone_aware:
        return datetime.fromtimestamp(timestamp, tz=timezone.utc)
    else:
        return datetime.fromtimestamp(timestamp)


def add_time(
    dt: datetime, days: int = 0, hours: int = 0, minutes: int = 0, seconds: int = 0, microseconds: int = 0
) -> datetime:
    """
    Add time to datetime object.

    Args:
        dt: Base datetime
        days: Days to add
        hours: Hours to add
        minutes: Minutes to add
        seconds: Seconds to add
        microseconds: Microseconds to add

    Returns:
        New datetime with added time
    """
    delta = timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds, microseconds=microseconds)
    return dt + delta


def subtract_time(
    dt: datetime, days: int = 0, hours: int = 0, minutes: int = 0, seconds: int = 0, microseconds: int = 0
) -> datetime:
    """
    Subtract time from datetime object.

    Args:
        dt: Base datetime
        days: Days to subtract
        hours: Hours to subtract
        minutes: Minutes to subtract
        seconds: Seconds to subtract
        microseconds: Microseconds to subtract

    Returns:
        New datetime with subtracted time
    """
    delta = timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds, microseconds=microseconds)
    return dt - delta


def time_difference(dt1: datetime, dt2: datetime) -> timedelta:
    """
    Calculate time difference between two datetimes.

    Args:
        dt1: First datetime
        dt2: Second datetime

    Returns:
        Time difference as timedelta
    """
    return dt1 - dt2


def is_business_day(dt: datetime, country: str = "US") -> bool:
    """
    Check if datetime falls on a business day.

    Args:
        dt: DateTime to check
        country: Country code for holiday calendar

    Returns:
        True if business day, False otherwise
    """
    # Monday = 0, Sunday = 6
    weekday = dt.weekday()

    # Weekend check
    if weekday >= 5:  # Saturday or Sunday
        return False

    # Basic implementation - could be extended with holiday calendars
    return True


def get_start_of_day(dt: datetime) -> datetime:
    """
    Get start of day (00:00:00) for given datetime.

    Args:
        dt: DateTime object

    Returns:
        DateTime at start of day
    """
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


def get_end_of_day(dt: datetime) -> datetime:
    """
    Get end of day (23:59:59.999999) for given datetime.

    Args:
        dt: DateTime object

    Returns:
        DateTime at end of day
    """
    return dt.replace(hour=23, minute=59, second=59, microsecond=999999)


def get_start_of_month(dt: datetime) -> datetime:
    """
    Get start of month for given datetime.

    Args:
        dt: DateTime object

    Returns:
        DateTime at start of month
    """
    return dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def get_end_of_month(dt: datetime) -> datetime:
    """
    Get end of month for given datetime.

    Args:
        dt: DateTime object

    Returns:
        DateTime at end of month
    """
    # Get first day of next month, then subtract one day
    if dt.month == 12:
        next_month = dt.replace(year=dt.year + 1, month=1, day=1)
    else:
        next_month = dt.replace(month=dt.month + 1, day=1)

    last_day = next_month - timedelta(days=1)
    return get_end_of_day(last_day)


def age_in_years(birth_date: datetime, reference_date: Optional[datetime] = None) -> int:
    """
    Calculate age in years.

    Args:
        birth_date: Birth date
        reference_date: Reference date (default: current date)

    Returns:
        Age in years
    """
    if reference_date is None:
        reference_date = get_utc_now()

    age = reference_date.year - birth_date.year

    # Adjust if birthday hasn't occurred this year
    if (reference_date.month, reference_date.day) < (birth_date.month, birth_date.day):
        age -= 1

    return age


def format_duration(seconds: float) -> str:
    """
    Format duration in seconds as human-readable string.

    Args:
        seconds: Duration in seconds

    Returns:
        Formatted duration string
    """
    if seconds < 60:
        return f"{seconds:.2f}s"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}m"
    elif seconds < 86400:
        hours = seconds / 3600
        return f"{hours:.1f}h"
    else:
        days = seconds / 86400
        return f"{days:.1f}d"


def sleep_until(target_time: datetime):
    """
    Sleep until target datetime.

    Args:
        target_time: Target datetime to sleep until
    """
    now = get_utc_now()
    if target_time > now:
        sleep_seconds = (target_time - now).total_seconds()
        time.sleep(sleep_seconds)
