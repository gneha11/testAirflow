"""
File utilities for AIML platform.

Provides common file operations, directory management, and file handling
utilities used across the platform.
"""

import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, List, Optional, Union

import yaml


def ensure_directory(directory_path: Union[str, Path], mode: int = 0o755) -> Path:
    """
    Ensure directory exists, create if it doesn't.

    Args:
        directory_path: Path to directory
        mode: Directory permissions

    Returns:
        Path object for the directory
    """
    path = Path(directory_path)
    path.mkdir(parents=True, exist_ok=True, mode=mode)
    return path


def safe_file_write(
    file_path: Union[str, Path],
    content: Union[str, bytes],
    mode: str = "w",
    encoding: Optional[str] = "utf-8",
    backup: bool = True,
) -> bool:
    """
    Safely write content to file with optional backup.

    Args:
        file_path: Path to file
        content: Content to write
        mode: File mode ('w', 'wb', 'a', 'ab')
        encoding: Text encoding (ignored for binary modes)
        backup: Whether to create backup of existing file

    Returns:
        True if successful, False otherwise
    """
    path = Path(file_path)

    try:
        # Ensure parent directory exists
        ensure_directory(path.parent)

        # Create backup if file exists and backup is requested
        if backup and path.exists():
            backup_path = path.with_suffix(f"{path.suffix}.backup")
            shutil.copy2(path, backup_path)

        # Write to temporary file first, then move
        with tempfile.NamedTemporaryFile(
            mode=mode, encoding=encoding if "b" not in mode else None, dir=path.parent, delete=False
        ) as temp_file:
            temp_file.write(content)
            temp_path = Path(temp_file.name)

        # Move temporary file to target location
        temp_path.replace(path)
        return True

    except Exception as e:
        # Clean up temporary file if it exists
        if "temp_path" in locals() and temp_path.exists():
            temp_path.unlink()
        raise e


def get_file_hash(file_path: Union[str, Path], algorithm: str = "sha256", chunk_size: int = 8192) -> str:
    """
    Calculate hash of file contents.

    Args:
        file_path: Path to file
        algorithm: Hash algorithm ('md5', 'sha1', 'sha256', 'sha512')
        chunk_size: Size of chunks to read

    Returns:
        Hex digest of file hash
    """
    if algorithm not in ["md5", "sha1", "sha256", "sha512"]:
        raise ValueError(f"Unsupported hash algorithm: {algorithm}")

    hash_func = getattr(hashlib, algorithm)()
    path = Path(file_path)

    with open(path, "rb") as f:
        while chunk := f.read(chunk_size):
            hash_func.update(chunk)

    return hash_func.hexdigest()


def get_file_size(file_path: Union[str, Path]) -> int:
    """
    Get file size in bytes.

    Args:
        file_path: Path to file

    Returns:
        File size in bytes
    """
    return Path(file_path).stat().st_size


def get_directory_size(directory_path: Union[str, Path]) -> int:
    """
    Get total size of directory and all its contents.

    Args:
        directory_path: Path to directory

    Returns:
        Total size in bytes
    """
    total_size = 0
    path = Path(directory_path)

    for file_path in path.rglob("*"):
        if file_path.is_file():
            total_size += file_path.stat().st_size

    return total_size


def copy_file(
    source_path: Union[str, Path], destination_path: Union[str, Path], preserve_metadata: bool = True
) -> bool:
    """
    Copy file from source to destination.

    Args:
        source_path: Source file path
        destination_path: Destination file path
        preserve_metadata: Whether to preserve file metadata

    Returns:
        True if successful, False otherwise
    """
    try:
        source = Path(source_path)
        destination = Path(destination_path)

        # Ensure destination directory exists
        ensure_directory(destination.parent)

        if preserve_metadata:
            shutil.copy2(source, destination)
        else:
            shutil.copy(source, destination)

        return True
    except Exception:
        return False


def move_file(source_path: Union[str, Path], destination_path: Union[str, Path]) -> bool:
    """
    Move file from source to destination.

    Args:
        source_path: Source file path
        destination_path: Destination file path

    Returns:
        True if successful, False otherwise
    """
    try:
        source = Path(source_path)
        destination = Path(destination_path)

        # Ensure destination directory exists
        ensure_directory(destination.parent)

        shutil.move(source, destination)
        return True
    except Exception:
        return False


def delete_file(file_path: Union[str, Path], missing_ok: bool = True) -> bool:
    """
    Delete file.

    Args:
        file_path: Path to file
        missing_ok: Whether to ignore if file doesn't exist

    Returns:
        True if successful, False otherwise
    """
    try:
        Path(file_path).unlink(missing_ok=missing_ok)
        return True
    except Exception:
        return False


def delete_directory(directory_path: Union[str, Path], recursive: bool = True, missing_ok: bool = True) -> bool:
    """
    Delete directory.

    Args:
        directory_path: Path to directory
        recursive: Whether to delete recursively
        missing_ok: Whether to ignore if directory doesn't exist

    Returns:
        True if successful, False otherwise
    """
    try:
        path = Path(directory_path)

        if not path.exists() and missing_ok:
            return True

        if recursive:
            shutil.rmtree(path)
        else:
            path.rmdir()

        return True
    except Exception:
        return False


def list_files(
    directory_path: Union[str, Path],
    pattern: Optional[str] = None,
    recursive: bool = False,
    include_directories: bool = False,
) -> List[Path]:
    """
    List files in directory with optional filtering.

    Args:
        directory_path: Path to directory
        pattern: Glob pattern to match (e.g., "*.txt")
        recursive: Whether to search recursively
        include_directories: Whether to include directories in results

    Returns:
        List of matching file paths
    """
    path = Path(directory_path)

    if not path.exists() or not path.is_dir():
        return []

    if recursive:
        glob_method = path.rglob
    else:
        glob_method = path.glob

    if pattern:
        items = glob_method(pattern)
    else:
        items = glob_method("*")

    results = []
    for item in items:
        if include_directories or item.is_file():
            results.append(item)

    return sorted(results)


def read_json_file(file_path: Union[str, Path]) -> dict[str, Any]:
    """
    Read JSON file.

    Args:
        file_path: Path to JSON file

    Returns:
        Parsed JSON data
    """
    with open(file_path, encoding="utf-8") as f:
        return json.load(f)


def write_json_file(
    file_path: Union[str, Path], data: dict[str, Any], indent: int = 2, ensure_ascii: bool = False
) -> bool:
    """
    Write data to JSON file.

    Args:
        file_path: Path to JSON file
        data: Data to write
        indent: JSON indentation
        ensure_ascii: Whether to ensure ASCII encoding

    Returns:
        True if successful, False otherwise
    """
    try:
        content = json.dumps(data, indent=indent, ensure_ascii=ensure_ascii)
        return safe_file_write(file_path, content)
    except Exception:
        return False


def read_yaml_file(file_path: Union[str, Path]) -> dict[str, Any]:
    """
    Read YAML file.

    Args:
        file_path: Path to YAML file

    Returns:
        Parsed YAML data
    """
    with open(file_path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def write_yaml_file(file_path: Union[str, Path], data: dict[str, Any], default_flow_style: bool = False) -> bool:
    """
    Write data to YAML file.

    Args:
        file_path: Path to YAML file
        data: Data to write
        default_flow_style: YAML flow style

    Returns:
        True if successful, False otherwise
    """
    try:
        content = yaml.dump(data, default_flow_style=default_flow_style)
        return safe_file_write(file_path, content)
    except Exception:
        return False


def find_files_by_extension(
    directory_path: Union[str, Path], extensions: Union[str, List[str]], recursive: bool = True
) -> List[Path]:
    """
    Find files by extension(s).

    Args:
        directory_path: Path to directory
        extensions: File extension(s) to search for
        recursive: Whether to search recursively

    Returns:
        List of matching file paths
    """
    if isinstance(extensions, str):
        extensions = [extensions]

    # Ensure extensions start with dot
    extensions = [ext if ext.startswith(".") else f".{ext}" for ext in extensions]

    results = []
    for ext in extensions:
        pattern = f"*{ext}"
        files = list_files(directory_path, pattern, recursive)
        results.extend(files)

    return sorted(set(results))


def get_file_info(file_path: Union[str, Path]) -> dict[str, Any]:
    """
    Get comprehensive file information.

    Args:
        file_path: Path to file

    Returns:
        Dictionary with file information
    """
    path = Path(file_path)

    if not path.exists():
        return {}

    stat = path.stat()

    return {
        "name": path.name,
        "stem": path.stem,
        "suffix": path.suffix,
        "size": stat.st_size,
        "created": stat.st_ctime,
        "modified": stat.st_mtime,
        "accessed": stat.st_atime,
        "is_file": path.is_file(),
        "is_directory": path.is_dir(),
        "is_symlink": path.is_symlink(),
        "absolute_path": str(path.absolute()),
        "parent": str(path.parent),
    }


def create_temp_file(
    suffix: Optional[str] = None,
    prefix: Optional[str] = None,
    directory: Optional[Union[str, Path]] = None,
    text: bool = True,
) -> Path:
    """
    Create temporary file.

    Args:
        suffix: File suffix
        prefix: File prefix
        directory: Directory to create file in
        text: Whether to open in text mode

    Returns:
        Path to temporary file
    """
    fd, temp_path = tempfile.mkstemp(suffix=suffix, prefix=prefix, dir=directory, text=text)

    # Close the file descriptor
    os.close(fd)

    return Path(temp_path)


def create_temp_directory(
    suffix: Optional[str] = None, prefix: Optional[str] = None, directory: Optional[Union[str, Path]] = None
) -> Path:
    """
    Create temporary directory.

    Args:
        suffix: Directory suffix
        prefix: Directory prefix
        directory: Parent directory

    Returns:
        Path to temporary directory
    """
    temp_dir = tempfile.mkdtemp(suffix=suffix, prefix=prefix, dir=directory)

    return Path(temp_dir)


def compress_directory(directory_path: Union[str, Path], output_path: Union[str, Path], format: str = "zip") -> bool:
    """
    Compress directory to archive.

    Args:
        directory_path: Path to directory to compress
        output_path: Path for output archive
        format: Archive format ('zip', 'tar', 'gztar', 'bztar', 'xztar')

    Returns:
        True if successful, False otherwise
    """
    try:
        shutil.make_archive(str(output_path).replace(f".{format}", ""), format, str(directory_path))
        return True
    except Exception:
        return False


def extract_archive(archive_path: Union[str, Path], extract_path: Union[str, Path]) -> bool:
    """
    Extract archive to directory.

    Args:
        archive_path: Path to archive file
        extract_path: Path to extract to

    Returns:
        True if successful, False otherwise
    """
    try:
        shutil.unpack_archive(str(archive_path), str(extract_path))
        return True
    except Exception:
        return False
