"""
Helper utilities for AIML platform.

Provides common helper functions for string manipulation, UUID generation,
file operations, and other utility functions.
"""

import hashlib
import random
import re
import string
import uuid
from typing import Any, List, Optional


def generate_uuid(version: int = 4) -> str:
    """
    Generate UUID string.

    Args:
        version: UUID version (1, 4, or 5)

    Returns:
        UUID string
    """
    if version == 1:
        return str(uuid.uuid1())
    elif version == 4:
        return str(uuid.uuid4())
    elif version == 5:
        # For UUID5, we need a namespace and name
        # Using a default namespace for simplicity
        namespace = uuid.NAMESPACE_DNS
        name = f"aiml-platform-{random.randint(1000, 9999)}"
        return str(uuid.uuid5(namespace, name))
    else:
        raise ValueError("Unsupported UUID version. Use 1, 4, or 5.")


def generate_random_string(
    length: int = 10,
    include_uppercase: bool = True,
    include_lowercase: bool = True,
    include_digits: bool = True,
    include_special: bool = False,
    special_chars: str = "!@#$%^&*",
) -> str:
    """
    Generate random string with specified characteristics.

    Args:
        length: Length of the string
        include_uppercase: Include uppercase letters
        include_lowercase: Include lowercase letters
        include_digits: Include digits
        include_special: Include special characters
        special_chars: Special characters to include

    Returns:
        Random string
    """
    if length <= 0:
        return ""

    characters = ""

    if include_uppercase:
        characters += string.ascii_uppercase
    if include_lowercase:
        characters += string.ascii_lowercase
    if include_digits:
        characters += string.digits
    if include_special:
        characters += special_chars

    if not characters:
        raise ValueError("At least one character type must be included")

    return "".join(random.choice(characters) for _ in range(length))


def sanitize_filename(filename: str, replacement: str = "_") -> str:
    """
    Sanitize filename by removing or replacing invalid characters.

    Args:
        filename: Original filename
        replacement: Character to replace invalid characters with

    Returns:
        Sanitized filename
    """
    if not filename:
        return "unnamed_file"

    # Remove or replace invalid characters
    invalid_chars = r'[<>:"/\\|?*\x00-\x1f]'
    sanitized = re.sub(invalid_chars, replacement, filename)

    # Remove leading/trailing dots and spaces
    sanitized = sanitized.strip(". ")

    # Handle reserved names on Windows
    reserved_names = {
        "CON",
        "PRN",
        "AUX",
        "NUL",
        "COM1",
        "COM2",
        "COM3",
        "COM4",
        "COM5",
        "COM6",
        "COM7",
        "COM8",
        "COM9",
        "LPT1",
        "LPT2",
        "LPT3",
        "LPT4",
        "LPT5",
        "LPT6",
        "LPT7",
        "LPT8",
        "LPT9",
    }

    name_part = sanitized.split(".")[0].upper()
    if name_part in reserved_names:
        sanitized = f"_{sanitized}"

    # Ensure filename is not empty
    if not sanitized:
        sanitized = "unnamed_file"

    # Limit length (most filesystems support 255 characters)
    if len(sanitized) > 255:
        name, ext = sanitized.rsplit(".", 1) if "." in sanitized else (sanitized, "")
        max_name_length = 255 - len(ext) - 1 if ext else 255
        sanitized = f"{name[:max_name_length]}.{ext}" if ext else name[:255]

    return sanitized


def slugify(text: str, separator: str = "-") -> str:
    """
    Convert text to URL-friendly slug.

    Args:
        text: Text to slugify
        separator: Separator character

    Returns:
        Slugified text
    """
    if not text:
        return ""

    # Convert to lowercase
    slug = text.lower()

    # Replace spaces and special characters with separator
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_-]+", separator, slug)

    # Remove leading/trailing separators
    slug = slug.strip(separator)

    return slug


def truncate_string(text: str, max_length: int, suffix: str = "...") -> str:
    """
    Truncate string to specified length with optional suffix.

    Args:
        text: Text to truncate
        max_length: Maximum length
        suffix: Suffix to add when truncating

    Returns:
        Truncated string
    """
    if not text or len(text) <= max_length:
        return text

    if len(suffix) >= max_length:
        return text[:max_length]

    return text[: max_length - len(suffix)] + suffix


def camel_to_snake(name: str) -> str:
    """
    Convert camelCase to snake_case.

    Args:
        name: CamelCase string

    Returns:
        snake_case string
    """
    # Insert underscore before uppercase letters
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def snake_to_camel(name: str, capitalize_first: bool = False) -> str:
    """
    Convert snake_case to camelCase.

    Args:
        name: snake_case string
        capitalize_first: Whether to capitalize the first letter

    Returns:
        camelCase string
    """
    components = name.split("_")
    if capitalize_first:
        return "".join(word.capitalize() for word in components)
    else:
        return components[0] + "".join(word.capitalize() for word in components[1:])


def deep_merge_dicts(dict1: dict, dict2: dict) -> dict:
    """
    Deep merge two dictionaries.

    Args:
        dict1: First dictionary
        dict2: Second dictionary

    Returns:
        Merged dictionary
    """
    result = dict1.copy()

    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge_dicts(result[key], value)
        else:
            result[key] = value

    return result


def flatten_dict(d: dict, parent_key: str = "", sep: str = ".") -> dict:
    """
    Flatten nested dictionary.

    Args:
        d: Dictionary to flatten
        parent_key: Parent key prefix
        sep: Separator for nested keys

    Returns:
        Flattened dictionary
    """
    items = []

    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k

        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep).items())
        else:
            items.append((new_key, v))

    return dict(items)


def unflatten_dict(d: dict, sep: str = ".") -> dict:
    """
    Unflatten dictionary with nested keys.

    Args:
        d: Flattened dictionary
        sep: Separator used in nested keys

    Returns:
        Nested dictionary
    """
    result = {}

    for key, value in d.items():
        keys = key.split(sep)
        current = result

        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]

        current[keys[-1]] = value

    return result


def chunk_list(lst: List, chunk_size: int) -> List[List]:
    """
    Split list into chunks of specified size.

    Args:
        lst: List to chunk
        chunk_size: Size of each chunk

    Returns:
        List of chunks
    """
    if chunk_size <= 0:
        raise ValueError("Chunk size must be positive")

    return [lst[i : i + chunk_size] for i in range(0, len(lst), chunk_size)]


def remove_duplicates(lst: List, key_func: Optional[callable] = None) -> List:
    """
    Remove duplicates from list while preserving order.

    Args:
        lst: List with potential duplicates
        key_func: Function to extract comparison key from items

    Returns:
        List without duplicates
    """
    seen = set()
    result = []

    for item in lst:
        key = key_func(item) if key_func else item

        if key not in seen:
            seen.add(key)
            result.append(item)

    return result


def safe_get(dictionary: dict, keys: str, default: Any = None, separator: str = ".") -> Any:
    """
    Safely get nested dictionary value using dot notation.

    Args:
        dictionary: Dictionary to search
        keys: Dot-separated key path
        default: Default value if key not found
        separator: Key separator

    Returns:
        Value or default
    """
    try:
        current = dictionary
        for key in keys.split(separator):
            current = current[key]
        return current
    except (KeyError, TypeError, AttributeError):
        return default


def safe_set(dictionary: dict, keys: str, value: Any, separator: str = ".") -> None:
    """
    Safely set nested dictionary value using dot notation.

    Args:
        dictionary: Dictionary to modify
        keys: Dot-separated key path
        value: Value to set
        separator: Key separator
    """
    key_list = keys.split(separator)
    current = dictionary

    for key in key_list[:-1]:
        if key not in current:
            current[key] = {}
        current = current[key]

    current[key_list[-1]] = value


def format_bytes(bytes_value: int, decimal_places: int = 2) -> str:
    """
    Format bytes as human-readable string.

    Args:
        bytes_value: Number of bytes
        decimal_places: Number of decimal places

    Returns:
        Formatted string (e.g., "1.23 MB")
    """
    if bytes_value == 0:
        return "0 B"

    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    unit_index = 0
    size = float(bytes_value)

    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024
        unit_index += 1

    return f"{size:.{decimal_places}f} {units[unit_index]}"


def calculate_hash(data: str, algorithm: str = "sha256") -> str:
    """
    Calculate hash of string data.

    Args:
        data: Data to hash
        algorithm: Hash algorithm ('md5', 'sha1', 'sha256', 'sha512')

    Returns:
        Hex digest of hash
    """
    if algorithm not in ["md5", "sha1", "sha256", "sha512"]:
        raise ValueError(f"Unsupported hash algorithm: {algorithm}")

    hash_func = getattr(hashlib, algorithm)
    return hash_func(data.encode("utf-8")).hexdigest()
