"""
Database manager for AIML platform.

Provides standardized database connection management, session handling,
connection pooling, and health monitoring.
"""

import time
from collections.abc import Generator
from contextlib import contextmanager
from typing import Any, Optional
from urllib.parse import urlparse

from sqlalchemy import create_engine, event, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, scoped_session, sessionmaker
from sqlalchemy.pool import NullPool, QueuePool

from ..logger import get_logger
from .exceptions import ConnectionError, DatabaseError, QueryError, TransactionError
from .models import Base


class DatabaseManager:
    """
    Database manager with connection pooling and session management.

    Features:
    - Connection pooling
    - Session management with context managers
    - Health monitoring
    - Multiple database support
    - Automatic reconnection
    - Performance monitoring
    """

    def __init__(
        self,
        database_url: str,
        pool_size: int = 10,
        max_overflow: int = 20,
        pool_timeout: int = 30,
        pool_recycle: int = 3600,
        echo: bool = False,
        echo_pool: bool = False,
    ):
        """
        Initialize database manager.

        Args:
            database_url: Database connection URL
            pool_size: Number of connections to maintain in pool
            max_overflow: Maximum overflow connections
            pool_timeout: Timeout for getting connection from pool
            pool_recycle: Time to recycle connections (seconds)
            echo: Enable SQL query logging
            echo_pool: Enable connection pool logging
        """
        self.database_url = database_url
        self.pool_size = pool_size
        self.max_overflow = max_overflow
        self.pool_timeout = pool_timeout
        self.pool_recycle = pool_recycle
        self.echo = echo
        self.echo_pool = echo_pool

        # Initialize logger
        self.logger = get_logger(__name__)

        # Connection statistics
        self._connection_stats = {
            "total_connections": 0,
            "active_connections": 0,
            "failed_connections": 0,
            "last_connection_time": None,
        }

        # Initialize engine and session factory
        self.engine = None
        self.session_factory = None
        self.scoped_session_factory = None

        self._initialize_engine()
        self._setup_event_listeners()

    def _initialize_engine(self):
        """Initialize SQLAlchemy engine with connection pooling."""
        try:
            # Parse database URL to determine database type
            parsed_url = urlparse(self.database_url)
            db_type = parsed_url.scheme.split("+")[0]

            # Configure engine based on database type
            engine_kwargs = {
                "echo": self.echo,
                "echo_pool": self.echo_pool,
            }

            # Configure connection pooling
            if db_type == "sqlite":
                # SQLite doesn't support connection pooling
                engine_kwargs["poolclass"] = NullPool
            else:
                engine_kwargs.update({
                    "poolclass": QueuePool,
                    "pool_size": self.pool_size,
                    "max_overflow": self.max_overflow,
                    "pool_timeout": self.pool_timeout,
                    "pool_recycle": self.pool_recycle,
                })

            # Add database-specific configurations
            if db_type == "postgresql":
                engine_kwargs["connect_args"] = {"connect_timeout": 10, "application_name": "aiml_platform"}
            elif db_type == "mysql":
                engine_kwargs["connect_args"] = {"connect_timeout": 10, "charset": "utf8mb4"}

            self.engine = create_engine(self.database_url, **engine_kwargs)

            # Create session factories
            self.session_factory = sessionmaker(bind=self.engine)
            self.scoped_session_factory = scoped_session(self.session_factory)

            self.logger.info(f"Initialized database engine for {db_type}")

        except Exception as e:
            self.logger.error(f"Failed to initialize database engine: {e!s}")
            raise ConnectionError(f"Failed to initialize database engine: {e!s}", e)

    def _setup_event_listeners(self):
        """Setup SQLAlchemy event listeners for monitoring."""

        @event.listens_for(self.engine, "connect")
        def on_connect(dbapi_connection, connection_record):
            """Handle new database connections."""
            self._connection_stats["total_connections"] += 1
            self._connection_stats["active_connections"] += 1
            self._connection_stats["last_connection_time"] = time.time()
            self.logger.debug("New database connection established")

        @event.listens_for(self.engine, "close")
        def on_close(dbapi_connection, connection_record):
            """Handle connection closure."""
            self._connection_stats["active_connections"] -= 1
            self.logger.debug("Database connection closed")

        @event.listens_for(self.engine, "close_detached")
        def on_close_detached(dbapi_connection):
            """Handle detached connection closure."""
            self._connection_stats["active_connections"] -= 1
            self.logger.debug("Detached database connection closed")

    @contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        """
        Get database session with automatic cleanup.

        Yields:
            SQLAlchemy session

        Raises:
            ConnectionError: If connection fails
            TransactionError: If transaction fails
        """
        session = None
        start_time = time.time()

        try:
            session = self.session_factory()
            self.logger.debug("Database session created")
            yield session
            session.commit()

        except SQLAlchemyError as e:
            if session:
                session.rollback()
            self.logger.error(f"Database session error: {e!s}")
            raise TransactionError(f"Database transaction failed: {e!s}", e)
        except Exception as e:
            if session:
                session.rollback()
            self.logger.error(f"Unexpected session error: {e!s}")
            raise DatabaseError(f"Unexpected database error: {e!s}", original_error=e)
        finally:
            if session:
                session.close()
                duration = time.time() - start_time
                self.logger.performance("database_session", duration)

    def get_scoped_session(self) -> Session:
        """
        Get thread-local scoped session.

        Returns:
            Scoped session instance
        """
        return self.scoped_session_factory()

    def remove_scoped_session(self):
        """Remove thread-local scoped session."""
        self.scoped_session_factory.remove()

    def execute_query(self, query: str, params: Optional[dict[str, Any]] = None) -> Any:
        """
        Execute raw SQL query.

        Args:
            query: SQL query string
            params: Query parameters

        Returns:
            Query result
        """
        start_time = time.time()

        try:
            with self.get_session() as session:
                result = session.execute(text(query), params or {})
                duration = time.time() - start_time
                self.logger.performance("execute_query", duration, query=query[:100])
                return result

        except Exception as e:
            self.logger.error(f"Query execution failed: {e!s}")
            raise QueryError(query, f"Query execution failed: {e!s}", e)

    def test_connection(self) -> bool:
        """
        Test database connection.

        Returns:
            True if connection is successful, False otherwise
        """
        try:
            with self.get_session() as session:
                session.execute(text("SELECT 1"))
            self.logger.info("Database connection test successful")
            return True
        except Exception as e:
            self.logger.error(f"Database connection test failed: {e!s}")
            self._connection_stats["failed_connections"] += 1
            return False

    def get_connection_stats(self) -> dict[str, Any]:
        """
        Get connection statistics.

        Returns:
            Dictionary with connection statistics
        """
        pool_stats = {}
        if hasattr(self.engine.pool, "size"):
            pool_stats.update({
                "pool_size": self.engine.pool.size(),
                "checked_in": self.engine.pool.checkedin(),
                "checked_out": self.engine.pool.checkedout(),
                "overflow": self.engine.pool.overflow(),
                "invalid": self.engine.pool.invalid(),
            })

        return {**self._connection_stats, **pool_stats, "database_url": self._mask_password(self.database_url)}

    def _mask_password(self, url: str) -> str:
        """Mask password in database URL for logging."""
        parsed = urlparse(url)
        if parsed.password:
            masked_netloc = parsed.netloc.replace(parsed.password, "***")
            return url.replace(parsed.netloc, masked_netloc)
        return url

    def create_tables(self, models: list = None):
        """
        Create database tables.

        Args:
            models: List of model classes to create tables for (optional)
        """
        try:
            if models:
                # Create tables for specific models
                for model in models:
                    model.__table__.create(self.engine, checkfirst=True)
            else:
                # Create all tables
                Base.metadata.create_all(self.engine)

            self.logger.info("Database tables created successfully")

        except Exception as e:
            self.logger.error(f"Failed to create database tables: {e!s}")
            raise DatabaseError(f"Failed to create database tables: {e!s}", original_error=e)

    def drop_tables(self, models: list = None):
        """
        Drop database tables.

        Args:
            models: List of model classes to drop tables for (optional)
        """
        try:
            if models:
                # Drop tables for specific models
                for model in models:
                    model.__table__.drop(self.engine, checkfirst=True)
            else:
                # Drop all tables
                Base.metadata.drop_all(self.engine)

            self.logger.info("Database tables dropped successfully")

        except Exception as e:
            self.logger.error(f"Failed to drop database tables: {e!s}")
            raise DatabaseError(f"Failed to drop database tables: {e!s}", original_error=e)

    def close(self):
        """Close database connections and cleanup resources."""
        try:
            if self.scoped_session_factory:
                self.scoped_session_factory.remove()

            if self.engine:
                self.engine.dispose()

            self.logger.info("Database manager closed successfully")

        except Exception as e:
            self.logger.error(f"Error closing database manager: {e!s}")

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
