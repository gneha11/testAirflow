"""
Base database models and mixins for AIML platform.

Provides common model functionality including timestamps, soft deletes,
and audit trails that can be inherited by application models.
"""

import uuid
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base, declared_attr
from sqlalchemy.orm import validates

# Base class for all models
Base = declarative_base()


class BaseModel(Base):
    """
    Abstract base model with common fields and functionality.

    Provides:
    - Primary key (id)
    - Created and updated timestamps
    - Common methods for serialization
    """

    __abstract__ = True

    id = Column(Integer, primary_key=True, autoincrement=True)

    def to_dict(self, exclude: Optional[list] = None) -> Dict[str, Any]:
        """
        Convert model instance to dictionary.

        Args:
            exclude: List of fields to exclude from dictionary

        Returns:
            Dictionary representation of the model
        """
        exclude = exclude or []
        result = {}

        for column in self.__table__.columns:
            if column.name not in exclude:
                value = getattr(self, column.name)
                # Handle datetime serialization
                if isinstance(value, datetime):
                    value = value.isoformat()
                # Handle UUID serialization
                elif isinstance(value, uuid.UUID):
                    value = str(value)
                result[column.name] = value

        return result

    def update_from_dict(self, data: Dict[str, Any], exclude: Optional[list] = None):
        """
        Update model instance from dictionary.

        Args:
            data: Dictionary with field values
            exclude: List of fields to exclude from update
        """
        exclude = exclude or ["id", "created_at"]

        for key, value in data.items():
            if key not in exclude and hasattr(self, key):
                setattr(self, key, value)

    def __repr__(self):
        return f"<{self.__class__.__name__}(id={self.id})>"


class TimestampMixin:
    """Mixin to add created_at and updated_at timestamps."""

    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)


class UUIDMixin:
    """Mixin to add UUID primary key instead of integer."""

    @declared_attr
    def id(cls):
        return Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)


class SoftDeleteMixin:
    """Mixin to add soft delete functionality."""

    is_deleted = Column(Boolean, default=False, nullable=False)
    deleted_at = Column(DateTime, nullable=True)

    def soft_delete(self):
        """Mark record as deleted."""
        self.is_deleted = True
        self.deleted_at = func.now()

    def restore(self):
        """Restore soft-deleted record."""
        self.is_deleted = False
        self.deleted_at = None


class AuditMixin:
    """Mixin to add audit trail fields."""

    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    def set_audit_fields(self, user_id: str, is_update: bool = False):
        """Set audit fields for create/update operations."""
        if is_update:
            self.updated_by = user_id
        else:
            self.created_by = user_id


class VersionMixin:
    """Mixin to add optimistic locking with version field."""

    version = Column(Integer, default=1, nullable=False)

    def increment_version(self):
        """Increment version for optimistic locking."""
        self.version += 1


class MetadataMixin:
    """Mixin to add flexible metadata storage."""

    metadata = Column(Text, nullable=True)  # Store JSON as text

    def set_metadata(self, data: Dict[str, Any]):
        """Set metadata as JSON string."""
        import json

        self.metadata = json.dumps(data) if data else None

    def get_metadata(self) -> Dict[str, Any]:
        """Get metadata as dictionary."""
        import json

        return json.loads(self.metadata) if self.metadata else {}


class FullAuditModel(BaseModel, TimestampMixin, SoftDeleteMixin, AuditMixin, VersionMixin):
    """
    Full-featured base model with all mixins.

    Includes:
    - Primary key
    - Timestamps (created_at, updated_at)
    - Soft delete (is_deleted, deleted_at)
    - Audit trail (created_by, updated_by)
    - Optimistic locking (version)
    """

    __abstract__ = True


class UUIDModel(Base, UUIDMixin, TimestampMixin):
    """Base model with UUID primary key and timestamps."""

    __abstract__ = True

    def to_dict(self, exclude: list = None) -> Dict[str, Any]:
        """Convert model instance to dictionary."""
        exclude = exclude or []
        result = {}

        for column in self.__table__.columns:
            if column.name not in exclude:
                value = getattr(self, column.name)
                # Handle datetime serialization
                if isinstance(value, datetime):
                    value = value.isoformat()
                # Handle UUID serialization
                elif isinstance(value, uuid.UUID):
                    value = str(value)
                result[column.name] = value

        return result

    def __repr__(self):
        return f"<{self.__class__.__name__}(id={self.id})>"


# Example model demonstrating usage
class ExampleModel(FullAuditModel):
    """Example model showing how to use the base classes."""

    __tablename__ = "examples"

    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String(50), default="active", nullable=False)

    @validates("status")
    def validate_status(self, key, status):
        """Validate status field."""
        allowed_statuses = ["active", "inactive", "pending"]
        if status not in allowed_statuses:
            raise ValueError(f"Status must be one of {allowed_statuses}")
        return status

    @validates("name")
    def validate_name(self, key, name):
        """Validate name field."""
        if not name or len(name.strip()) == 0:
            raise ValueError("Name cannot be empty")
        if len(name) > 255:
            raise ValueError("Name cannot exceed 255 characters")
        return name.strip()
