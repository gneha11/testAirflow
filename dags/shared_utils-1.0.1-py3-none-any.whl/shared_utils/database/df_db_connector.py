"""
Database Connector Module for Data Foundation package.

This module provides database connection functionality with validation
and smart config extraction. It is independent of config loading.
"""

import logging
from contextlib import contextmanager
from typing import Dict, List, Any, Optional, Union
import psycopg2
from psycopg2.extras import RealDictCursor
from azure.cosmos import CosmosClient, PartitionKey
from pymongo import MongoClient


class DFDatabaseManager:
    """
    Database manager for creating connections to various database types.
    
    Provides validation and smart config extraction for Postgres, Cosmos DB, and MongoDB.
    """
    
    # Required keys for each database type
    POSTGRES_KEYS = ["host", "port", "dbname", "user", "password", "schema"]
    COSMOS_KEYS = ["COSMOS_URL", "COSMOS_KEY", "DATABASE_ID", "CONTAINER_ID"]
    MONGO_KEYS = ["MONGO_URI", "MONGO_DB", "MONGO_COLLECTION"]
    
    def __init__(self, logger_instance: Optional[logging.Logger] = None):
        """
        Initialize the database manager.
        
        Args:
            logger_instance: Logger instance for logging. If None, creates a basic logger.
        """
        self.logger = logger_instance or self._create_basic_logger()
    
    def _create_basic_logger(self) -> logging.Logger:
        """
        Create a basic logger if none provided.
        
        Returns:
            Basic logger instance
        """
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def _validate_config_keys(self, config: Dict[str, str], required_keys: List[str], db_type: str) -> None:
        """
        Validate that all required keys are present in the configuration.
        
        Args:
            config: Configuration dictionary to validate
            required_keys: List of required keys
            db_type: Type of database for error messages
            
        Raises:
            ValueError: If any required keys are missing
        """
        missing_keys = [key for key in required_keys if key not in config]
        if missing_keys:
            raise ValueError(f"Missing required {db_type} configuration keys: {missing_keys}")
    
    def df_get_postgres_connection(self, postgres_config: Dict[str, str]):
        """
        Create a fresh Postgres connection with validation.
        
        Args:
            postgres_config: Postgres configuration dictionary containing:
                host, port, dbname, user, password, schema
                
        Returns:
            Postgres connection object
            
        Raises:
            ValueError: If required configuration keys are missing
            Exception: If connection fails
        """
        self._validate_config_keys(postgres_config, self.POSTGRES_KEYS, "postgres")
        
        # Extract connection parameters
        host = postgres_config["host"]
        port = postgres_config["port"]
        dbname = postgres_config["dbname"]
        user = postgres_config["user"]
        password = postgres_config["password"]
        schema = postgres_config["schema"]
        
        self.logger.info(f"🔌 Creating fresh Postgres connection to {host}:{port}/{dbname}")
        
        try:
            # Create fresh connection
            conn = psycopg2.connect(
                host=host,
                port=port,
                dbname=dbname,
                user=user,
                password=password,
                cursor_factory=RealDictCursor
            )
            
            # Set autocommit to True to avoid transaction issues
            conn.autocommit = True
            
            # Set schema
            with conn.cursor() as cursor:
                cursor.execute(f"SET search_path TO {schema}")
            
            self.logger.info("✅ Postgres connection created successfully")
            return conn
            
        except Exception as e:
            self.logger.error(f"❌ Postgres connection failed: {e}")
            raise
    
    def df_get_cosmos_container(self, cosmos_config: Dict[str, str]):
        """
        Create a fresh Cosmos DB container connection with validation.
        
        Args:
            cosmos_config: Cosmos DB configuration dictionary containing:
                COSMOS_URL, COSMOS_KEY, DATABASE_ID, CONTAINER_ID
                
        Returns:
            Cosmos DB container client
            
        Raises:
            ValueError: If required configuration keys are missing
            Exception: If connection fails
        """
        self._validate_config_keys(cosmos_config, self.COSMOS_KEYS, "cosmos")
        
        # Extract connection parameters
        cosmos_url = cosmos_config["COSMOS_URL"]
        cosmos_key = cosmos_config["COSMOS_KEY"]
        database_id = cosmos_config["DATABASE_ID"]
        container_id = cosmos_config["CONTAINER_ID"]
        
        self.logger.info(f"🔌 Creating fresh Cosmos DB connection to {cosmos_url}")
        
        try:
            # Create fresh client
            client = CosmosClient(cosmos_url, {'masterKey': cosmos_key})
            database = client.get_database_client(database_id)
            container = database.get_container_client(container_id)
            
            self.logger.info("✅ Cosmos DB container connection created successfully")
            return container
            
        except Exception as e:
            self.logger.error(f"❌ Cosmos DB connection failed: {e}")
            raise
    
    def df_get_mongodb_collection(self, mongo_config: Dict[str, str]):
        """
        Create a fresh MongoDB collection connection with validation.
        
        Args:
            mongo_config: MongoDB configuration dictionary containing:
                MONGO_URI, MONGO_DB, MONGO_COLLECTION
                
        Returns:
            MongoDB collection client
            
        Raises:
            ValueError: If required configuration keys are missing
            Exception: If connection fails
        """
        self._validate_config_keys(mongo_config, self.MONGO_KEYS, "mongo")
        
        # Extract connection parameters
        mongo_uri = mongo_config["MONGO_URI"]
        database_name = mongo_config["MONGO_DB"]
        collection_name = mongo_config["MONGO_COLLECTION"]
        
        self.logger.info(f"🔌 Creating fresh MongoDB connection to {database_name}.{collection_name}")
        
        try:
            # Create fresh client
            client = MongoClient(mongo_uri)
            database = client[database_name]
            collection = database[collection_name]
            
            self.logger.info("✅ MongoDB collection connection created successfully")
            return collection
            
        except Exception as e:
            self.logger.error(f"❌ MongoDB connection failed: {e}")
            raise


# Convenience functions for direct access
def df_get_postgres_connection(config: Dict[str, Any], logger_instance: Optional[logging.Logger] = None):
    """
    Create Postgres connection object.
    
    Automatically extracts postgres section from config.
    
    Args:
        config: Full configuration dictionary containing postgres section
        logger_instance: Logger instance (optional)
        
    Returns:
        Postgres connection object
        
    Raises:
        ValueError: If postgres section is missing or invalid
        Exception: If connection fails
    """
    if "postgres" not in config:
        raise ValueError("Configuration must contain 'postgres' section")
    
    manager = DFDatabaseManager(logger_instance)
    return manager.df_get_postgres_connection(config["postgres"])


def df_get_cosmos_container(config: Dict[str, Any], logger_instance: Optional[logging.Logger] = None):
    """
    Create Cosmos DB container connection.
    
    Automatically extracts cosmos section from config.
    
    Args:
        config: Full configuration dictionary containing cosmos section
        logger_instance: Logger instance (optional)
        
    Returns:
        Cosmos DB container client
        
    Raises:
        ValueError: If cosmos section is missing or invalid
        Exception: If connection fails
    """
    if "cosmos" not in config:
        raise ValueError("Configuration must contain 'cosmos' section")
    
    manager = DFDatabaseManager(logger_instance)
    return manager.df_get_cosmos_container(config["cosmos"])


def df_get_mongodb_collection(config: Dict[str, Any], logger_instance: Optional[logging.Logger] = None):
    """
    Create MongoDB collection connection.
    
    Automatically extracts mongo section from config.
    
    Args:
        config: Full configuration dictionary containing mongo section
        logger_instance: Logger instance (optional)
        
    Returns:
        MongoDB collection client
        
    Raises:
        ValueError: If mongo section is missing or invalid
        Exception: If connection fails
    """
    if "mongo" not in config:
        raise ValueError("Configuration must contain 'mongo' section")
    
    manager = DFDatabaseManager(logger_instance)
    return manager.df_get_mongodb_collection(config["mongo"]) 