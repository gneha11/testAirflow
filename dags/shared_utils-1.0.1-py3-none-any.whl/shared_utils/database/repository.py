"""
Base repository classes for AIML platform.

Provides standardized CRUD operations, query building, and data access patterns
that can be inherited by application-specific repositories.
"""

import time
from typing import Any, List, Optional, Tuple, Type, Union

from sqlalchemy import asc, desc, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Query, Session

from ..logger import get_logger
from .exceptions import DatabaseError, DuplicateRecordError, QueryError, RecordNotFoundError
from .models import BaseModel


class BaseRepository:
    """
    Base repository class providing standard CRUD operations.

    Features:
    - Standard CRUD operations
    - Query building utilities
    - Pagination support
    - Bulk operations
    - Soft delete support
    - Performance monitoring
    """

    def __init__(self, model: Type[BaseModel], session: Session):
        """
        Initialize repository.

        Args:
            model: SQLAlchemy model class
            session: Database session
        """
        self.model = model
        self.session = session
        self.logger = get_logger(f"{__name__}.{model.__name__}Repository")

    def create(self, data: dict[str, Any], commit: bool = True) -> BaseModel:
        """
        Create a new record.

        Args:
            data: Dictionary with field values
            commit: Whether to commit the transaction

        Returns:
            Created model instance

        Raises:
            DuplicateRecordError: If record already exists
            ValidationError: If data validation fails
        """
        start_time = time.time()

        try:
            instance = self.model(**data)
            self.session.add(instance)

            if commit:
                self.session.commit()
                self.session.refresh(instance)

            duration = time.time() - start_time
            self.logger.performance("create", duration, model=self.model.__name__)
            self.logger.info(f"Created {self.model.__name__} with id: {instance.id}")

            return instance

        except IntegrityError as e:
            self.session.rollback()
            self.logger.error(f"Integrity error creating {self.model.__name__}: {e!s}")
            raise DuplicateRecordError(self.model.__name__)
        except Exception as e:
            self.session.rollback()
            self.logger.error(f"Error creating {self.model.__name__}: {e!s}")
            raise DatabaseError(f"Failed to create {self.model.__name__}: {e!s}", original_error=e)

    def get_by_id(self, id: Union[int, str]) -> Optional[BaseModel]:
        """
        Get record by ID.

        Args:
            id: Record ID

        Returns:
            Model instance or None if not found
        """
        start_time = time.time()

        try:
            instance = self.session.query(self.model).filter(self.model.id == id).first()

            duration = time.time() - start_time
            self.logger.performance("get_by_id", duration, model=self.model.__name__)

            return instance

        except Exception as e:
            self.logger.error(f"Error getting {self.model.__name__} by id {id}: {e!s}")
            raise QueryError(f"Failed to get {self.model.__name__} by id: {e!s}", original_error=e)

    def get_by_id_or_raise(self, id: Union[int, str]) -> BaseModel:
        """
        Get record by ID or raise exception if not found.

        Args:
            id: Record ID

        Returns:
            Model instance

        Raises:
            RecordNotFoundError: If record is not found
        """
        instance = self.get_by_id(id)
        if instance is None:
            raise RecordNotFoundError(self.model.__name__, str(id))
        return instance

    def get_by_field(self, field: str, value: Any) -> Optional[BaseModel]:
        """
        Get record by field value.

        Args:
            field: Field name
            value: Field value

        Returns:
            Model instance or None if not found
        """
        start_time = time.time()

        try:
            instance = self.session.query(self.model).filter(getattr(self.model, field) == value).first()

            duration = time.time() - start_time
            self.logger.performance("get_by_field", duration, model=self.model.__name__, field=field)

            return instance

        except Exception as e:
            self.logger.error(f"Error getting {self.model.__name__} by {field}: {e!s}")
            raise QueryError(f"Failed to get {self.model.__name__} by {field}: {e!s}", original_error=e)

    def get_all(self, limit: int = None, offset: int = None) -> List[BaseModel]:
        """
        Get all records with optional pagination.

        Args:
            limit: Maximum number of records to return
            offset: Number of records to skip

        Returns:
            List of model instances
        """
        start_time = time.time()

        try:
            query = self.session.query(self.model)

            if offset:
                query = query.offset(offset)
            if limit:
                query = query.limit(limit)

            instances = query.all()

            duration = time.time() - start_time
            self.logger.performance("get_all", duration, model=self.model.__name__, count=len(instances))

            return instances

        except Exception as e:
            self.logger.error(f"Error getting all {self.model.__name__}: {e!s}")
            raise QueryError(f"Failed to get all {self.model.__name__}: {e!s}", original_error=e)

    def update(self, id: Union[int, str], data: dict[str, Any], commit: bool = True) -> BaseModel:
        """
        Update record by ID.

        Args:
            id: Record ID
            data: Dictionary with field values to update
            commit: Whether to commit the transaction

        Returns:
            Updated model instance

        Raises:
            RecordNotFoundError: If record is not found
        """
        start_time = time.time()

        try:
            instance = self.get_by_id_or_raise(id)

            # Update fields
            for key, value in data.items():
                if hasattr(instance, key):
                    setattr(instance, key, value)

            if commit:
                self.session.commit()
                self.session.refresh(instance)

            duration = time.time() - start_time
            self.logger.performance("update", duration, model=self.model.__name__)
            self.logger.info(f"Updated {self.model.__name__} with id: {id}")

            return instance

        except RecordNotFoundError:
            raise
        except IntegrityError as e:
            self.session.rollback()
            self.logger.error(f"Integrity error updating {self.model.__name__}: {e!s}")
            raise DuplicateRecordError(self.model.__name__)
        except Exception as e:
            self.session.rollback()
            self.logger.error(f"Error updating {self.model.__name__}: {e!s}")
            raise DatabaseError(f"Failed to update {self.model.__name__}: {e!s}", original_error=e)

    def delete(self, id: Union[int, str], commit: bool = True) -> bool:
        """
        Delete record by ID.

        Args:
            id: Record ID
            commit: Whether to commit the transaction

        Returns:
            True if record was deleted, False if not found
        """
        start_time = time.time()

        try:
            instance = self.get_by_id(id)
            if instance is None:
                return False

            # Check if model supports soft delete
            if hasattr(instance, "soft_delete"):
                instance.soft_delete()
            else:
                self.session.delete(instance)

            if commit:
                self.session.commit()

            duration = time.time() - start_time
            self.logger.performance("delete", duration, model=self.model.__name__)
            self.logger.info(f"Deleted {self.model.__name__} with id: {id}")

            return True

        except Exception as e:
            self.session.rollback()
            self.logger.error(f"Error deleting {self.model.__name__}: {e!s}")
            raise DatabaseError(f"Failed to delete {self.model.__name__}: {e!s}", original_error=e)

    def count(self, filters: Optional[dict[str, Any]] = None) -> int:
        """
        Count records with optional filters.

        Args:
            filters: Dictionary with filter conditions

        Returns:
            Number of matching records
        """
        try:
            query = self.session.query(func.count(self.model.id))

            if filters:
                query = self._apply_filters(query, filters)

            return query.scalar()

        except Exception as e:
            self.logger.error(f"Error counting {self.model.__name__}: {e!s}")
            raise QueryError(f"Failed to count {self.model.__name__}: {e!s}", original_error=e)

    def exists(self, id: Union[int, str]) -> bool:
        """
        Check if record exists by ID.

        Args:
            id: Record ID

        Returns:
            True if record exists, False otherwise
        """
        try:
            return self.session.query(self.session.query(self.model).filter(self.model.id == id).exists()).scalar()

        except Exception as e:
            self.logger.error(f"Error checking existence of {self.model.__name__}: {e!s}")
            raise QueryError(f"Failed to check existence: {e!s}", original_error=e)

    def find(
        self,
        filters: Optional[dict[str, Any]] = None,
        order_by: Optional[str] = None,
        order_desc: bool = False,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> List[BaseModel]:
        """
        Find records with filters and sorting.

        Args:
            filters: Dictionary with filter conditions
            order_by: Field name to order by
            order_desc: Whether to order in descending order
            limit: Maximum number of records to return
            offset: Number of records to skip

        Returns:
            List of matching model instances
        """
        start_time = time.time()

        try:
            query = self.session.query(self.model)

            # Apply filters
            if filters:
                query = self._apply_filters(query, filters)

            # Apply ordering
            if order_by and hasattr(self.model, order_by):
                field = getattr(self.model, order_by)
                if order_desc:
                    query = query.order_by(desc(field))
                else:
                    query = query.order_by(asc(field))

            # Apply pagination
            if offset:
                query = query.offset(offset)
            if limit:
                query = query.limit(limit)

            instances = query.all()

            duration = time.time() - start_time
            self.logger.performance("find", duration, model=self.model.__name__, count=len(instances))

            return instances

        except Exception as e:
            self.logger.error(f"Error finding {self.model.__name__}: {e!s}")
            raise QueryError(f"Failed to find {self.model.__name__}: {e!s}", original_error=e)

    def paginate(
        self,
        page: int = 1,
        per_page: int = 20,
        filters: Optional[dict[str, Any]] = None,
        order_by: Optional[str] = None,
        order_desc: bool = False,
    ) -> Tuple[List[BaseModel], int, int]:
        """
        Paginate records.

        Args:
            page: Page number (1-based)
            per_page: Records per page
            filters: Dictionary with filter conditions
            order_by: Field name to order by
            order_desc: Whether to order in descending order

        Returns:
            Tuple of (records, total_count, total_pages)
        """
        try:
            # Calculate offset
            offset = (page - 1) * per_page

            # Get total count
            total_count = self.count(filters)
            total_pages = (total_count + per_page - 1) // per_page

            # Get records
            records = self.find(
                filters=filters, order_by=order_by, order_desc=order_desc, limit=per_page, offset=offset
            )

            return records, total_count, total_pages

        except Exception as e:
            self.logger.error(f"Error paginating {self.model.__name__}: {e!s}")
            raise QueryError(f"Failed to paginate {self.model.__name__}: {e!s}", original_error=e)

    def bulk_create(self, data_list: List[dict[str, Any]], commit: bool = True) -> List[BaseModel]:
        """
        Create multiple records in bulk.

        Args:
            data_list: List of dictionaries with field values
            commit: Whether to commit the transaction

        Returns:
            List of created model instances
        """
        start_time = time.time()

        try:
            instances = [self.model(**data) for data in data_list]
            self.session.add_all(instances)

            if commit:
                self.session.commit()
                for instance in instances:
                    self.session.refresh(instance)

            duration = time.time() - start_time
            self.logger.performance("bulk_create", duration, model=self.model.__name__, count=len(instances))
            self.logger.info(f"Bulk created {len(instances)} {self.model.__name__} records")

            return instances

        except Exception as e:
            self.session.rollback()
            self.logger.error(f"Error bulk creating {self.model.__name__}: {e!s}")
            raise DatabaseError(f"Failed to bulk create {self.model.__name__}: {e!s}", original_error=e)

    def _apply_filters(self, query: Query, filters: dict[str, Any]) -> Query:
        """
        Apply filters to query.

        Args:
            query: SQLAlchemy query
            filters: Dictionary with filter conditions

        Returns:
            Filtered query
        """
        for field, value in filters.items():
            if hasattr(self.model, field):
                if isinstance(value, dict):
                    # Handle complex filters like {'gt': 10}, {'in': [1, 2, 3]}
                    for operator, operand in value.items():
                        field_attr = getattr(self.model, field)
                        if operator == "gt":
                            query = query.filter(field_attr > operand)
                        elif operator == "gte":
                            query = query.filter(field_attr >= operand)
                        elif operator == "lt":
                            query = query.filter(field_attr < operand)
                        elif operator == "lte":
                            query = query.filter(field_attr <= operand)
                        elif operator == "in":
                            query = query.filter(field_attr.in_(operand))
                        elif operator == "like":
                            query = query.filter(field_attr.like(operand))
                        elif operator == "ilike":
                            query = query.filter(field_attr.ilike(operand))
                else:
                    # Simple equality filter
                    query = query.filter(getattr(self.model, field) == value)

        return query


class AsyncBaseRepository:
    """
    Async version of BaseRepository for async/await operations.

    Note: This is a placeholder for future async implementation.
    Requires async SQLAlchemy setup and async session management.
    """

    def __init__(self, model: Type[BaseModel], session):
        """Initialize async repository."""
        self.model = model
        self.session = session
        self.logger = get_logger(f"{__name__}.Async{model.__name__}Repository")

    async def create(self, data: dict[str, Any]) -> BaseModel:
        """Async create operation."""
        # Placeholder for async implementation
        raise NotImplementedError("Async repository operations not yet implemented")

    async def get_by_id(self, id: Union[int, str]) -> Optional[BaseModel]:
        """Async get by ID operation."""
        # Placeholder for async implementation
        raise NotImplementedError("Async repository operations not yet implemented")
