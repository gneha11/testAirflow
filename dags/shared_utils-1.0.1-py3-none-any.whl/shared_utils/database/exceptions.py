"""
Custom exceptions for database operations.

Provides specific exception types for different database error scenarios
to enable proper error handling in client applications.
"""


class DatabaseError(Exception):
    """Base exception for database operations."""

    def __init__(self, message: str, error_code: str = None, original_error: Exception = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.original_error = original_error


class ConnectionError(DatabaseError):
    """Exception raised when database connection fails."""

    def __init__(self, message: str = "Failed to connect to database", original_error: Exception = None):
        super().__init__(message, "CONNECTION_FAILED", original_error)


class QueryError(DatabaseError):
    """Exception raised when a database query fails."""

    def __init__(self, query: str = None, message: str = "Database query failed", original_error: Exception = None):
        super().__init__(message, "QUERY_FAILED", original_error)
        self.query = query


class TransactionError(DatabaseError):
    """Exception raised when a database transaction fails."""

    def __init__(self, message: str = "Database transaction failed", original_error: Exception = None):
        super().__init__(message, "TRANSACTION_FAILED", original_error)


class ValidationError(DatabaseError):
    """Exception raised when data validation fails."""

    def __init__(self, field: str, message: str, original_error: Exception = None):
        full_message = f"Validation error for field '{field}': {message}"
        super().__init__(full_message, "VALIDATION_FAILED", original_error)
        self.field = field


class RecordNotFoundError(DatabaseError):
    """Exception raised when a database record is not found."""

    def __init__(self, model_name: str, identifier: str = None):
        message = f"Record not found in {model_name}"
        if identifier:
            message += f" with identifier: {identifier}"
        super().__init__(message, "RECORD_NOT_FOUND")
        self.model_name = model_name
        self.identifier = identifier


class DuplicateRecordError(DatabaseError):
    """Exception raised when attempting to create a duplicate record."""

    def __init__(self, model_name: str, field: str = None, value: str = None):
        message = f"Duplicate record in {model_name}"
        if field and value:
            message += f" for {field}: {value}"
        super().__init__(message, "DUPLICATE_RECORD")
        self.model_name = model_name
        self.field = field
        self.value = value


class MigrationError(DatabaseError):
    """Exception raised when database migration fails."""

    def __init__(self, message: str = "Database migration failed", original_error: Exception = None):
        super().__init__(message, "MIGRATION_FAILED", original_error)
