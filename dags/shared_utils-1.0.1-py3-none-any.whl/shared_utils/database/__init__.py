"""
Database utilities for AIML platform modules.

Provides standardized SQLAlchemy database connections, session management,
and base repository classes for CRUD operations.
"""

from .exceptions import ConnectionError, DatabaseError, QueryError
from .manager import DatabaseManager
from .models import (
    AuditMixin,
    BaseModel,
    FullAuditModel,
    MetadataMixin,
    SoftDeleteMixin,
    TimestampMixin,
    UUIDModel,
    VersionMixin,
)
from .repository import AsyncBaseRepository, BaseRepository
from .df_db_connector import (
    DFDatabaseManager,
    df_get_postgres_connection,
    df_get_cosmos_container,
    df_get_mongodb_collection,
)

__all__ = [
    "AsyncBaseRepository",
    "AuditMixin",
    "BaseModel",
    "BaseRepository",
    "ConnectionError",
    "DatabaseError",
    "DatabaseManager",
    "FullAuditModel",
    "MetadataMixin",
    "QueryError",
    "SoftDeleteMixin",
    "TimestampMixin",
    "UUIDModel",
    "VersionMixin",
    # Data Foundation specific database functions and class
    "DFDatabaseManager",
    "df_get_postgres_connection",
    "df_get_cosmos_container",
    "df_get_mongodb_collection",
]
