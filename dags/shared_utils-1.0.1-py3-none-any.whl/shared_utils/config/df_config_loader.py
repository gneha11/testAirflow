"""
Configuration loader for Data Foundation package.

This module provides a unified configuration loading mechanism that reads
a JSON configuration file and validates that all required sections and keys are present.

All functions are prefixed with 'df_' to identify them as Data Foundation specific functions.
"""

import json
import logging
from typing import Dict, Any, Optional


class DFConfigLoader:
    """
    Data Foundation Configuration Loader class.
    
    This class provides configuration loading and validation capabilities
    for Data Foundation operations.
    """
    
    def __init__(self):
        """Initialize the DFConfigLoader with required sections and keys."""
        # Development list - finalize this as you complete development
        self.REQUIRED_SECTIONS = [
            "cosmos",      # Asset hierarchy
            "mongo",       # Telemetry ingestion  
            "postgres",    # Checkpoints
            "adls",        # Telemetry ingestion
        ]

        # Required keys for each section
        self.REQUIRED_KEYS = {
            "cosmos": ["COSMOS_URL", "COSMOS_KEY", "DATABASE_ID", "CONTAINER_ID"],
            "mongo": ["MONGO_URI", "MONGO_DB", "MONGO_COLLECTION"],
            "postgres": ["host", "port", "dbname", "user", "password", "schema"],
            "adls": ["ACCOUNT_NAME", "ACCOUNT_URL", "CREDENTIAL", "sensorType_mappings"]
        }

        # Required keys for sensor type mappings
        self.SENSOR_MAPPING_KEYS = ["container", "data_categories", "path_template"]
    
    def load_config(self, config_path: str, logger_instance: Optional[logging.Logger] = None) -> Dict[str, Any]:
        """
        Load configuration file and validate required sections and keys.
        
        Args:
            config_path: Path to the configuration JSON file (required)
            logger_instance: Logger instance (optional, creates basic logger if not provided)
            
        Returns:
            Complete configuration dictionary with all sections
            
        Raises:
            ValueError: If config file is missing, invalid JSON, missing required sections, or missing required keys
            
        Example:
            >>> df_config_loader = DFConfigLoader()
            >>> config = df_config_loader.load_config("/lakehouse/default/Files/env/app_config.json")
            >>> cosmos_config = config["cosmos"]
            >>> adls_config = config["adls"]
        """
        logger = logger_instance or self._create_basic_logger()
        
        try:
            logger.info(f"📄 Loading configuration from: {config_path}")
            with open(config_path, 'r') as f:
                config = json.load(f)
            logger.info("✅ Configuration file loaded successfully")
        except FileNotFoundError:
            error_msg = f"Configuration file not found: {config_path}"
            logger.error(f"❌ {error_msg}")
            raise ValueError(error_msg)
        except json.JSONDecodeError as e:
            error_msg = f"Invalid JSON in configuration file {config_path}: {e}"
            logger.error(f"❌ {error_msg}")
            raise ValueError(error_msg)
        
        # Validate required sections and keys
        self._validate_config(config, logger)
        
        logger.info("✅ Configuration validation completed successfully")
        return config

    def _create_basic_logger(self) -> logging.Logger:
        """
        Create a basic logger instance.
        
        Returns:
            Basic logger instance
        """
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger

    def _validate_config(self, config: Dict[str, Any], logger: logging.Logger) -> None:
        """
        Validate that all required sections and keys are present in the configuration.
        
        Args:
            config: Configuration dictionary to validate
            logger: Logger instance for validation messages
            
        Raises:
            ValueError: If any required sections or keys are missing
        """
        logger.info("🔍 Starting configuration validation...")
        missing_sections = []
        missing_keys = {}
        missing_sensor_keys = {}
        
        # Check for missing sections
        for section in self.REQUIRED_SECTIONS:
            if section not in config:
                missing_sections.append(section)
                logger.warning(f"⚠️ Missing required section: {section}")
            else:
                logger.info(f"✅ Found section: {section}")
                # Check for missing keys within the section
                section_keys = self.REQUIRED_KEYS.get(section, [])
                missing_keys_in_section = []
                
                for key in section_keys:
                    if key not in config[section]:
                        missing_keys_in_section.append(key)
                
                if missing_keys_in_section:
                    missing_keys[section] = missing_keys_in_section
                    logger.warning(f"⚠️ Missing keys in '{section}' section: {missing_keys_in_section}")
                else:
                    logger.info(f"✅ All required keys present in '{section}' section")
                
                # Special validation for ADLS sensorType_mappings
                if section == "adls" and "sensorType_mappings" in config[section]:
                    logger.info("🔍 Validating ADLS sensorType_mappings...")
                    sensor_mappings = config[section]["sensorType_mappings"]
                    if isinstance(sensor_mappings, dict):
                        for sensor_type, mapping in sensor_mappings.items():
                            if not isinstance(mapping, dict):
                                missing_sensor_keys[sensor_type] = ["Invalid mapping structure"]
                                logger.warning(f"⚠️ Invalid mapping structure for sensor type: {sensor_type}")
                            else:
                                missing_keys_in_mapping = []
                                for required_key in self.SENSOR_MAPPING_KEYS:
                                    if required_key not in mapping:
                                        missing_keys_in_mapping.append(required_key)
                                if missing_keys_in_mapping:
                                    missing_sensor_keys[sensor_type] = missing_keys_in_mapping
                                    logger.warning(f"⚠️ Missing keys in '{sensor_type}' mapping: {missing_keys_in_mapping}")
                                else:
                                    logger.info(f"✅ Sensor mapping '{sensor_type}' validation passed")
                    else:
                        missing_sensor_keys["sensorType_mappings"] = ["Not a dictionary"]
                        logger.warning("⚠️ sensorType_mappings is not a dictionary")
        
        # Build error messages
        error_messages = []
        
        if missing_sections:
            error_messages.append(f"Missing required sections: {missing_sections}")
        
        for section, keys in missing_keys.items():
            error_messages.append(f"Missing required keys in '{section}' section: {keys}")
        
        for sensor_type, keys in missing_sensor_keys.items():
            error_messages.append(f"Missing required keys in '{sensor_type}' sensor mapping: {keys}")
        
        if error_messages:
            error_msg = "Configuration validation failed:\n" + "\n".join(f"  - {msg}" for msg in error_messages)
            logger.error(f"❌ {error_msg}")
            raise ValueError(error_msg)
        
        logger.info("✅ Configuration validation passed")


# Global instance for backward compatibility
_df_config_loader_instance = DFConfigLoader()


# Backward compatibility functions - these maintain the exact same functionality
def df_load_config(config_path: str, logger_instance: Optional[logging.Logger] = None) -> Dict[str, Any]:
    """
    Load configuration file and validate required sections and keys.
    
    Args:
        config_path: Path to the configuration JSON file (required)
        logger_instance: Logger instance (optional, creates basic logger if not provided)
        
    Returns:
        Complete configuration dictionary with all sections
        
    Raises:
        ValueError: If config file is missing, invalid JSON, missing required sections, or missing required keys
        
    Example:
        >>> config = df_load_config("/lakehouse/default/Files/env/app_config.json")
        >>> cosmos_config = config["cosmos"]
        >>> adls_config = config["adls"]
    """
    return _df_config_loader_instance.load_config(config_path, logger_instance)


# Constants for backward compatibility
REQUIRED_SECTIONS = _df_config_loader_instance.REQUIRED_SECTIONS
REQUIRED_KEYS = _df_config_loader_instance.REQUIRED_KEYS
SENSOR_MAPPING_KEYS = _df_config_loader_instance.SENSOR_MAPPING_KEYS 