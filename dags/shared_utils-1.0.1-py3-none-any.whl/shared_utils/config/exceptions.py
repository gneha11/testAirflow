"""
Custom exceptions for configuration management.

Provides specific exception types for different configuration error scenarios
to enable proper error handling in client applications.
"""


class ConfigError(Exception):
    """Base exception for configuration operations."""

    def __init__(self, message: str, error_code: str = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code


class ConfigNotFoundError(ConfigError):
    """Exception raised when a configuration key is not found."""

    def __init__(self, key: str, source: str = None):
        message = f"Configuration key '{key}' not found"
        if source:
            message += f" in {source}"
        super().__init__(message, "CONFIG_NOT_FOUND")
        self.key = key
        self.source = source


class ConfigValidationError(ConfigError):
    """Exception raised when configuration validation fails."""

    def __init__(self, key: str, value: str, expected_type: str = None, message: str = None):
        if message:
            full_message = f"Configuration validation error for '{key}': {message}"
        else:
            full_message = f"Invalid value for configuration key '{key}': {value}"
            if expected_type:
                full_message += f" (expected {expected_type})"

        super().__init__(full_message, "CONFIG_VALIDATION_ERROR")
        self.key = key
        self.value = value
        self.expected_type = expected_type


class ConfigFileError(ConfigError):
    """Exception raised when configuration file operations fail."""

    def __init__(self, file_path: str, message: str = "Configuration file error"):
        full_message = f"{message}: {file_path}"
        super().__init__(full_message, "CONFIG_FILE_ERROR")
        self.file_path = file_path


class ConfigSchemaError(ConfigError):
    """Exception raised when configuration schema validation fails."""

    def __init__(self, errors: list, message: str = "Configuration schema validation failed"):
        full_message = f"{message}: {', '.join(str(e) for e in errors)}"
        super().__init__(full_message, "CONFIG_SCHEMA_ERROR")
        self.errors = errors
