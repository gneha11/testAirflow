"""
Configuration manager for AIML platform.

Provides centralized configuration management with support for:
- Environment variables
- Configuration files (JSON, YAML, TOML)
- Azure Key Vault integration
- Configuration validation
- Default values and type conversion
"""

import json
import os
from pathlib import Path
from typing import Any, Optional, Type

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, ValidationError

from ..azure_keyvault import KeyVaultClient
from ..logger import get_logger
from .exceptions import ConfigError, ConfigFileError, ConfigNotFoundError, ConfigSchemaError, ConfigValidationError


class ConfigManager:
    """
    Centralized configuration manager.

    Features:
    - Multiple configuration sources
    - Type conversion and validation
    - Default values
    - Environment variable substitution
    - Azure Key Vault integration
    - Configuration caching
    """

    def __init__(
        self,
        config_file: Optional[str] = None,
        env_file: Optional[str] = None,
        keyvault_client: Optional[KeyVaultClient] = None,
        auto_load_env: bool = True,
    ):
        """
        Initialize configuration manager.

        Args:
            config_file: Path to configuration file (JSON, YAML, or TOML)
            env_file: Path to .env file
            keyvault_client: Azure Key Vault client for secret retrieval
            auto_load_env: Whether to automatically load .env file
        """
        self.logger = get_logger(__name__)
        self.keyvault_client = keyvault_client

        # Configuration cache
        self._config_cache: dict[str, Any] = {}
        self._file_config: dict[str, Any] = {}

        # Load environment variables
        if auto_load_env:
            if env_file and Path(env_file).exists():
                load_dotenv(env_file)
                self.logger.info(f"Loaded environment variables from {env_file}")
            else:
                load_dotenv()  # Load from default .env file if exists

        # Load configuration file
        if config_file:
            self.load_config_file(config_file)

    def load_config_file(self, file_path: str):
        """
        Load configuration from file.

        Args:
            file_path: Path to configuration file

        Raises:
            ConfigFileError: If file cannot be loaded
        """
        try:
            path = Path(file_path)
            if not path.exists():
                raise ConfigFileError(file_path, "Configuration file not found")

            with open(path, encoding="utf-8") as f:
                if path.suffix.lower() == ".json":
                    self._file_config = json.load(f)
                elif path.suffix.lower() in [".yaml", ".yml"]:
                    self._file_config = yaml.safe_load(f)
                elif path.suffix.lower() == ".toml":
                    import tomli

                    with open(path, "rb") as fb:
                        self._file_config = tomli.load(fb)
                else:
                    raise ConfigFileError(file_path, "Unsupported file format")

            self.logger.info(f"Loaded configuration from {file_path}")

        except Exception as e:
            self.logger.error(f"Failed to load configuration file {file_path}: {e!s}")
            raise ConfigFileError(file_path, f"Failed to load configuration: {e!s}")

    def get(
        self, key: str, default: Any = None, required: bool = False, data_type: Type = None, from_keyvault: bool = False
    ) -> Any:
        """
        Get configuration value.
        """
        value = None
        source = None

        try:
            # 1. If from_keyvault, try Key Vault first
            if from_keyvault and self.keyvault_client:
                try:
                    value = self.keyvault_client.get_secret(key)
                    source = "keyvault"
                except Exception as e:
                    self.logger.warning(f"Failed to get secret '{key}' from Key Vault: {e!s}")

            # 2. Check if value was set via set() (cache)
            if value is None and f"{key}:False" in self._config_cache:
                value = self._config_cache[f"{key}:False"]
                source = "cache"

            # 3. Try environment variables
            if value is None:
                env_key = key.upper().replace(".", "_")
                value = os.getenv(env_key)
                if value is not None:
                    source = "environment"

            # 4. Try configuration file
            if value is None:
                value = self._get_nested_value(self._file_config, key)
                if value is not None:
                    source = "config_file"

            # 5. Default or required
            if value is None:
                if required:
                    raise ConfigNotFoundError(key)
                value = default
                source = "default"

            # 6. Type conversion (always apply, even for cache)
            if data_type is not None and value is not None and not isinstance(value, data_type):
                value = self._convert_type(key, value, data_type)

            # 7. Cache the converted value (except for default)
            if source != "default":
                cache_key = f"{key}:{from_keyvault}"
                self._config_cache[cache_key] = value

            if source != "default":
                self.logger.debug(f"Retrieved config '{key}' from {source}")

            return value

        except (ConfigNotFoundError, ConfigValidationError):
            raise
        except Exception as e:
            self.logger.error(f"Error getting configuration '{key}': {e!s}")
            raise ConfigError(f"Failed to get configuration '{key}': {e!s}")

    def get_int(self, key: str, default: int = None, required: bool = False) -> int:
        """Get integer configuration value."""
        return self.get(key, default, required, int)

    def get_float(self, key: str, default: float = None, required: bool = False) -> float:
        """Get float configuration value."""
        return self.get(key, default, required, float)

    def get_bool(self, key: str, default: bool = None, required: bool = False) -> bool:
        """Get boolean configuration value."""
        return self.get(key, default, required, bool)

    def get_list(self, key: str, default: list = None, required: bool = False) -> list:
        """Get list configuration value."""
        return self.get(key, default, required, list)

    def get_dict(self, key: str, default: dict = None, required: bool = False) -> dict:
        """Get dictionary configuration value."""
        return self.get(key, default, required, dict)

    def get_secret(self, key: str, default: str = None, required: bool = False) -> str:
        """Get secret from Azure Key Vault, cache, env, or file config."""
        # 1. Check if value was set via set() (cache)
        if f"{key}:False" in self._config_cache:
            return self._config_cache[f"{key}:False"]
        # 2. Try Key Vault
        if self.keyvault_client:
            try:
                return self.keyvault_client.get_secret(key)
            except Exception as e:
                self.logger.warning(f"Failed to get secret '{key}' from Key Vault: {e!s}")
        # 3. Try environment variables
        env_key = key.upper().replace(".", "_")
        value = os.getenv(env_key)
        if value is not None:
            return value
        # 4. Try configuration file
        value = self._get_nested_value(self._file_config, key)
        if value is not None:
            return value
        # 5. Default or required
        if required:
            raise ConfigNotFoundError(key)
        return default

    def set(self, key: str, value: Any, cache_only: bool = True):
        """
        Set configuration value.

        Args:
            key: Configuration key
            value: Configuration value
            cache_only: Whether to only set in cache (not persist to file)
        """
        cache_key = f"{key}:False"
        self._config_cache[cache_key] = value

        if not cache_only:
            # Set in file config (for potential persistence)
            self._set_nested_value(self._file_config, key, value)

        self.logger.debug(f"Set configuration '{key}' = {value}")

    def get_all(self, prefix: str = None) -> dict[str, Any]:
        """
        Get all configuration values with optional prefix filter.

        Args:
            prefix: Key prefix to filter by

        Returns:
            Dictionary of configuration values
        """
        result = {}

        # Get from environment variables
        for key, value in os.environ.items():
            config_key = key.lower().replace("_", ".")
            if prefix is None or config_key.startswith(prefix):
                result[config_key] = value

        # Get from file config
        def _flatten_dict(d: dict, parent_key: str = "") -> dict:
            items = []
            for k, v in d.items():
                new_key = f"{parent_key}.{k}" if parent_key else k
                if isinstance(v, dict):
                    items.extend(_flatten_dict(v, new_key).items())
                else:
                    items.append((new_key, v))
            return dict(items)

        file_config_flat = _flatten_dict(self._file_config)
        for key, value in file_config_flat.items():
            if prefix is None or key.startswith(prefix):
                result[key] = value

        return result

    def validate_schema(self, schema: Type[BaseModel]) -> BaseModel:
        """
        Validate configuration against Pydantic schema.

        Args:
            schema: Pydantic model class for validation

        Returns:
            Validated configuration model instance

        Raises:
            ConfigSchemaError: If validation fails
        """
        try:
            # Get all configuration values
            config_data = self.get_all()

            # Create model instance
            return schema(**config_data)

        except ValidationError as e:
            self.logger.error(f"Configuration schema validation failed: {e.errors()}")
            raise ConfigSchemaError(e.errors())
        except Exception as e:
            self.logger.error(f"Configuration validation error: {e!s}")
            raise ConfigError(f"Configuration validation failed: {e!s}")

    def reload(self):
        """Reload configuration from all sources."""
        self._config_cache.clear()
        self.logger.info("Configuration cache cleared and reloaded")

    def _get_nested_value(self, data: dict, key: str) -> Any:
        """Get value from nested dictionary using dot notation."""
        keys = key.split(".")
        value = data

        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return None

        return value

    def _set_nested_value(self, data: dict, key: str, value: Any):
        """Set value in nested dictionary using dot notation."""
        keys = key.split(".")
        current = data

        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]

        current[keys[-1]] = value

    def _convert_type(self, key: str, value: Any, data_type: Type) -> Any:
        """Convert value to specified type."""
        if value is None:
            return None

        try:
            if data_type == bool:
                if isinstance(value, str):
                    return value.lower() in ("true", "1", "yes", "on")
                return bool(value)
            elif data_type == list:
                if isinstance(value, str):
                    # Try to parse as JSON array
                    try:
                        parsed = json.loads(value)
                        if isinstance(parsed, list):
                            return parsed
                    except json.JSONDecodeError:
                        pass
                    # Split by comma
                    return [item.strip() for item in value.split(",") if item.strip()]
                return list(value) if not isinstance(value, list) else value
            elif data_type == dict:
                if isinstance(value, str):
                    return json.loads(value)
                return dict(value) if not isinstance(value, dict) else value
            else:
                return data_type(value)

        except (ValueError, TypeError, json.JSONDecodeError) as e:
            raise ConfigValidationError(key, str(value), data_type.__name__, str(e))

    def get_database_url(self, prefix: str = "database") -> str:
        """
        Build database URL from configuration components.

        Args:
            prefix: Configuration key prefix

        Returns:
            Database connection URL
        """
        driver = self.get(f"{prefix}.driver", required=True)
        host = self.get(f"{prefix}.host", required=True)
        port = self.get_int(f"{prefix}.port")
        database = self.get(f"{prefix}.name", required=True)
        username = self.get(f"{prefix}.username")
        password = self.get_secret(f"{prefix}.password")

        # Build URL
        url = f"{driver}://"
        if username:
            url += username
            if password:
                url += f":{password}"
            url += "@"
        url += host
        if port:
            url += f":{port}"
        url += f"/{database}"

        return url
