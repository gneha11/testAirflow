"""
Enums for database logging component.

Defines status values and event types used in database logging.
"""

from enum import Enum


class BatchStatus(Enum):
    """Batch job status values."""

    STARTED = "STARTED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    PAUSED = "PAUSED"


class EventStatus(Enum):
    """Event status values."""

    INFO = "INFO"
    SUCCESS = "SUCCESS"
    WARNING = "WARNING"
    ERROR = "ERROR"
    DEBUG = "DEBUG"


class EventType(Enum):
    """Event type values."""

    BATCH_START = "BATCH_START"
    BATCH_END = "BATCH_END"
    RECORD_PROCESS = "RECORD_PROCESS"
    STEP_START = "STEP_START"
    STEP_END = "STEP_END"
    ERROR_HANDLE = "ERROR_HANDLE"
    VALIDATION = "VALIDATION"
    TRANSFORMATION = "TRANSFORMATION"
    EXTERNAL_API = "EXTERNAL_API"
    DATABASE_OPERATION = "DATABASE_OPERATION"
    CUSTOM = "CUSTOM"
