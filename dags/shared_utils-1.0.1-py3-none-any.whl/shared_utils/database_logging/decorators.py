"""
Decorators for database logging functionality.

Provides convenient decorators for automatic batch job and step tracking.
"""

import time  # Added for time.time()
from functools import wraps  # Added for wraps
from typing import Any, Dict, Optional

from .enums import EventStatus, EventType


def log_batch_job(
    batch_name: Optional[str] = None,
    batch_type: Optional[str] = None,
    total_records: Optional[int] = None,
    created_by: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
):
    """
    Decorator to automatically log batch job lifecycle.

    Args:
        batch_name: Name for the batch (can be function name if not provided)
        batch_type: Type of batch job
        total_records: Expected total records to process
        created_by: User/system creating the batch
        metadata: Additional metadata
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Get database logger from kwargs or create one
            db_logger = kwargs.get("db_logger")
            if not db_logger:
                raise ValueError("db_logger must be provided in kwargs")

            # Determine batch name
            actual_batch_name = batch_name or func.__name__

            # Start batch
            batch_id = db_logger.start_batch(
                batch_name=actual_batch_name,
                batch_type=batch_type,
                total_records=total_records,
                created_by=created_by,
                metadata=metadata,
            )

            try:
                # Execute function
                result = func(*args, **kwargs)

                # Complete batch successfully
                db_logger.complete_batch(batch_id, success_count=total_records or 0, failed_count=0)

                return result

            except Exception as e:
                # Complete batch with error
                db_logger.complete_batch(
                    batch_id, success_count=0, failed_count=total_records or 0, error_message=str(e)
                )
                raise

        return wrapper

    return decorator


def log_processing_step(step_name: Optional[str] = None, step_order: Optional[int] = None):
    """
    Decorator to log individual processing steps within a batch.

    Args:
        step_name: Name of the processing step
        step_order: Order of the step in the process
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Get required parameters
            db_logger = kwargs.get("db_logger")
            batch_id = kwargs.get("batch_id")

            if not db_logger:
                raise ValueError("db_logger must be provided in kwargs")
            if batch_id is None:
                raise ValueError("batch_id must be provided in kwargs")

            # Determine step name
            actual_step_name = step_name or func.__name__

            # Log step start
            start_time = db_logger.log_step_start(batch_id=batch_id, step_name=actual_step_name, step_order=step_order)

            try:
                # Execute function
                result = func(*args, **kwargs)

                # Log step completion
                db_logger.log_step_end(
                    batch_id=batch_id,
                    step_name=actual_step_name,
                    start_time=start_time,
                    success=True,
                    step_order=step_order,
                )

                return result

            except Exception as e:
                # Log step failure
                db_logger.log_step_end(
                    batch_id=batch_id,
                    step_name=actual_step_name,
                    start_time=start_time,
                    success=False,
                    step_order=step_order,
                    metadata={"error": str(e)},
                )
                raise

        return wrapper

    return decorator


def log_record_processing(record_id_param: str = "record_id", event_type: str = EventType.RECORD_PROCESS.value):
    """
    Decorator to log individual record processing.

    Args:
        record_id_param: Name of the parameter containing record ID
        event_type: Type of event to log
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Get required parameters
            db_logger = kwargs.get("db_logger")
            batch_id = kwargs.get("batch_id")

            if not db_logger:
                raise ValueError("db_logger must be provided in kwargs")
            if batch_id is None:
                raise ValueError("batch_id must be provided in kwargs")

            # Get record ID
            record_id = kwargs.get(record_id_param)
            if not record_id:
                raise ValueError(f"Parameter '{record_id_param}' must be provided")

            start_time = time.time()

            try:
                # Execute function
                result = func(*args, **kwargs)

                # Log successful processing
                execution_time_ms = int((time.time() - start_time) * 1000)
                db_logger.log_event(
                    batch_id=batch_id,
                    event_type=event_type,
                    event_status=EventStatus.SUCCESS.value,
                    event_message=f"Successfully processed record: {record_id}",
                    record_id=record_id,
                    execution_time_ms=execution_time_ms,
                )

                return result

            except Exception as e:
                # Log failed processing
                execution_time_ms = int((time.time() - start_time) * 1000)
                db_logger.log_event(
                    batch_id=batch_id,
                    event_type=event_type,
                    event_status=EventStatus.ERROR.value,
                    event_message=f"Failed to process record: {record_id} - {e!s}",
                    event_data={"error": str(e)},
                    record_id=record_id,
                    execution_time_ms=execution_time_ms,
                )
                raise

        return wrapper

    return decorator


def log_external_api_call(api_name: str, event_type: str = EventType.EXTERNAL_API.value):
    """
    Decorator to log external API calls.

    Args:
        api_name: Name of the external API
        event_type: Type of event to log
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Get required parameters
            db_logger = kwargs.get("db_logger")
            batch_id = kwargs.get("batch_id")

            if not db_logger:
                raise ValueError("db_logger must be provided in kwargs")
            if batch_id is None:
                raise ValueError("batch_id must be provided in kwargs")

            start_time = time.time()

            try:
                # Execute function
                result = func(*args, **kwargs)

                # Log successful API call
                execution_time_ms = int((time.time() - start_time) * 1000)
                db_logger.log_event(
                    batch_id=batch_id,
                    event_type=event_type,
                    event_status=EventStatus.SUCCESS.value,
                    event_message=f"Successfully called external API: {api_name}",
                    event_data={"api_name": api_name, "response": result},
                    execution_time_ms=execution_time_ms,
                )

                return result

            except Exception as e:
                # Log failed API call
                execution_time_ms = int((time.time() - start_time) * 1000)
                db_logger.log_event(
                    batch_id=batch_id,
                    event_type=event_type,
                    event_status=EventStatus.ERROR.value,
                    event_message=f"Failed to call external API: {api_name} - {e!s}",
                    event_data={"api_name": api_name, "error": str(e)},
                    execution_time_ms=execution_time_ms,
                )
                raise

        return wrapper

    return decorator


def log_database_operation(
    operation_type: str, table_name: Optional[str] = None, event_type: str = EventType.DATABASE_OPERATION.value
):
    """
    Decorator to log database operations.

    Args:
        operation_type: Type of database operation (SELECT, INSERT, UPDATE, DELETE)
        table_name: Name of the table being operated on
        event_type: Type of event to log
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Get required parameters
            db_logger = kwargs.get("db_logger")
            batch_id = kwargs.get("batch_id")

            if not db_logger:
                raise ValueError("db_logger must be provided in kwargs")
            if batch_id is None:
                raise ValueError("batch_id must be provided in kwargs")

            start_time = time.time()

            try:
                # Execute function
                result = func(*args, **kwargs)

                # Log successful database operation
                execution_time_ms = int((time.time() - start_time) * 1000)
                db_logger.log_event(
                    batch_id=batch_id,
                    event_type=event_type,
                    event_status=EventStatus.SUCCESS.value,
                    event_message=f"Successfully executed {operation_type} operation{f' on {table_name}' if table_name else ''}",
                    event_data={
                        "operation_type": operation_type,
                        "table_name": table_name,
                        "affected_rows": getattr(result, "rowcount", None),
                    },
                    execution_time_ms=execution_time_ms,
                )

                return result

            except Exception as e:
                # Log failed database operation
                execution_time_ms = int((time.time() - start_time) * 1000)
                db_logger.log_event(
                    batch_id=batch_id,
                    event_type=event_type,
                    event_status=EventStatus.ERROR.value,
                    event_message=f"Failed to execute {operation_type} operation{f' on {table_name}' if table_name else ''} - {e!s}",
                    event_data={"operation_type": operation_type, "table_name": table_name, "error": str(e)},
                    execution_time_ms=execution_time_ms,
                )
                raise

        return wrapper

    return decorator
