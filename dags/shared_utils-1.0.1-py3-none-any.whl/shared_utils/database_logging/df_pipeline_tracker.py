"""
Pipeline tracking utilities for data processing pipelines.

This module provides functionality to track pipeline execution states
and manage time windows for data processing.
"""

import logging
from datetime import datetime
from typing import Optional, Tuple, Dict, Any, Union
import psycopg2
from psycopg2.extras import RealDictCursor

# PySpark imports
try:
    from pyspark.sql import DataFrame
    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    DataFrame = None


class DFPipelineManager:
    """
    Pipeline manager for tracking execution states and time windows.
    
    Provides functionality to retrieve time windows from execution checkpoints
    and manage pipeline state tracking.
    """
    
    def __init__(self, logger_instance: Optional[logging.Logger] = None):
        """
        Initialize DFPipelineManager.
        
        Args:
            logger_instance: Logger instance (optional, creates basic logger if not provided)
        """
        self.logger = logger_instance or self._create_basic_logger()
    
    def _create_basic_logger(self) -> logging.Logger:
        """
        Create a basic logger instance.
        
        Returns:
            Basic logger instance
        """
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def df_get_execution_time_window(
        self,
        log_session_id: str,
        tenant_id: str,
        enterprise_id: str,
        pipeline_name: str,
        data_category: str,
        conn: psycopg2.extensions.connection
    ) -> Tuple[Optional[datetime], datetime]:
        """
        Retrieve time window from execution_checkpoint table using provided connection.
        
        Args:
            log_session_id: Log session identifier (used for end_ts when no records found)
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            pipeline_name: Pipeline name for checkpoint lookup
            data_category: Category of data being processed
            conn: PostgreSQL connection object (from db_connector)
            
        Returns:
            Tuple of (start_timestamp, end_timestamp)
            
        Raises:
            Exception: If database query fails or connection issues occur
        """
        logger = self.logger
        
        try:
            logger.info(f"🔍 Retrieving time window for pipeline: {pipeline_name}")
            logger.info(f"📊 Parameters: tenant={tenant_id}, enterprise={enterprise_id}, category={data_category}")
            
            # Query to get latest execution checkpoint
            query = """
            SELECT last_run_timestamp, current_start_time
            FROM execution_checkpoint
            WHERE tenant_id = %s 
              AND enterprise_id = %s 
              AND pipeline_name = %s
              AND additional_details = %s
            ORDER BY current_start_time DESC LIMIT 1
            """
            
            with conn.cursor() as cursor:
                cursor.execute(query, (tenant_id, enterprise_id, pipeline_name, data_category))
                row = cursor.fetchone()
            
            # Return appropriate time window based on availability
            if row:
                # start_ts, end_ts = row
                # Handle RealDictRow (dictionary-like) vs tuple results
                if hasattr(row, 'keys'):  # RealDictRow
                    start_ts = row['last_run_timestamp']
                    end_ts = row['current_start_time']
                else:  # Regular tuple
                    start_ts, end_ts = row
                logger.info(f"✅ Time Window from checkpoint: {start_ts} to {end_ts}")
            else:
                start_ts = None
                end_ts = datetime.fromisoformat(log_session_id)
                logger.info(f"⭐ First-time run. Using time window till {end_ts}")
            
            return start_ts, end_ts
            
        except psycopg2.Error as e:
            error_msg = f"❌ Database query failed: {e}"
            logger.error(error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"❌ Unexpected error in df_get_execution_time_window: {e}"
            logger.error(error_msg)
            raise Exception(error_msg) from e

    def df_track_pipeline_execution(
        self,
        tenant_id: str,
        enterprise_id: str,
        pipeline_name: str,
        component_name: str,
        data_category: str,
        log_session_id: str,
        conn: psycopg2.extensions.connection
    ) -> int:
        """
        Track pipeline execution by creating audit records and managing checkpoints.
        
        This function performs the following operations:
        1. Validates required parameters
        2. Creates a new execution record in execution_audit_log
        3. Cleans up previous checkpoints for the same pipeline
        4. Updates execution_checkpoint with latest completed run
        5. Returns the new pipeline run_id
        
        Args:
            tenant_id: Tenant identifier (required)
            enterprise_id: Enterprise identifier (required)
            pipeline_name: Pipeline name (required)
            component_name: Component name (required)
            data_category: Data category for processing (required)
            log_session_id: Log session identifier (required)
            conn: PostgreSQL connection object (from db_connector)
            
        Returns:
            New pipeline run_id (integer)
            
        Raises:
            ValueError: If required parameters are missing
            Exception: If database operations fail
        """
        logger = self.logger
        
        try:
            # ────────────────────────────────────────────────────────────────────────────────
            # 🛡️ Validate Parameters
            # ────────────────────────────────────────────────────────────────────────────────
            if not tenant_id or not enterprise_id:
                raise ValueError("❌ tenant_id and enterprise_id must be provided.")
            
            if not pipeline_name or not component_name or not data_category or not log_session_id:
                raise ValueError("❌ pipeline_name, component_name, data_category, and log_session_id must be provided.")
            
            # Generate timestamp from log_session_id
            new_timestamp = datetime.strptime(log_session_id, "%Y%m%d_%H%M%S")
            
            logger.info(f"📌 Starting pipeline tracking..")
            logger.info(f"🔐 tenant_id: {tenant_id}, enterprise_id: {enterprise_id}, session: {log_session_id}")
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 🔌 Use provided PostgreSQL connection
            # ────────────────────────────────────────────────────────────────────────────────
            cursor = conn.cursor()
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 🔢 Compute New pipeline run_id
            # ────────────────────────────────────────────────────────────────────────────────
            cursor.execute("SELECT MAX(run_id) FROM execution_audit_log")
            result = cursor.fetchone()
            
            # Handle both RealDictRow and tuple results
            if hasattr(result, 'keys'):  # RealDictRow (dictionary-like)
                max_id = result.get('max') if result else None
            else:  # Regular tuple
                max_id = result[0] if result and result[0] is not None else None
            new_pipeline_id = 1 if max_id is None else max_id + 1
            
            logger.info(f"🆕 New pipeline run_id: {new_pipeline_id}, timestamp: {new_timestamp}")
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 📝 Insert new execution record into execution_audit_log
            # ────────────────────────────────────────────────────────────────────────────────
            cursor.execute("""
                INSERT INTO execution_audit_log
                (run_id, tenant_id, enterprise_id, component_name, pipeline_name, start_time, end_time, status, record_counts, additional_details)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                new_pipeline_id,
                tenant_id,
                enterprise_id,
                component_name,
                pipeline_name,        
                new_timestamp,
                None,  # end_time will be updated when pipeline completes
                "In-Progress",
                None,  # record_counts will be updated when pipeline completes
                data_category  # additional_details stores data_category
            ))
            logger.info("✅ Inserted new record into execution_audit_log.")
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 🗑️ Clean up previous snapshot from execution_checkpoint
            # ────────────────────────────────────────────────────────────────────────────────
            cursor.execute("""
                DELETE FROM execution_checkpoint
                WHERE component_name = %s AND pipeline_name = %s AND tenant_id = %s AND enterprise_id = %s AND additional_details = %s
            """, (component_name, pipeline_name, tenant_id, enterprise_id, data_category))
            
            deleted_count = cursor.rowcount
            logger.info(f"🗑️ Deleted {deleted_count} existing records from execution_checkpoint.")
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 📥 Fetch latest completed run from execution_audit_log
            # ────────────────────────────────────────────────────────────────────────────────
            cursor.execute("""
                SELECT run_id, component_name, pipeline_name, tenant_id, enterprise_id, start_time
                FROM execution_audit_log
                WHERE run_id = (
                    SELECT MAX(run_id)
                    FROM execution_audit_log
                    WHERE status = 'Completed'
                      AND component_name = %s
                      AND pipeline_name = %s
                      AND tenant_id = %s
                      AND enterprise_id = %s
                      AND additional_details = %s
                )
            """, (component_name, pipeline_name, tenant_id, enterprise_id, data_category))
            last_run = cursor.fetchone()
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 💾 Insert snapshot into execution_checkpoint if a completed run exists
            # ────────────────────────────────────────────────────────────────────────────────
            if last_run is None:
                logger.warning("⚠️ No completed pipeline run found to update execution_checkpoint.")
            else:
                # Handle both RealDictRow and tuple results for last_run
                if hasattr(last_run, 'keys'):  # RealDictRow (dictionary-like)
                    run_id_val = last_run.get('run_id')
                    component_name_val = last_run.get('component_name')
                    pipeline_name_val = last_run.get('pipeline_name')
                    tenant_id_val = last_run.get('tenant_id')
                    enterprise_id_val = last_run.get('enterprise_id')
                    start_time_val = last_run.get('start_time')
                else:  # Regular tuple
                    run_id_val = last_run[0]
                    component_name_val = last_run[1]
                    pipeline_name_val = last_run[2]
                    tenant_id_val = last_run[3]
                    enterprise_id_val = last_run[4]
                    start_time_val = last_run[5]
                
                cursor.execute("""
                    INSERT INTO execution_checkpoint
                    (run_id, component_name, pipeline_name, tenant_id, enterprise_id, last_run_timestamp, current_start_time, additional_details)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    run_id_val,
                    component_name_val,
                    pipeline_name_val,
                    tenant_id_val,
                    enterprise_id_val,
                    start_time_val,
                    new_timestamp,
                    data_category  # additional_details stores data_category
                ))
                logger.info("🔁 Updated execution_checkpoint with latest completed execution.")
            
            # ✅ Close cursor (connection is managed by caller)
            cursor.close()
            
            logger.info(f"✅ Pipeline execution tracking completed successfully. Run ID: {new_pipeline_id}")
            return new_pipeline_id
            
        except ValueError as e:
            logger.error(f"❌ Validation error: {e}")
            raise
        except psycopg2.Error as e:
            logger.error(f"❌ Database error: {e}")
            raise Exception(f"Database operation failed: {e}") from e
        except Exception as e:
            logger.error(f"❌ Pipeline execution tracking failed: {e}")
            raise Exception(f"Pipeline execution tracking failed: {e}") from e

    def df_update_pipeline_failed_status(
        self,
        conn: psycopg2.extensions.connection,
        run_id: Optional[int] = None,
        tenant_id: Optional[str] = None,
        enterprise_id: Optional[str] = None,
        pipeline_name: Optional[str] = None,
        component_name: Optional[str] = None,
        data_category: Optional[str] = None,
        exception: Optional[Exception] = None,
        logger_instance: Optional[logging.Logger] = None
    ) -> None:
        """
        Update pipeline status to 'Failed' in execution_audit_log.
        
        This function updates the status of the latest 'In-Progress' pipeline run
        to 'Failed' and sets the end_time to the current timestamp.
        
        Args:
            conn: PostgreSQL connection object (from db_connector) (required)
            run_id: Specific run_id to update (optional, if provided, other parameters are ignored)
            tenant_id: Tenant identifier (required if run_id not provided)
            enterprise_id: Enterprise identifier (required if run_id not provided)
            pipeline_name: Pipeline name (required if run_id not provided)
            component_name: Component name (required if run_id not provided)
            data_category: Data category for processing (required if run_id not provided)
            exception: Exception object to append to additional_details (optional)
            logger_instance: Logger instance (optional)
            
        Raises:
            ValueError: If required parameters are missing
            Exception: If database operations fail
        """
        # Use provided logger or fall back to instance logger
        logger = logger_instance or self.logger
        
        try:
            # ────────────────────────────────────────────────────────────────────────────────
            # 🛡️ Validate Parameters
            # ────────────────────────────────────────────────────────────────────────────────
            if not run_id and (not tenant_id or not enterprise_id or not pipeline_name or not component_name or not data_category):
                raise ValueError("❌ run_id or tenant_id, enterprise_id, pipeline_name, component_name, and data_category must be provided.")
            
            # Generate current timestamp
            new_timestamp = datetime.utcnow()
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 🔌 Use provided PostgreSQL connection
            # ────────────────────────────────────────────────────────────────────────────────
            cursor = conn.cursor()
            
            # ────────────────────────────────────────────────────────────────────────────────
            # ❌ Update execution_audit_log status to 'Failed'
            # ────────────────────────────────────────────────────────────────────────────────
            # Prepare error message if exception is provided
            error_message = ""
            if exception:
                error_message = f"; Error: {str(exception)}"
                logger.info(f"📝 Appending error message: {error_message}")
            
            if run_id is not None:
                # Update by specific run_id
                cursor.execute("""
                    UPDATE execution_audit_log 
                    SET status = 'Failed',
                        end_time = %s,
                        additional_details = COALESCE(additional_details, '') || %s
                    WHERE run_id = %s AND status = 'In-Progress'
                """, (new_timestamp, error_message, run_id))
                logger.info(f"📌 Marking pipeline run_id {run_id} as Failed at {new_timestamp}")
            else:
                # Update by other parameters
                cursor.execute("""
                    UPDATE execution_audit_log 
                    SET status = 'Failed',
                        end_time = %s,
                        additional_details = COALESCE(additional_details, '') || %s
                    WHERE status = 'In-Progress'
                      AND pipeline_name = %s
                      AND component_name = %s
                      AND tenant_id = %s
                      AND enterprise_id = %s
                      AND additional_details = %s
                """, (
                    new_timestamp,
                    error_message,
                    pipeline_name,
                    component_name,
                    tenant_id,
                    enterprise_id,
                    data_category
                ))
                logger.info(f"📌 Marking pipeline '{pipeline_name}' as Failed at {new_timestamp}")
                logger.info(f"🔐 tenant_id: {tenant_id}, enterprise_id: {enterprise_id}")
            
            updated_count = cursor.rowcount
            logger.info(f"🛑 Updated {updated_count} record(s) in execution_audit_log to 'Failed'.")
            
            # ✅ Close cursor (connection is managed by caller)
            cursor.close()
            
            logger.info(f"✅ Pipeline failed status update done successfully.")
            
        except ValueError as e:
            logger.error(f"❌ Validation error: {e}")
            raise
        except psycopg2.Error as e:
            logger.error(f"❌ Database error: {e}")
            raise Exception(f"Database operation failed: {e}") from e
        except Exception as e:
            logger.error(f"❌ Pipeline failed status update failed: {e}")
            raise Exception(f"Pipeline failed status update failed: {e}") from e

    def df_update_pipeline_completed_status(
        self,
        conn: psycopg2.extensions.connection,
        run_id: Optional[int] = None,
        tenant_id: Optional[str] = None,
        enterprise_id: Optional[str] = None,
        pipeline_name: Optional[str] = None,
        component_name: Optional[str] = None,
        data_category: Optional[str] = None,
        record_counts: Optional[str] = None,
        logger_instance: Optional[logging.Logger] = None
    ) -> None:
        """
        Update pipeline status to 'Completed' in execution_audit_log.
        
        This function updates the status of the latest 'In-Progress' pipeline run
        to 'Completed' and sets the end_time to the current timestamp.
        
        Args:
            conn: PostgreSQL connection object (from db_connector) (required)
            run_id: Specific run_id to update (optional, if provided, other parameters are ignored)
            tenant_id: Tenant identifier (required if run_id not provided)
            enterprise_id: Enterprise identifier (required if run_id not provided)
            pipeline_name: Pipeline name (required if run_id not provided)
            component_name: Component name (required if run_id not provided)
            data_category: Data category for processing (required if run_id not provided)
            record_counts: Number of records processed or table info (optional, string format)
            logger_instance: Logger instance (optional)
            
        Raises:
            ValueError: If required parameters are missing
            Exception: If database operations fail
        """
        # Use provided logger or fall back to instance logger
        logger = logger_instance or self.logger
        
        try:
            # ────────────────────────────────────────────────────────────────────────────────
            # 🛡️ Validate Parameters
            # ────────────────────────────────────────────────────────────────────────────────
            if run_id is not None:
                # If run_id is provided, use it directly
                logger.info(f"📌 Using specific run_id: {run_id}")
            else:
                # If run_id is not provided, validate all other parameters
                if not tenant_id or not enterprise_id:
                    raise ValueError("❌ tenant_id and enterprise_id must be provided when run_id is not provided.")
                
                if not pipeline_name or not component_name or not data_category:
                    raise ValueError("❌ pipeline_name, component_name, and data_category must be provided when run_id is not provided.")
            
            # Generate current timestamp
            new_timestamp = datetime.utcnow()
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 🔌 Use provided PostgreSQL connection
            # ────────────────────────────────────────────────────────────────────────────────
            cursor = conn.cursor()
            
            # ────────────────────────────────────────────────────────────────────────────────
            # ✅ Update execution_audit_log status to 'Completed'
            # ────────────────────────────────────────────────────────────────────────────────
            if run_id is not None:
                # Update by specific run_id
                cursor.execute("""
                    UPDATE execution_audit_log 
                    SET status = 'Completed',
                        end_time = %s,
                        record_counts = %s
                    WHERE run_id = %s AND status = 'In-Progress'
                """, (new_timestamp, record_counts, run_id))
                logger.info(f"📌 Marking pipeline run_id {run_id} as Completed at {new_timestamp}")
            else:
                # Update by other parameters
                cursor.execute("""
                    UPDATE execution_audit_log 
                    SET status = 'Completed',
                        end_time = %s,
                        record_counts = %s
                    WHERE status = 'In-Progress'
                      AND pipeline_name = %s
                      AND component_name = %s
                      AND tenant_id = %s
                      AND enterprise_id = %s
                      AND additional_details = %s
                """, (
                    new_timestamp,
                    record_counts,
                    pipeline_name,
                    component_name,
                    tenant_id,
                    enterprise_id,
                    data_category
                ))
                logger.info(f"📌 Marking pipeline '{pipeline_name}' as Completed at {new_timestamp}")
                logger.info(f"🔐 tenant_id: {tenant_id}, enterprise_id: {enterprise_id}")
            
            updated_count = cursor.rowcount
            logger.info(f"✅ Updated {updated_count} record(s) in execution_audit_log to 'Completed'.")
            
            # ✅ Close cursor (connection is managed by caller)
            cursor.close()
            
            logger.info(f"✅ Pipeline completed status update done successfully.")
            
        except ValueError as e:
            logger.error(f"❌ Validation error: {e}")
            raise
        except psycopg2.Error as e:
            logger.error(f"❌ Database error: {e}")
            raise Exception(f"Database operation failed: {e}") from e
        except Exception as e:
            logger.error(f"❌ Pipeline completed status update failed: {e}")
            raise Exception(f"Pipeline completed status update failed: {e}") from e

    def df_capture_schema(
        self,
        spark_session,
        table_name: str,
        fail_if_not_exists: bool = False
    ) -> Optional[DataFrame]:
        """
        Capture current schema and return as DataFrame.
        
        This function captures the current schema of a table and returns it as a DataFrame
        for schema tracking and comparison purposes.
        
        Args:
            spark_session: Spark session object (required)
            table_name: Name of the table whose schema is being captured (required)
            fail_if_not_exists: If True, function fails when table doesn't exist. 
                               If False, returns None for non-existent tables (default: False)
            
        Returns:
            DataFrame containing the schema information, or None if table doesn't exist and fail_if_not_exists=False
            
        Raises:
            ImportError: If PySpark is not available
            ValueError: If required parameters are missing
            Exception: If schema capture fails and fail_if_not_exists=True
        """
        # Use instance logger
        logger = self.logger
        
        try:
            # ────────────────────────────────────────────────────────────────────────────────
            # 🛡️ Validate Parameters
            # ────────────────────────────────────────────────────────────────────────────────
            if not PYSPARK_AVAILABLE:
                raise ImportError("❌ PySpark is required for schema capture functionality")
            
            if not spark_session or not table_name:
                raise ValueError("❌ spark_session and table_name must be provided.")
            
            logger.info(f"📊 Capturing schema for table: {table_name}")
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 🔍 Capture schema using Spark
            # ────────────────────────────────────────────────────────────────────────────────
            try:
                # Get schema as DataFrame
                schema_df = spark_session.sql(f"DESCRIBE {table_name}")
                
                # Force execution to get fresh schema
                schema_df.collect()
                
                logger.info(f"✅ Schema captured successfully for table '{table_name}'")
                logger.info(f"📋 Schema columns: {schema_df.count()}")
                return schema_df
                
            except Exception as e:
                # Check if it's a "table not found" error - handle various Spark error messages
                error_str = str(e)
                is_table_not_found = (
                    "Table or view not found" in error_str or 
                    "does not exist" in error_str or
                    "TABLE_OR_VIEW_NOT_FOUND" in error_str or
                    "UnresolvedTableOrView" in error_str or
                    "cannot be found" in error_str
                )
                
                if is_table_not_found:
                    if fail_if_not_exists:
                        logger.error(f"❌ Table '{table_name}' does not exist: {e}")
                        raise Exception(f"Table '{table_name}' does not exist: {e}") from e
                    else:
                        logger.warning(f"⚠️ Table '{table_name}' does not exist yet (first execution). Returning None.")
                        logger.info(f"💡 This is normal for first-time pipeline runs.")
                        return None
                else:
                    # Other errors still fail
                    logger.error(f"❌ Failed to capture schema for table '{table_name}': {e}")
                    raise Exception(f"Schema capture failed for table '{table_name}': {e}") from e
            
        except ValueError as e:
            logger.error(f"❌ Validation error: {e}")
            raise
        except Exception as e:
            logger.error(f"❌ Schema capture failed: {e}")
            raise Exception(f"Schema capture failed: {e}") from e

    def df_load_execution_details(
        self,
        run_id: int,
        table_name: str,
        other_details: str,
        remarks: str,
        postgres_conn,
        execution_detail_table_name: str
    ) -> None:
        """
        Load execution details to specified table.
        
        This function stores execution details like record counts, processing times,
        or any other metadata that needs to be tracked during pipeline execution.
        
        Args:
            run_id: Pipeline run identifier (required)
            table_name: Name of the table being processed (required)
            other_details: Additional details about the execution (required)
            remarks: Remarks or notes about the execution (required)
            postgres_conn: PostgreSQL connection object (required)
            execution_detail_table_name: Name of the table to store execution details (required)
            
        Raises:
            ValueError: If required parameters are missing
            Exception: If database operations fail
        """
        # Use instance logger
        logger = self.logger
        
        try:
            # ────────────────────────────────────────────────────────────────────────────────
            # 🛡️ Validate Parameters
            # ────────────────────────────────────────────────────────────────────────────────
            if not run_id or not table_name or not other_details or not remarks or not postgres_conn or not execution_detail_table_name:
                raise ValueError("❌ All parameters must be provided: run_id, table_name, other_details, remarks, postgres_conn, execution_detail_table_name.")
            
            # Generate current timestamp
            capture_timestamp = datetime.utcnow()
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 🔌 Use provided PostgreSQL connection
            # ────────────────────────────────────────────────────────────────────────────────
            cursor = postgres_conn.cursor()
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 📝 Insert execution detail record into specified table
            # ────────────────────────────────────────────────────────────────────────────────
            cursor.execute(f"""
                INSERT INTO {execution_detail_table_name}
                (run_id, resource_object_details, other_details, remarks)
                VALUES (%s, %s, %s, %s)
            """, (
                run_id,
                table_name,  # Store table name in resource_object_details
                other_details,
                remarks
            ))
            
            logger.info(f"📝 Execution details loaded for table '{table_name}'")
            logger.info(f"🔍 Run ID: {run_id}, Details: {other_details}, Remarks: {remarks}")
            
            # Log the column mapping used
            logger.info(f"✅ Used correct column mapping: run_id, resource_object_details, other_details, remarks")
            
            # ✅ Close cursor (connection is managed by caller)
            cursor.close()
            
            logger.info(f"✅ Execution details loaded successfully to '{execution_detail_table_name}'.")
            
        except ValueError as e:
            logger.error(f"❌ Validation error: {e}")
            raise
        except psycopg2.Error as e:
            logger.error(f"❌ Database error: {e}")
            raise Exception(f"Database operation failed: {e}") from e
        except Exception as e:
            logger.error(f"❌ Execution details loading failed: {e}")
            raise Exception(f"Execution details loading failed: {e}") from e

    def df_compare_schemas(
        self,
        before_df: Optional[DataFrame],
        after_df: Optional[DataFrame]
    ) -> str:
        """
        Compare before and after schemas and return change description.
        
        This function compares two DataFrames (before and after) and returns a string
        description of any schema changes detected.
        
        Args:
            before_df: DataFrame representing the schema before changes (can be None for first execution)
            after_df: DataFrame representing the schema after changes (can be None for first execution)
            
        Returns:
            String description of schema changes detected
            
        Raises:
            ImportError: If PySpark is not available
            ValueError: If required parameters are missing
            Exception: If schema comparison fails
        """
        # Use instance logger
        logger = self.logger
        
        try:
            # ────────────────────────────────────────────────────────────────────────────────
            # 🛡️ Validate Parameters
            # ────────────────────────────────────────────────────────────────────────────────
            if not PYSPARK_AVAILABLE:
                raise ImportError("❌ PySpark is required for schema comparison functionality")
            
            # Handle first execution scenarios
            if before_df is None and after_df is None:
                logger.info("🆕 First execution detected - no previous schema to compare")
                return "🆕 First execution - no previous schema to compare"
            
            if before_df is None:
                logger.info("🆕 First execution detected - comparing with current schema only")
                # Extract schema from after_df to show what we have
                after_fields = set([row['col_name'] for row in after_df.collect() if row['col_name'] is not None])
                return f"🆕 First execution - initial schema has {len(after_fields)} columns: {', '.join(sorted(after_fields))}"
            
            if after_df is None:
                logger.warning("⚠️ Current schema is None - cannot compare")
                return "⚠️ Current schema is None - cannot compare"
            
            logger.info("📊 Comparing before and after schemas...")
            
            # ────────────────────────────────────────────────────────────────────────────────
            # 🔍 Extract schema information from DataFrames
            # ────────────────────────────────────────────────────────────────────────────────
            try:
                # Get schema information from DESCRIBE output DataFrames
                # DESCRIBE returns DataFrame with columns: col_name, data_type, comment
                
                # Convert to sets for comparison - extract column names from DESCRIBE output
                before_fields = set([row['col_name'] for row in before_df.collect() if row['col_name'] is not None])
                after_fields = set([row['col_name'] for row in after_df.collect() if row['col_name'] is not None])
                
                # Debug logging
                logger.info(f"🔍 Before fields count: {len(before_fields)}")
                logger.info(f"🔍 After fields count: {len(after_fields)}")
                logger.info(f"🔍 Before fields: {sorted(before_fields)}")
                logger.info(f"🔍 After fields: {sorted(after_fields)}")
                
                # Find added columns
                added_columns = after_fields - before_fields
                
                # Find removed columns
                removed_columns = before_fields - after_fields
                
                # Debug logging for changes
                logger.info(f"🔍 Added columns: {sorted(added_columns)}")
                logger.info(f"🔍 Removed columns: {sorted(removed_columns)}")
                
                # Find modified columns (same name, different type)
                common_columns = before_fields & after_fields
                modified_columns = []
                
                # Create lookup dictionaries for easier comparison
                before_data = {row['col_name']: row['data_type'] for row in before_df.collect() if row['col_name'] is not None}
                after_data = {row['col_name']: row['data_type'] for row in after_df.collect() if row['col_name'] is not None}
                
                for field_name in common_columns:
                    before_type = before_data.get(field_name)
                    after_type = after_data.get(field_name)
                    
                    if before_type != after_type:
                        modified_columns.append({
                            'column': field_name,
                            'before_type': str(before_type),
                            'after_type': str(after_type)
                        })
                
                # ────────────────────────────────────────────────────────────────────────────────
                # 📝 Generate change description
                # ────────────────────────────────────────────────────────────────────────────────
                change_description = []
                
                if added_columns:
                    change_description.append(f"➕ Added columns: {', '.join(sorted(added_columns))}")
                
                if removed_columns:
                    change_description.append(f"➖ Removed columns: {', '.join(sorted(removed_columns))}")
                
                if modified_columns:
                    for mod in modified_columns:
                        change_description.append(f"🔄 Modified column '{mod['column']}': {mod['before_type']} → {mod['after_type']}")
                
                if not change_description:
                    change_description.append("✅ No schema changes detected")
                
                # Join all changes into final description
                final_description = " | ".join(change_description)
                
                logger.info(f"📊 Schema comparison completed")
                logger.info(f"📋 Changes: {final_description}")
                
                return final_description
                
            except Exception as e:
                logger.error(f"❌ Failed to compare schemas: {e}")
                raise Exception(f"Schema comparison failed: {e}") from e
            
        except ValueError as e:
            logger.error(f"❌ Validation error: {e}")
            raise
        except Exception as e:
            logger.error(f"❌ Schema comparison failed: {e}")
            raise Exception(f"Schema comparison failed: {e}") from e


# Convenience function for direct access
def df_get_execution_time_window(
    log_session_id: str,
    tenant_id: str,
    enterprise_id: str,
    pipeline_name: str,
    data_category: str,
    conn: psycopg2.extensions.connection,
    logger_instance: Optional[logging.Logger] = None
) -> Tuple[Optional[datetime], datetime]:
    """
    Retrieve time window from execution_checkpoint table using provided connection.
    
    Args:
        log_session_id: Log session identifier (used for end_ts when no records found)
        tenant_id: Tenant identifier
        enterprise_id: Enterprise identifier
        pipeline_name: Pipeline name for checkpoint lookup
        data_category: Category of data being processed
        conn: PostgreSQL connection object (from db_connector)
        logger_instance: Logger instance (optional)
        
    Returns:
        Tuple of (start_timestamp, end_timestamp)
        
    Raises:
        Exception: If database query fails or connection issues occur
    """
    manager = DFPipelineManager(logger_instance)
    return manager.df_get_execution_time_window(
        log_session_id, tenant_id, enterprise_id, 
        pipeline_name, data_category, conn
    )


def df_track_pipeline_execution(
    tenant_id: str,
    enterprise_id: str,
    pipeline_name: str,
    component_name: str,
    data_category: str,
    log_session_id: str,
    conn: psycopg2.extensions.connection,
    logger_instance: Optional[logging.Logger] = None
) -> int:
    """
    Track pipeline execution by creating audit records and managing checkpoints.
    
    This function performs the following operations:
    1. Validates required parameters
    2. Creates a new execution record in execution_audit_log
    3. Cleans up previous checkpoints for the same pipeline
    4. Updates execution_checkpoint with latest completed run
    5. Returns the new pipeline run_id
    
    Args:
        tenant_id: Tenant identifier (required)
        enterprise_id: Enterprise identifier (required)
        pipeline_name: Pipeline name (required)
        component_name: Component name (required)
        data_category: Data category for processing (required)
        log_session_id: Log session identifier (required)
        conn: PostgreSQL connection object (from db_connector)
        logger_instance: Logger instance (optional)
        
    Returns:
        New pipeline run_id (integer)
        
    Raises:
        ValueError: If required parameters are missing
        Exception: If database operations fail
        
    Example:
        >>> from data_foundation import pipeline_tracker, config_loader, db_connector
        
        >>> # Load config
        >>> config = config_loader.load_config("/lakehouse/default/Files/env/app_config.json")
        
        >>> # Get PostgreSQL connection
        >>> conn = db_connector.get_postgres_connection(config, logger_instance)
        
        >>> # Track pipeline execution
        >>> run_id = pipeline_tracker.track_pipeline_execution(
        ...     tenant_id="tenant_123",
        ...     enterprise_id="enterprise_456",
        ...     pipeline_name="telemetry_ingestion",
        ...     component_name="bronze_to_silver",
        ...     data_category="FullWaveform",
        ...     log_session_id="20250101_120000",
        ...     conn=conn,
        ...     logger_instance=logger
        ... )
        >>> print(f"Pipeline run ID: {run_id}")
    """
    manager = DFPipelineManager(logger_instance)
    return manager.df_track_pipeline_execution(
        tenant_id, enterprise_id, pipeline_name, component_name,
        data_category, log_session_id, conn
    )


def df_update_pipeline_failed_status(
    conn: psycopg2.extensions.connection,
    run_id: Optional[int] = None,
    tenant_id: Optional[str] = None,
    enterprise_id: Optional[str] = None,
    pipeline_name: Optional[str] = None,
    component_name: Optional[str] = None,
    data_category: Optional[str] = None,
    exception: Optional[Exception] = None,
    logger_instance: Optional[logging.Logger] = None
) -> None:
    """
    Update pipeline status to 'Failed' in execution_audit_log.
    
    This function updates the status of the latest 'In-Progress' pipeline run
    to 'Failed' and sets the end_time to the current timestamp.
    
    Args:
        conn: PostgreSQL connection object (from db_connector) (required)
        run_id: Specific run_id to update (optional, if provided, other parameters are ignored)
        tenant_id: Tenant identifier (required if run_id not provided)
        enterprise_id: Enterprise identifier (required if run_id not provided)
        pipeline_name: Pipeline name (required if run_id not provided)
        component_name: Component name (required if run_id not provided)
        data_category: Data category for processing (required if run_id not provided)
        exception: Exception object to append to additional_details (optional)
        logger_instance: Logger instance (optional)
        
    Raises:
        ValueError: If required parameters are missing
        Exception: If database operations fail
        
    Example:
        >>> from data_foundation import pipeline_tracker, config_loader, db_connector
        
        >>> # Load config
        >>> config = config_loader.load_config("/lakehouse/default/Files/env/app_config.json")
        
        >>> # Get PostgreSQL connection
        >>> conn = db_connector.get_postgres_connection(config, logger_instance)
        
        >>> # Update pipeline status to Failed
        >>> try:
        ...     # Your pipeline code here
        ...     pass
        ... except Exception as e:
        ...     pipeline_tracker.update_pipeline_failed_status(
        ...         tenant_id="tenant_123",
        ...         enterprise_id="enterprise_456",
        ...         pipeline_name="telemetry_ingestion",
        ...         component_name="bronze_to_silver",
        ...         data_category="FullWaveform",
        ...         exception=e,
        ...         conn=conn,
        ...         logger_instance=logger
        ...     )
    """
    manager = DFPipelineManager(logger_instance)
    return manager.df_update_pipeline_failed_status(
        conn, run_id, tenant_id, enterprise_id, pipeline_name, 
        component_name, data_category, exception, logger_instance
    )


def df_update_pipeline_completed_status(
    conn: psycopg2.extensions.connection,
    run_id: Optional[int] = None,
    tenant_id: Optional[str] = None,
    enterprise_id: Optional[str] = None,
    pipeline_name: Optional[str] = None,
    component_name: Optional[str] = None,
    data_category: Optional[str] = None,
    record_counts: Optional[str] = None,
    logger_instance: Optional[logging.Logger] = None
) -> None:
    """
    Update pipeline status to 'Completed' in execution_audit_log.
    
    This function updates the status of the latest 'In-Progress' pipeline run
    to 'Completed' and sets the end_time to the current timestamp.
    
    Args:
        conn: PostgreSQL connection object (from db_connector) (required)
        run_id: Specific run_id to update (optional, if provided, other parameters are ignored)
        tenant_id: Tenant identifier (required if run_id not provided)
        enterprise_id: Enterprise identifier (required if run_id not provided)
        pipeline_name: Pipeline name (required if run_id not provided)
        component_name: Component name (required if run_id not provided)
        data_category: Data category for processing (required if run_id not provided)
        record_counts: Number of records processed or table info (optional, string format)
        logger_instance: Logger instance (optional)
        
    Raises:
        ValueError: If required parameters are missing
        Exception: If database operations fail
        
    Example:
        >>> from data_foundation import pipeline_tracker, config_loader, db_connector
        
        >>> # Load config
        >>> config = config_loader.load_config("/lakehouse/default/Files/env/app_config.json")
        
        >>> # Get PostgreSQL connection
        >>> conn = db_connector.get_postgres_connection(config, logger_instance)
        
        >>> # Update pipeline status to Completed
        >>> pipeline_tracker.update_pipeline_completed_status(
        ...     tenant_id="tenant_123",
        ...     enterprise_id="enterprise_456",
        ...     pipeline_name="telemetry_ingestion",
        ...     component_name="bronze_to_silver",
        ...     data_category="FullWaveform",
        ...     record_counts="table_name: 1000",
        ...     conn=conn,
        ...     logger_instance=logger
        ... )
    """
    manager = DFPipelineManager(logger_instance)
    return manager.df_update_pipeline_completed_status(
        conn, run_id, tenant_id, enterprise_id, pipeline_name,
        component_name, data_category, record_counts, logger_instance
    ) 


def df_capture_schema(
    spark_session,
    table_name: str,
    fail_if_not_exists: bool = False,
    logger_instance: Optional[logging.Logger] = None
) -> Optional[DataFrame]:
    """
    Capture current schema and return as DataFrame.
    
    This function captures the current schema of a table and returns it as a DataFrame
    for schema tracking and comparison purposes.
    
    Args:
        spark_session: Spark session object (required)
        table_name: Name of the table whose schema is being captured (required)
        fail_if_not_exists: If True, function fails when table doesn't exist. 
                           If False, returns None for non-existent tables (default: False)
        logger_instance: Logger instance (optional)
        
    Returns:
        DataFrame containing the schema information, or None if table doesn't exist and fail_if_not_exists=False
        
    Raises:
        ImportError: If PySpark is not available
        ValueError: If required parameters are missing
        Exception: If schema capture fails and fail_if_not_exists=True
        
    Example:
        >>> from data_foundation import pipeline_tracker
        
        >>> # Capture schema for a table (won't fail if table doesn't exist)
        >>> schema_df = pipeline_tracker.df_capture_schema(
        ...     spark_session=spark,
        ...     table_name="my_table",
        ...     logger_instance=logger
        ... )
        >>> if schema_df is not None:
        ...     print(f"Schema columns: {schema_df.count()}")
        ... else:
        ...     print("Table doesn't exist yet (first execution)")
    """
    if not PYSPARK_AVAILABLE:
        raise ImportError("❌ PySpark is required for schema capture functionality")
    
    manager = DFPipelineManager(logger_instance)
    return manager.df_capture_schema(spark_session, table_name, fail_if_not_exists)


def df_load_execution_details(
    run_id: int,
    table_name: str,
    other_details: str,
    remarks: str,
    postgres_conn,
    execution_detail_table_name: str,
    logger_instance: Optional[logging.Logger] = None
) -> None:
    """
    Load execution details to specified table.
    
    This function stores execution details like record counts, processing times,
    or any other metadata that needs to be tracked during pipeline execution.
    
    Args:
        run_id: Pipeline run identifier (required)
        table_name: Name of the table being processed (required)
        other_details: Additional details about the execution (required)
        remarks: Remarks or notes about the execution (required)
        postgres_conn: PostgreSQL connection object (required)
        execution_detail_table_name: Name of the table to store execution details (required)
        logger_instance: Logger instance (optional)
        
    Raises:
        ValueError: If required parameters are missing
        Exception: If database operations fail
        
    Example:
        >>> from data_foundation import pipeline_tracker, db_connector
        
        >>> # Get PostgreSQL connection
        >>> conn = db_connector.get_postgres_connection(config, logger_instance)
        
        >>> # Load execution details
        >>> pipeline_tracker.load_execution_details(
        ...     run_id=123,
        ...     table_name="my_table",
        ...     other_details="Processed 1000 records",
        ...     remarks="Successful processing",
        ...     postgres_conn=conn,
        ...     execution_detail_table_name="execution_details",
        ...     logger_instance=logger
        ... )
    """
    manager = DFPipelineManager(logger_instance)
    return manager.df_load_execution_details(
        run_id, table_name, other_details, remarks, 
        postgres_conn, execution_detail_table_name
    )


def df_compare_schemas(
    before_df: Optional[DataFrame],
    after_df: Optional[DataFrame],
    logger_instance: Optional[logging.Logger] = None
) -> str:
    """
    Compare before and after schemas and return change description.
    
    This function compares two DataFrames (before and after) and returns a string
    description of any schema changes detected.
    
    Args:
        before_df: DataFrame representing the schema before changes (can be None for first execution)
        after_df: DataFrame representing the schema after changes (can be None for first execution)
        logger_instance: Logger instance (optional)
        
    Returns:
        String description of schema changes detected
        
    Raises:
        ImportError: If PySpark is not available
        ValueError: If required parameters are missing
        Exception: If schema comparison fails
        
    Example:
        >>> from data_foundation import pipeline_tracker
        
        >>> # Compare schemas before and after processing
        >>> changes = pipeline_tracker.df_compare_schemas(
        ...     before_df=before_schema_df,
        ...     after_df=after_schema_df,
        ...     logger_instance=logger
        ... )
        >>> print(f"Schema changes: { changes}")
        
        >>> # First execution (no previous schema)
        >>> changes = pipeline_tracker.df_compare_schemas(
        ...     before_df=None,  # No previous schema
        ...     after_df=current_schema_df,
        ...     logger_instance=logger
        ... )
        >>> print(f"First execution: { changes}")
    """
    if not PYSPARK_AVAILABLE:
        raise ImportError("❌ PySpark is required for schema comparison functionality")
    
    manager = DFPipelineManager(logger_instance)
    return manager.df_compare_schemas(before_df, after_df) 