"""
Database logging models for tracking batch jobs and events.

Provides SQLAlchemy models for comprehensive batch job tracking and event logging.
"""

from datetime import datetime, timezone
from typing import Any, Dict, Optional

from sqlalchemy import JSON, CheckConstraint, Column, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

# Use absolute import to avoid relative import issues
try:
    from shared_utils.database.models import BaseModel, TimestampMixin
except ImportError:
    # Fallback for when running tests
    from ..database.models import BaseModel, TimestampMixin

from .enums import BatchStatus, EventStatus, EventType


class EventMaster(BaseModel, TimestampMixin):
    """
    Master table for tracking batch jobs and their overall status.

    This table maintains the lifecycle and status of batch processing jobs,
    including metrics like record counts, duration, and overall status.
    """

    __tablename__ = "event_master"

    id = Column(Integer, primary_key=True, autoincrement=True)
    # Optional business key
    batch_id = Column(String(255), unique=True, nullable=True, index=True)
    batch_name = Column(String(255), nullable=False)
    batch_type = Column(String(100), index=True)

    # Status tracking
    status = Column(String(50), nullable=False, default=BatchStatus.STARTED.value, index=True)

    # Record statistics
    total_records = Column(Integer, default=0)
    processed_records = Column(Integer, default=0)
    failed_records = Column(Integer, default=0)
    success_records = Column(Integer, default=0)

    # Timing information
    start_time = Column(DateTime(timezone=True), default=func.now())
    end_time = Column(DateTime(timezone=True))
    duration_seconds = Column(Integer)

    # Metadata and context
    created_by = Column(String(255))
    batch_metadata = Column(JSON)  # JSON for cross-database compatibility
    error_message = Column(Text)

    # Relationships
    events = relationship("EventDetails", back_populates="batch", cascade="all, delete-orphan")

    # Constraints
    __table_args__ = (
        CheckConstraint("total_records >= 0", name="check_total_records_positive"),
        CheckConstraint("processed_records >= 0", name="check_processed_records_positive"),
        CheckConstraint("failed_records >= 0", name="check_failed_records_positive"),
        CheckConstraint("success_records >= 0", name="check_success_records_positive"),
        CheckConstraint("duration_seconds >= 0", name="check_duration_positive"),
        Index("idx_event_master_status_created", "status", "created_at"),
        Index("idx_event_master_batch_type_status", "batch_type", "status"),
    )

    def __repr__(self):
        return f"<EventMaster(batch_id='{self.batch_id}', status='{self.status}')>"

    def start_batch(self, created_by: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None):
        """Mark batch as started."""
        self.status = BatchStatus.RUNNING.value
        self.start_time = datetime.now(timezone.utc)
        if created_by:
            self.created_by = created_by
        if metadata:
            self.batch_metadata = metadata

    def complete_batch(self, success: bool = True, error_message: Optional[str] = None):
        """Mark batch as completed."""
        self.end_time = datetime.now(timezone.utc)
        if self.start_time:
            # Ensure both datetimes have timezone info
            start_time = self.start_time
            if start_time.tzinfo is None:
                start_time = start_time.replace(tzinfo=timezone.utc)

            duration = self.end_time - start_time
            self.duration_seconds = int(duration.total_seconds())

        if success:
            self.status = BatchStatus.COMPLETED.value
        else:
            self.status = BatchStatus.FAILED.value
            if error_message:
                self.error_message = error_message

    def cancel_batch(self, reason: Optional[str] = None):
        """Mark batch as cancelled."""
        self.status = BatchStatus.CANCELLED.value
        self.end_time = datetime.now(timezone.utc)
        if reason:
            self.error_message = reason

    def pause_batch(self):
        """Mark batch as paused."""
        self.status = BatchStatus.PAUSED.value

    def update_progress(self, processed: int = 0, failed: int = 0, success: int = 0):
        """Update batch progress counters."""
        if processed > 0:
            self.processed_records += processed
        if failed > 0:
            self.failed_records += failed
        if success > 0:
            self.success_records += success

    def get_progress_percentage(self) -> float:
        """Calculate progress percentage."""
        if self.total_records == 0:
            return 0.0
        return (self.processed_records / self.total_records) * 100.0

    def is_active(self) -> bool:
        """Check if batch is currently active."""
        return self.status in [BatchStatus.STARTED.value, BatchStatus.RUNNING.value, BatchStatus.PAUSED.value]

    def is_completed(self) -> bool:
        """Check if batch is completed (success or failure)."""
        return self.status in [BatchStatus.COMPLETED.value, BatchStatus.FAILED.value, BatchStatus.CANCELLED.value]


class EventDetails(BaseModel, TimestampMixin):
    """
    Details table for tracking individual events within batch jobs.

    This table stores granular events that occur during batch processing,
    providing detailed audit trail and debugging information.
    """

    __tablename__ = "event_details"

    id = Column(Integer, primary_key=True, autoincrement=True)
    # FK to EventMaster
    event_master_id = Column(Integer, ForeignKey("event_master.id", ondelete="CASCADE"), nullable=False, index=True)
    # Optional business key
    event_id = Column(String(255), nullable=True)
    batch_id = Column(String(255), nullable=True, index=True)  # for legacy/business reference
    event_type = Column(String(100), nullable=False, index=True)
    event_status = Column(String(50), nullable=False, default=EventStatus.INFO.value, index=True)
    event_message = Column(Text)
    event_data = Column(JSON)
    record_id = Column(String(255))
    step_name = Column(String(255), index=True)
    step_order = Column(Integer)
    execution_time_ms = Column(Integer)
    batch = relationship("EventMaster", back_populates="events")

    # Constraints
    __table_args__ = (
        CheckConstraint("execution_time_ms >= 0", name="check_execution_time_positive"),
        Index("idx_event_details_batch_event", "batch_id", "event_type"),
        Index("idx_event_details_status_created", "event_status", "created_at"),
        Index("idx_event_details_step_order", "batch_id", "step_order"),
    )

    def __repr__(self):
        return f"<EventDetails(batch_id='{self.batch_id}', event_type='{self.event_type}')>"

    @classmethod
    def create_info_event(
        cls,
        batch_id: str,
        message: str,
        event_type: str = EventType.CUSTOM.value,
        event_data: Optional[Dict[str, Any]] = None,
        **kwargs,
    ):
        """Create an informational event."""
        return cls(
            batch_id=batch_id,
            event_id=kwargs.get("event_id", f"{batch_id}_{datetime.now().timestamp()}"),
            event_type=event_type,
            event_status=EventStatus.INFO.value,
            event_message=message,
            event_data=event_data,
            **{k: v for k, v in kwargs.items() if k != "event_id"},
        )

    @classmethod
    def create_success_event(
        cls,
        batch_id: str,
        message: str,
        event_type: str = EventType.CUSTOM.value,
        event_data: Optional[Dict[str, Any]] = None,
        **kwargs,
    ):
        """Create a success event."""
        return cls(
            batch_id=batch_id,
            event_id=kwargs.get("event_id", f"{batch_id}_{datetime.now().timestamp()}"),
            event_type=event_type,
            event_status=EventStatus.SUCCESS.value,
            event_message=message,
            event_data=event_data,
            **{k: v for k, v in kwargs.items() if k != "event_id"},
        )

    @classmethod
    def create_error_event(
        cls,
        batch_id: str,
        message: str,
        event_type: str = EventType.ERROR_HANDLE.value,
        event_data: Optional[Dict[str, Any]] = None,
        **kwargs,
    ):
        """Create an error event."""
        return cls(
            batch_id=batch_id,
            event_id=kwargs.get("event_id", f"{batch_id}_{datetime.now().timestamp()}"),
            event_type=event_type,
            event_status=EventStatus.ERROR.value,
            event_message=message,
            event_data=event_data,
            **{k: v for k, v in kwargs.items() if k != "event_id"},
        )

    @classmethod
    def create_warning_event(
        cls,
        batch_id: str,
        message: str,
        event_type: str = EventType.CUSTOM.value,
        event_data: Optional[Dict[str, Any]] = None,
        **kwargs,
    ):
        """Create a warning event."""
        return cls(
            batch_id=batch_id,
            event_id=kwargs.get("event_id", f"{batch_id}_{datetime.now().timestamp()}"),
            event_type=event_type,
            event_status=EventStatus.WARNING.value,
            event_message=message,
            event_data=event_data,
            **{k: v for k, v in kwargs.items() if k != "event_id"},
        )

    def set_execution_time(self, start_time: datetime, end_time: Optional[datetime] = None):
        """Set execution time in milliseconds."""
        if end_time is None:
            end_time = datetime.now(timezone.utc)

        if start_time.tzinfo is None:
            start_time = start_time.replace(tzinfo=timezone.utc)
        if end_time.tzinfo is None:
            end_time = end_time.replace(tzinfo=timezone.utc)

        duration = end_time - start_time
        self.execution_time_ms = int(duration.total_seconds() * 1000)
