"""
Database logging module for tracking batch jobs and events.

This module provides comprehensive logging capabilities for batch processing jobs,
including batch lifecycle management, event tracking, and performance monitoring.

Key Components:
- EventMaster: Tracks batch job metadata and status
- EventDetails: Tracks individual events within batches
- DatabaseLogger: High-level service for batch operations
- Decorators: Automatic logging for common operations

Usage:
    from shared_utils.database_logging import DatabaseLogger, log_batch_job

    # Initialize logger
    db_logger = DatabaseLogger(session)

    # Use decorator for automatic batch logging
    @log_batch_job(batch_name="Data Processing", batch_type="ETL")
    def process_data(db_logger, batch_id, data):
        # Your processing logic here
        pass
"""

# Import all components
from .decorators import (
    log_batch_job,
    log_database_operation,
    log_external_api_call,
    log_processing_step,
    log_record_processing,
)
from .enums import BatchStatus, EventStatus, EventType
from .models import EventDetails, EventMaster
from .repository import EventDetailsRepository, EventMasterRepository
from .service import DatabaseLogger
from .df_pipeline_tracker import (
    DFPipelineManager,
    df_get_execution_time_window,
    df_track_pipeline_execution,
    df_update_pipeline_failed_status,
    df_update_pipeline_completed_status,
    df_capture_schema,
    df_load_execution_details,
    df_compare_schemas,
)

__all__ = [
    # Models
    "EventMaster",
    "EventDetails",
    # Service
    "DatabaseLogger",
    # Repositories
    "EventMasterRepository",
    "EventDetailsRepository",
    # Enums
    "BatchStatus",
    "EventStatus",
    "EventType",
    # Decorators
    "log_batch_job",
    "log_processing_step",
    "log_record_processing",
    "log_external_api_call",
    "log_database_operation",
    # Data Foundation specific pipeline tracking functions and class
    "DFPipelineManager",
    "df_get_execution_time_window",
    "df_track_pipeline_execution",
    "df_update_pipeline_failed_status",
    "df_update_pipeline_completed_status",
    "df_capture_schema",
    "df_load_execution_details",
    "df_compare_schemas",
]
