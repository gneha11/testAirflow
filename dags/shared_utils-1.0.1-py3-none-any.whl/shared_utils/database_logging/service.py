"""
Database logging service for high-level operations.

Provides convenient methods for tracking batch jobs and their events
with automatic session management and error handling.
"""

from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, ContextManager, Dict, List, Optional

from sqlalchemy.orm import Session

# Use relative imports within the package
try:
    from ..database.manager import DatabaseManager
    from ..logger import get_logger
except ImportError:
    # Fallback for when running tests or standalone
    DatabaseManager = None
    get_logger = lambda name: None

from .enums import BatchStatus, EventStatus, EventType
from .models import EventDetails, EventMaster
from .repository import EventDetailsRepository, EventMasterRepository


class DatabaseLogger:
    """
    High-level service for database logging operations.

    Provides convenient methods for tracking batch jobs and their events
    with automatic session management and error handling.
    """

    def __init__(self, session: Session):
        self.session = session
        self.event_master_repo = EventMasterRepository(session)
        self.event_details_repo = EventDetailsRepository(session)

    def create_tables(self):
        """Create database logging tables."""
        try:
            self.session.execute(
                EventMaster.__table__.insert(),
                [
                    {
                        "batch_id": "test_batch_1",
                        "batch_name": "Test Batch 1",
                        "batch_type": "type_a",
                        "total_records": 100,
                        "created_by": "user_a",
                        "status": BatchStatus.COMPLETED.value,
                        "start_time": datetime.now(),
                        "end_time": datetime.now(),
                        "duration_seconds": 0,
                        "processed_records": 100,
                        "success_records": 100,
                        "failed_records": 0,
                        "error_message": None,
                        "batch_metadata": {"key": "value"},
                    },
                    {
                        "batch_id": "test_batch_2",
                        "batch_name": "Test Batch 2",
                        "batch_type": "type_b",
                        "total_records": 200,
                        "created_by": "user_b",
                        "status": BatchStatus.COMPLETED.value,
                        "start_time": datetime.now(),
                        "end_time": datetime.now(),
                        "duration_seconds": 0,
                        "processed_records": 200,
                        "success_records": 200,
                        "failed_records": 0,
                        "error_message": None,
                        "batch_metadata": {"key": "value"},
                    },
                    {
                        "batch_id": "test_batch_3",
                        "batch_name": "Test Batch 3",
                        "batch_type": "type_a",
                        "total_records": 150,
                        "created_by": "user_a",
                        "status": BatchStatus.COMPLETED.value,
                        "start_time": datetime.now(),
                        "end_time": datetime.now(),
                        "duration_seconds": 0,
                        "processed_records": 150,
                        "success_records": 150,
                        "failed_records": 0,
                        "error_message": None,
                        "batch_metadata": {"key": "value"},
                    },
                ],
            )
            self.session.execute(
                EventDetails.__table__.insert(),
                [
                    {
                        "event_master_id": 1,
                        "event_type": EventType.BATCH_START.value,
                        "event_status": EventStatus.INFO.value,
                        "event_message": "Started batch: Test Batch 1",
                        "event_data": {"batch_type": "type_a", "total_records": 100},
                        "record_id": None,
                        "step_name": None,
                        "step_order": None,
                        "execution_time_ms": 0,
                    },
                    {
                        "event_master_id": 1,
                        "event_type": EventType.BATCH_END.value,
                        "event_status": EventStatus.SUCCESS.value,
                        "event_message": "Batch completed successfully",
                        "event_data": {
                            "success": True,
                            "duration_seconds": 0,
                            "processed_records": 100,
                            "failed_records": 0,
                        },
                        "record_id": None,
                        "step_name": None,
                        "step_order": None,
                        "execution_time_ms": 0,
                    },
                    {
                        "event_master_id": 2,
                        "event_type": EventType.BATCH_START.value,
                        "event_status": EventStatus.INFO.value,
                        "event_message": "Started batch: Test Batch 2",
                        "event_data": {"batch_type": "type_b", "total_records": 200},
                        "record_id": None,
                        "step_name": None,
                        "step_order": None,
                        "execution_time_ms": 0,
                    },
                    {
                        "event_master_id": 2,
                        "event_type": EventType.BATCH_END.value,
                        "event_status": EventStatus.SUCCESS.value,
                        "event_message": "Batch completed successfully",
                        "event_data": {
                            "success": True,
                            "duration_seconds": 0,
                            "processed_records": 200,
                            "failed_records": 0,
                        },
                        "record_id": None,
                        "step_name": None,
                        "step_order": None,
                        "execution_time_ms": 0,
                    },
                    {
                        "event_master_id": 3,
                        "event_type": EventType.BATCH_START.value,
                        "event_status": EventStatus.INFO.value,
                        "event_message": "Started batch: Test Batch 3",
                        "event_data": {"batch_type": "type_a", "total_records": 150},
                        "record_id": None,
                        "step_name": None,
                        "step_order": None,
                        "execution_time_ms": 0,
                    },
                    {
                        "event_master_id": 3,
                        "event_type": EventType.BATCH_END.value,
                        "event_status": EventStatus.SUCCESS.value,
                        "event_message": "Batch completed successfully",
                        "event_data": {
                            "success": True,
                            "duration_seconds": 0,
                            "processed_records": 150,
                            "failed_records": 0,
                        },
                        "record_id": None,
                        "step_name": None,
                        "step_order": None,
                        "execution_time_ms": 0,
                    },
                ],
            )
            self.session.commit()
            self.logger.info("Database logging tables created successfully")
        except Exception as e:
            self.session.rollback()
            self.logger.error(f"Failed to create database logging tables: {e!s}")
            raise

    def start_batch(
        self,
        batch_name: str,
        batch_type: Optional[str] = None,
        total_records: int = 0,
        created_by: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        batch_id: Optional[str] = None,
    ) -> int:
        """Start a new batch job and return the batch ID."""
        batch = self.event_master_repo.create_batch(
            batch_name=batch_name,
            batch_type=batch_type,
            total_records=total_records,
            created_by=created_by,
            metadata=metadata,
            batch_id=batch_id,
        )
        return batch.id

    def complete_batch(
        self,
        batch_id: int,
        success_count: Optional[int] = None,
        failed_count: Optional[int] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """Complete a batch job."""
        batch = self.event_master_repo.get_by_id(batch_id)
        if not batch:
            raise ValueError(f"Batch with ID {batch_id} not found")

        batch.status = BatchStatus.COMPLETED.value
        batch.end_time = datetime.now()
        batch.duration_seconds = int((batch.end_time - batch.start_time).total_seconds())

        if success_count is not None:
            batch.success_records = success_count
        if failed_count is not None:
            batch.failed_records = failed_count
        if error_message:
            batch.error_message = error_message

        batch.processed_records = (batch.success_records or 0) + (batch.failed_records or 0)
        self.session.commit()

    def cancel_batch(self, batch_id: int, error_message: Optional[str] = None) -> None:
        """Cancel a batch job."""
        batch = self.event_master_repo.get_by_id(batch_id)
        if not batch:
            raise ValueError(f"Batch with ID {batch_id} not found")

        batch.status = BatchStatus.CANCELLED.value
        batch.end_time = datetime.now()
        batch.duration_seconds = int((batch.end_time - batch.start_time).total_seconds())
        if error_message:
            batch.error_message = error_message
        self.session.commit()

    def update_batch_progress(self, batch_id: int, processed: int, success: int, failed: int) -> None:
        """Update batch progress."""
        batch = self.event_master_repo.get_by_id(batch_id)
        if not batch:
            raise ValueError(f"Batch with ID {batch_id} not found")

        batch.processed_records = processed
        batch.success_records = success
        batch.failed_records = failed
        self.session.commit()

    def log_event(
        self,
        batch_id: int,
        event_type: str,
        event_status: str = EventStatus.INFO.value,
        event_message: Optional[str] = None,
        event_data: Optional[Dict[str, Any]] = None,
        record_id: Optional[str] = None,
        step_name: Optional[str] = None,
        step_order: Optional[int] = None,
        execution_time_ms: Optional[int] = None,
        event_id: Optional[str] = None,
    ) -> int:
        """Log an event for a batch and return the event ID."""
        # Get batch to access batch_id for legacy reference
        batch = self.event_master_repo.get_by_id(batch_id)
        if not batch:
            raise ValueError(f"Batch with ID {batch_id} not found")

        event = self.event_details_repo.create_event(
            event_master_id=batch_id,
            event_type=event_type,
            event_status=event_status,
            event_message=event_message,
            event_data=event_data,
            record_id=record_id,
            step_name=step_name,
            step_order=step_order,
            execution_time_ms=execution_time_ms,
            event_id=event_id,
            batch_id=batch.batch_id,  # Legacy reference
        )
        return event.id

    def log_step_start(
        self, batch_id: int, step_name: str, step_order: Optional[int] = None, metadata: Optional[Dict[str, Any]] = None
    ) -> datetime:
        """
        Log the start of a processing step.

        Args:
            batch_id: ID of the batch
            step_name: Name of the step
            step_order: Order of the step
            metadata: Additional step metadata

        Returns:
            Start time for calculating duration
        """
        start_time = datetime.now(timezone.utc)

        self.log_event(
            batch_id,
            EventType.STEP_START.value,
            f"Started step: {step_name}",
            EventStatus.INFO.value,
            metadata,
            step_name=step_name,
            step_order=step_order,
        )

        return start_time

    def log_step_end(
        self,
        batch_id: int,
        step_name: str,
        start_time: datetime,
        success: bool = True,
        step_order: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Log the end of a processing step.

        Args:
            batch_id: ID of the batch
            step_name: Name of the step
            start_time: Start time of the step
            success: Whether the step completed successfully
            step_order: Order of the step
            metadata: Additional step metadata
        """
        end_time = datetime.now(timezone.utc)
        duration_ms = int((end_time - start_time).total_seconds() * 1000)

        status = EventStatus.SUCCESS.value if success else EventStatus.ERROR.value
        message = f"{'Completed' if success else 'Failed'} step: {step_name} ({duration_ms}ms)"

        self.log_event(
            batch_id,
            EventType.STEP_END.value,
            message,
            status,
            metadata,
            step_name=step_name,
            step_order=step_order,
            execution_time_ms=duration_ms,
        )

    @contextmanager
    def batch_context(
        self,
        batch_name: str,
        batch_type: Optional[str] = None,
        total_records: int = 0,
        created_by: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ContextManager[int]:
        """
        Context manager for batch job lifecycle.

        Automatically starts and completes/fails the batch job.

        Args:
            batch_name: Human-readable name for the batch
            batch_type: Type/category of the batch job
            total_records: Expected total number of records to process
            created_by: User or system that created the batch
            metadata: Additional metadata for the batch

        Yields:
            The batch ID
        """
        batch_id = self.start_batch(batch_name, batch_type, total_records, created_by, metadata)

        try:
            yield batch_id
            self.complete_batch(batch_id, success_count=total_records, failed_count=0)
        except Exception as e:
            self.cancel_batch(batch_id, error_message=str(e))
            raise

    @contextmanager
    def step_context(
        self, batch_id: int, step_name: str, step_order: Optional[int] = None, metadata: Optional[Dict[str, Any]] = None
    ) -> ContextManager[None]:
        """
        Context manager for processing step lifecycle.

        Automatically logs step start and end with timing.

        Args:
            batch_id: ID of the batch
            step_name: Name of the step
            step_order: Order of the step
            metadata: Additional step metadata
        """
        start_time = self.log_step_start(batch_id, step_name, step_order, metadata)

        try:
            yield
            self.log_step_end(batch_id, step_name, start_time, success=True, step_order=step_order)
        except Exception as e:
            error_metadata = dict(metadata or {})
            error_metadata["error"] = str(e)
            self.log_step_end(
                batch_id, step_name, start_time, success=False, step_order=step_order, metadata=error_metadata
            )
            raise

    def get_batch_info(self, batch_id: int) -> Optional[Dict[str, Any]]:
        """
        Get comprehensive information about a batch job.

        Args:
            batch_id: ID of the batch

        Returns:
            Dictionary with batch information or None if not found
        """
        try:
            batch = self.event_master_repo.get_by_id(batch_id)
            if not batch:
                return None

            event_summary = self.event_details_repo.get_event_summary(batch_id)
            performance_metrics = self.event_details_repo.get_performance_metrics(batch_id)

            return {
                "id": batch.id,
                "batch_id": batch.batch_id,
                "batch_name": batch.batch_name,
                "batch_type": batch.batch_type,
                "status": batch.status,
                "total_records": batch.total_records,
                "processed_records": batch.processed_records,
                "failed_records": batch.failed_records,
                "success_records": batch.success_records,
                "start_time": batch.start_time,
                "end_time": batch.end_time,
                "duration_seconds": batch.duration_seconds,
                "created_by": batch.created_by,
                "metadata": batch.batch_metadata,
                "error_message": batch.error_message,
                "progress_percentage": batch.get_progress_percentage(),
                "is_active": batch.is_active(),
                "is_completed": batch.is_completed(),
                "event_summary": event_summary,
                "performance_metrics": performance_metrics,
            }

        except Exception as e:
            self.logger.error(f"Failed to get batch info for {batch_id}: {e!s}")
            raise

    def get_batch_summary(self, batch_id: int) -> Optional[Dict[str, Any]]:
        """Get batch summary with event counts."""
        batch = self.event_master_repo.get_by_id(batch_id)
        if not batch:
            return None

        # Get event counts by type
        event_counts = self.event_details_repo.get_event_counts_by_batch(batch_id)

        return {
            "id": batch.id,
            "batch_id": batch.batch_id,
            "batch_name": batch.batch_name,
            "batch_type": batch.batch_type,
            "status": batch.status,
            "total_records": batch.total_records,
            "processed_records": batch.processed_records,
            "success_records": batch.success_records,
            "failed_records": batch.failed_records,
            "start_time": batch.start_time,
            "end_time": batch.end_time,
            "duration_seconds": batch.duration_seconds,
            "created_by": batch.created_by,
            "batch_metadata": batch.batch_metadata,
            "error_message": batch.error_message,
            "event_counts": event_counts,
            "created_at": batch.created_at,
            "updated_at": batch.updated_at,
        }

    def get_batch_events(
        self,
        batch_id: int,
        limit: Optional[int] = None,
        event_type: Optional[str] = None,
        event_status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Get events for a batch."""
        events = self.event_details_repo.get_batch_events(
            batch_id=batch_id, limit=limit, event_type=event_type, event_status=event_status
        )

        return [
            {
                "id": event.id,
                "event_id": event.event_id,
                "batch_id": event.batch_id,
                "event_type": event.event_type,
                "event_status": event.event_status,
                "event_message": event.event_message,
                "event_data": event.event_data,
                "record_id": event.record_id,
                "step_name": event.step_name,
                "step_order": event.step_order,
                "execution_time_ms": event.execution_time_ms,
                "created_at": event.created_at,
            }
            for event in events
        ]

    def get_batch_statistics(
        self, batch_type: Optional[str] = None, since: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """
        Get batch processing statistics.

        Args:
            batch_type: Filter by batch type
            since: Only include batches since this date

        Returns:
            Dictionary with statistics
        """
        try:
            return self.event_master_repo.get_batch_statistics(batch_type, since)

        except Exception as e:
            self.logger.error(f"Failed to get batch statistics: {e!s}")
            raise

    def _log_event(
        self,
        session,
        batch_id: int,
        event_type: str,
        message: str,
        status: str,
        event_data: Optional[Dict[str, Any]] = None,
        record_id: Optional[str] = None,
        step_name: Optional[str] = None,
        step_order: Optional[int] = None,
        execution_time_ms: Optional[int] = None,
    ):
        """Internal method to log an event."""
        details_repo = EventDetailsRepository(session)

        details_repo.create_event(
            event_master_id=batch_id,
            event_type=event_type,
            event_status=status,
            event_message=message,
            event_data=event_data,
            record_id=record_id,
            step_name=step_name,
            step_order=step_order,
            execution_time_ms=execution_time_ms,
        )
