"""
Repository classes for database logging operations.

Provides data access layer for EventMaster and EventDetails models
with specialized query methods for batch job tracking.
"""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import and_, asc, desc
from sqlalchemy.orm import Session

from ..database.repository import BaseRepository
from .enums import BatchStatus, EventStatus
from .models import EventDetails, EventMaster


class EventMasterRepository(BaseRepository):
    """Repository for EventMaster operations."""

    def __init__(self, session: Session):
        super().__init__(EventMaster, session)

    def create_batch(
        self,
        batch_name: str,
        batch_type: Optional[str] = None,
        total_records: int = 0,
        created_by: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        batch_id: Optional[str] = None,
    ) -> EventMaster:
        """Create a new batch job record."""
        batch = EventMaster(
            batch_name=batch_name,
            batch_type=batch_type,
            total_records=total_records,
            created_by=created_by,
            batch_metadata=metadata,
            status=BatchStatus.STARTED.value,
            batch_id=batch_id,
        )
        self.session.add(batch)
        self.session.commit()
        return batch

    def get_by_id(self, id: int) -> Optional[EventMaster]:
        """Get batch by ID."""
        return self.session.query(EventMaster).filter(EventMaster.id == id).first()

    def get_by_batch_id(self, batch_id: str) -> Optional[EventMaster]:
        """Get batch by batch_id."""
        return self.session.query(EventMaster).filter(EventMaster.batch_id == batch_id).first()

    def get_active_batches(self) -> List[EventMaster]:
        """Get all active (not completed) batches."""
        active_statuses = [BatchStatus.STARTED.value, BatchStatus.RUNNING.value, BatchStatus.PAUSED.value]
        return (
            self.session.query(EventMaster)
            .filter(EventMaster.status.in_(active_statuses))
            .order_by(desc(EventMaster.created_at))
            .all()
        )

    def get_batches_by_status(self, status: BatchStatus) -> List[EventMaster]:
        """Get batches by status."""
        return (
            self.session.query(EventMaster)
            .filter(EventMaster.status == status.value)
            .order_by(desc(EventMaster.created_at))
            .all()
        )

    def get_batches_by_type(self, batch_type: str, limit: Optional[int] = None) -> List[EventMaster]:
        """Get batches by type."""
        query = (
            self.session.query(EventMaster)
            .filter(EventMaster.batch_type == batch_type)
            .order_by(desc(EventMaster.created_at))
        )

        if limit:
            query = query.limit(limit)

        return query.all()

    def get_failed_batches(self, since: Optional[datetime] = None) -> List[EventMaster]:
        """Get failed batches, optionally since a specific date."""
        query = self.session.query(EventMaster).filter(EventMaster.status == BatchStatus.FAILED.value)

        if since:
            query = query.filter(EventMaster.created_at >= since)

        return query.order_by(desc(EventMaster.created_at)).all()

    def get_batch_statistics(
        self, batch_type: Optional[str] = None, since: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """Get batch processing statistics."""
        query = self.session.query(EventMaster)

        if batch_type:
            query = query.filter(EventMaster.batch_type == batch_type)

        if since:
            query = query.filter(EventMaster.created_at >= since)

        batches = query.all()

        if not batches:
            return {
                "total_batches": 0,
                "completed_batches": 0,
                "failed_batches": 0,
                "active_batches": 0,
                "total_records_processed": 0,
                "total_records_failed": 0,
                "average_duration_seconds": 0,
                "success_rate": 0.0,
            }

        completed = [b for b in batches if b.status == BatchStatus.COMPLETED.value]
        failed = [b for b in batches if b.status == BatchStatus.FAILED.value]
        active = [b for b in batches if b.is_active()]

        total_processed = sum(b.processed_records or 0 for b in batches)
        total_failed = sum(b.failed_records or 0 for b in batches)

        completed_durations = [b.duration_seconds for b in completed if b.duration_seconds]
        avg_duration = sum(completed_durations) / len(completed_durations) if completed_durations else 0

        success_rate = len(completed) / len(batches) * 100 if batches else 0

        return {
            "total_batches": len(batches),
            "completed_batches": len(completed),
            "failed_batches": len(failed),
            "active_batches": len(active),
            "total_records_processed": total_processed,
            "total_records_failed": total_failed,
            "average_duration_seconds": avg_duration,
            "success_rate": round(success_rate, 2),
        }

    def update_batch_status(
        self, batch_id: str, status: BatchStatus, error_message: Optional[str] = None
    ) -> Optional[EventMaster]:
        """Update batch status."""
        batch = self.get_by_batch_id(batch_id)
        if not batch:
            return None

        batch.status = status.value
        if error_message:
            batch.error_message = error_message

        if status in [BatchStatus.COMPLETED, BatchStatus.FAILED, BatchStatus.CANCELLED]:
            batch.end_time = datetime.now(timezone.utc)
            if batch.start_time:
                duration = batch.end_time - batch.start_time
                batch.duration_seconds = int(duration.total_seconds())

        self.session.commit()
        return batch

    def update_batch_progress(
        self, batch_id: str, processed: int = 0, failed: int = 0, success: int = 0
    ) -> Optional[EventMaster]:
        """Update batch progress counters."""
        batch = self.get_by_batch_id(batch_id)
        if not batch:
            return None

        batch.update_progress(processed, failed, success)
        self.session.commit()
        return batch

    def cleanup_old_batches(self, older_than_days: int = 30, keep_failed: bool = True) -> int:
        """Clean up old batch records."""
        cutoff_date = datetime.now(timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0
        ) - timezone.timedelta(days=older_than_days)

        query = self.session.query(EventMaster).filter(EventMaster.created_at < cutoff_date)

        if keep_failed:
            query = query.filter(EventMaster.status != BatchStatus.FAILED.value)

        count = query.count()
        query.delete(synchronize_session=False)
        self.session.commit()

        return count


class EventDetailsRepository(BaseRepository):
    """Repository for EventDetails operations."""

    def __init__(self, session: Session):
        super().__init__(EventDetails, session)

    def create_event(
        self,
        event_master_id: int,
        event_type: str,
        event_status: str = EventStatus.INFO.value,
        event_message: Optional[str] = None,
        event_data: Optional[Dict[str, Any]] = None,
        record_id: Optional[str] = None,
        step_name: Optional[str] = None,
        step_order: Optional[int] = None,
        execution_time_ms: Optional[int] = None,
        event_id: Optional[str] = None,
        batch_id: Optional[str] = None,
    ) -> EventDetails:
        """Create a new event record."""
        event = EventDetails(
            event_master_id=event_master_id,
            event_type=event_type,
            event_status=event_status,
            event_message=event_message,
            event_data=event_data,
            record_id=record_id,
            step_name=step_name,
            step_order=step_order,
            execution_time_ms=execution_time_ms,
            event_id=event_id,
            batch_id=batch_id,
        )
        self.session.add(event)
        self.session.commit()
        return event

    def get_by_id(self, id: int) -> Optional[EventDetails]:
        """Get event by ID."""
        return self.session.query(EventDetails).filter(EventDetails.id == id).first()

    def get_batch_events(
        self,
        batch_id: str,
        limit: Optional[int] = None,
        event_type: Optional[str] = None,
        event_status: Optional[str] = None,
    ) -> List[EventDetails]:
        """Get events for a specific batch."""
        query = self.session.query(EventDetails).filter(EventDetails.batch_id == batch_id)

        if event_type:
            query = query.filter(EventDetails.event_type == event_type)

        if event_status:
            query = query.filter(EventDetails.event_status == event_status)

        query = query.order_by(asc(EventDetails.created_at))

        if limit:
            query = query.limit(limit)

        return query.all()

    def get_error_events(self, batch_id: Optional[str] = None, since: Optional[datetime] = None) -> List[EventDetails]:
        """Get error events, optionally filtered by batch and date."""
        query = self.session.query(EventDetails).filter(EventDetails.event_status == EventStatus.ERROR.value)

        if batch_id:
            query = query.filter(EventDetails.batch_id == batch_id)

        if since:
            query = query.filter(EventDetails.created_at >= since)

        return query.order_by(desc(EventDetails.created_at)).all()

    def get_step_events(self, batch_id: str, step_name: str) -> List[EventDetails]:
        """Get events for a specific step in a batch."""
        return (
            self.session.query(EventDetails)
            .filter(and_(EventDetails.batch_id == batch_id, EventDetails.step_name == step_name))
            .order_by(asc(EventDetails.step_order), asc(EventDetails.created_at))
            .all()
        )

    def get_event_summary(self, batch_id: str) -> Dict[str, Any]:
        """Get event summary for a batch."""
        events = self.get_batch_events(batch_id)

        if not events:
            return {
                "total_events": 0,
                "event_types": {},
                "event_statuses": {},
                "steps": [],
                "error_count": 0,
                "warning_count": 0,
            }

        # Count by type
        type_counts = {}
        for event in events:
            type_counts[event.event_type] = type_counts.get(event.event_type, 0) + 1

        # Count by status
        status_counts = {}
        for event in events:
            status_counts[event.event_status] = status_counts.get(event.event_status, 0) + 1

        # Get unique steps
        steps = list(set(event.step_name for event in events if event.step_name))
        steps.sort()

        return {
            "total_events": len(events),
            "event_types": type_counts,
            "event_statuses": status_counts,
            "steps": steps,
            "error_count": status_counts.get(EventStatus.ERROR.value, 0),
            "warning_count": status_counts.get(EventStatus.WARNING.value, 0),
        }

    def get_performance_metrics(self, batch_id: str) -> Dict[str, Any]:
        """Get performance metrics for a batch."""
        events = (
            self.session.query(EventDetails)
            .filter(and_(EventDetails.batch_id == batch_id, EventDetails.execution_time_ms.isnot(None)))
            .all()
        )

        if not events:
            return {
                "total_timed_events": 0,
                "average_execution_time_ms": 0,
                "min_execution_time_ms": 0,
                "max_execution_time_ms": 0,
                "total_execution_time_ms": 0,
            }

        execution_times = [event.execution_time_ms for event in events]

        return {
            "total_timed_events": len(events),
            "average_execution_time_ms": sum(execution_times) / len(execution_times),
            "min_execution_time_ms": min(execution_times),
            "max_execution_time_ms": max(execution_times),
            "total_execution_time_ms": sum(execution_times),
        }

    def cleanup_old_events(self, older_than_days: int = 30) -> int:
        """Clean up old event records."""
        cutoff_date = datetime.now(timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0
        ) - timezone.timedelta(days=older_than_days)

        count = self.session.query(EventDetails).filter(EventDetails.created_at < cutoff_date).count()

        self.session.query(EventDetails).filter(EventDetails.created_at < cutoff_date).delete(synchronize_session=False)

        self.session.commit()
        return count
