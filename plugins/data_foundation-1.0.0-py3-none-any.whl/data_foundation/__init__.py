"""
Data Foundation Package.

A comprehensive data processing library for Microsoft Fabric environments.
Provides structured logging, JSON flattening, asset hierarchy processing, and telemetry ingestion.
"""

from . import logger
from . import json_exploder
from . import asset_hierarchy
from . import telemetry_ingestion
from . import bronze_to_silver
from . import config_loader
from . import pipeline_tracker
from . import db_connector
from . import db_queries
from . import config_refresh
from . import initial_setup


# Import functions for direct access
from .logger import get_logger, save_log_to_lakehouse, create_log_session_id
from .json_exploder import (
    flatten_json,
    save_with_schema_evolution,
    save_with_schema_evolution_deduplication
)
from .asset_hierarchy import sync_asset_hierarchy_from_gremlin
from .telemetry_ingestion import fetch_telemetry_data
from .bronze_to_silver import load_silver_raw_waveform_data, load_silver_calculated_waveform_data

# Import utility functions
from .config_loader import load_config
from .config_refresh import refresh_simulator_configs
from .pipeline_tracker import (
    PipelineManager, get_execution_time_window, track_pipeline_execution,
    update_pipeline_failed_status, update_pipeline_completed_status
)
from .db_connector import (
    get_postgres_connection, get_cosmos_container, get_mongodb_collection,
    DatabaseManager
)
from .db_queries import (
    BronzeToSilverQueries,
    AssetHierarchyQueries,
    TelemetryQueries
)
from .initial_setup import (
    LakehouseSetup,
    create_schemas,
    create_lakehouse,
    create_base_folders
)


__version__ = "1.0.0"

__all__ = [
    # Modules
    "logger",
    "json_exploder",
    "asset_hierarchy",
    "telemetry_ingestion",
    "bronze_to_silver",
    "config_loader",
    "pipeline_tracker",
    "db_connector",
    "initial_setup",
    # Functions
    "get_logger",
    "save_log_to_lakehouse",
    "create_log_session_id",
    "flatten_json",
    "save_with_schema_evolution",
    "save_with_schema_evolution_deduplication",
    "sync_asset_hierarchy_from_gremlin",
    "fetch_telemetry_data",
    "load_silver_raw_waveform_data",
    "load_silver_calculated_waveform_data",
    # Utility functions
    "load_config",
    "refresh_simulator_configs",
    "get_execution_time_window",
    "track_pipeline_execution",
    "update_pipeline_failed_status",
    "update_pipeline_completed_status",
    # Database functions
    "get_postgres_connection",
    "get_cosmos_container",
    "get_mongodb_collection",
    # Lakehouse setup functions
    "create_schemas",
    "create_lakehouse",
    "create_base_folders",
    # Classes
    "PipelineManager",
    "DatabaseManager",
    "LakehouseSetup",
    # SQL Query Classes
    "BronzeToSilverQueries",
    "AssetHierarchyQueries",
    "TelemetryQueries"
]
