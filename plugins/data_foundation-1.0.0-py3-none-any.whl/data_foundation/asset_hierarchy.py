"""
Asset Hierarchy Module for Microsoft Fabric.

This module provides functionality to fetch asset hierarchy from Azure Cosmos DB (GremlinDB),
build complete hierarchies by parsing scope strings, and update partitioned Delta tables
with auto-incrementing IDs and change detection via hash comparison.
"""

import json
import logging
import traceback
from datetime import datetime
from typing import Tuple, Optional, Any

# PySpark imports
try:
    from pyspark.sql import SparkSession, DataFrame
    from pyspark.sql.types import StructType, StructField, StringType, LongType, DoubleType
    from pyspark.sql.functions import (
        current_timestamp, col, lit, from_json, split, when, 
        size, sha2, concat_ws, row_number
    )
    from pyspark.sql.utils import AnalysisException
    from pyspark.sql.window import Window
    from delta.tables import DeltaTable
    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    DataFrame = None
    SparkSession = None

# Import centralized SQL queries
from .db_queries import AssetHierarchyQueries

# Azure Cosmos DB imports
try:
    from azure.cosmos import CosmosClient
    COSMOS_AVAILABLE = True
except ImportError:
    COSMOS_AVAILABLE = False

def fetch_sensor_data(spark_session, container, tenant_id: str, enterprise_id: str, logger: Optional[logging.Logger] = None) -> DataFrame:
        """
        Fetch sensor data for a given tenant and enterprise.
        
        Args:
            container: Cosmos DB container client
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            logger: Logger instance for tracking
            
        Returns:
            DataFrame containing processed sensor data with parsed scope hierarchy
            
        Raises:
            ValueError: If sensor data has invalid scope format
        """
        if logger:
            logger.info(f"📥 Querying sensor data for tenant: {tenant_id}, enterprise: {enterprise_id}")
        
        # Use centralized SQL query
        sensor_query = AssetHierarchyQueries.get_sensor_data(tenant_id, enterprise_id)

        results = list(container.query_items(query=sensor_query, enable_cross_partition_query=True))
        if logger:
            logger.info(f"📊 Retrieved {len(results)} sensor records.")

        schema = StructType([
            StructField("scope", StringType(), True),
            StructField("serialNumber", StringType(), True),
            StructField("tenantId", StringType(), True),
            StructField("objectSubType", StringType(), True),
            StructField("id", StringType(), True)
        ])

        df = spark_session.createDataFrame(results, schema=schema)

        try:
            df = df.withColumn("scope_array", split(col("scope"), "/"))
            df = df.withColumn("valid_scope", when(size(col("scope_array")) >= 7, True).otherwise(False))

            invalid_scopes = df.filter(col("valid_scope") == False).count()
            if invalid_scopes > 0:
                raise ValueError(f"{invalid_scopes} record(s) have invalid scope format.")

            df = df.withColumn("enterprise_id", col("scope_array")[1]) \
                   .withColumn("site_id", col("scope_array")[2]) \
                   .withColumn("area_id", col("scope_array")[3]) \
                   .withColumn("unit_id", col("scope_array")[4]) \
                   .withColumn("equipment_id", col("scope_array")[5]) \
                   .withColumn("sensor_id", col("scope_array")[6]) \
                   .drop("scope_array", "valid_scope")

            if logger:
                logger.info("✅ Sensor data processed successfully.")
            return df

        except Exception as e:
            if logger:
                logger.error(f"❌ Error processing sensor data: {e}")
            raise
    
def fetch_asset_data(spark_session, container, tenant_id: str, enterprise_id: str, logger: Optional[logging.Logger] = None) -> DataFrame:
        """
        Fetch non-sensor assets data for a given tenant and enterprise.
        
        Args:
            container: Cosmos DB container client
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            logger: Logger instance for tracking
            
        Returns:
            DataFrame containing asset data
        """
        if logger:
            logger.info(f"📥 Querying asset data for tenant: {tenant_id}, enterprise: {enterprise_id}")
        
        # Use centralized SQL query
        asset_query = AssetHierarchyQueries.get_asset_data(tenant_id, enterprise_id)

        results = list(container.query_items(query=asset_query, enable_cross_partition_query=True))
        if logger:
            logger.info(f"📊 Retrieved {len(results)} asset records.")

        schema = StructType([
            StructField("scope", StringType(), True),
            StructField("tenantId", StringType(), True),
            StructField("objectType", StringType(), True),
            StructField("label", StringType(), True),
            StructField("objectSubType", StringType(), True),
            StructField("id", StringType(), True)
        ])

        return spark_session.createDataFrame(results, schema=schema)
    
def run_cosmos_queries(spark_session, container, tenant_id: str, enterprise_id: str, logger: Optional[logging.Logger] = None) -> Tuple[DataFrame, DataFrame]:
        """
        Run both sensor and asset queries and return DataFrames.
        
        Args:
            spark_session: Spark session for data processing
            container: Cosmos DB container client
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            logger: Logger instance for tracking
            
        Returns:
            Tuple of (sensor_dataframe, asset_dataframe)
        """
        df_sensors = fetch_sensor_data(spark_session, container, tenant_id, enterprise_id, logger)
        df_assets = fetch_asset_data(spark_session, container, tenant_id, enterprise_id, logger)
        return df_sensors, df_assets
    
def full_asset_hierarchy(df_sensors: DataFrame, df_assets: DataFrame, logger: Optional[logging.Logger] = None) -> DataFrame:
        """
        Join sensor and asset data into full hierarchy.
        
        Args:
            df_sensors: DataFrame containing sensor data
            df_assets: DataFrame containing asset data
            logger: Logger instance for tracking
            
        Returns:
            DataFrame containing complete asset hierarchy
        """
        if logger:
            logger.info("🔗 Joining sensor and asset data into full hierarchy.")

        df_enterprise = df_assets.alias("enterprise")
        df_site = df_assets.alias("site")
        df_area = df_assets.alias("area")
        df_unit = df_assets.alias("unit")
        df_equipment = df_assets.alias("equipment")

        df_combined = df_sensors.alias("df") \
            .join(df_enterprise, col("enterprise.id") == col("df.enterprise_id"), how="left") \
            .join(df_site, col("site.id") == col("df.site_id"), how="left") \
            .join(df_area, col("area.id") == col("df.area_id"), how="left") \
            .join(df_unit, col("unit.id") == col("df.unit_id"), how="left") \
            .join(df_equipment, col("equipment.id") == col("df.equipment_id"), how="left") \
            .select(
                col("df.tenantId").alias("tenantId"),
                col("df.enterprise_id").alias("enterpriseId"),
                col("enterprise.label").alias("enterpriseName"),
                col("df.site_id").alias("siteId"),
                col("site.label").alias("siteName"),
                col("df.area_id").alias("areaId"),
                col("area.label").alias("areaName"),
                col("df.unit_id").alias("unitId"),
                col("unit.label").alias("unitName"),
                col("df.equipment_id").alias("equipmentId"),
                col("equipment.label").alias("equipmentName"),
                col("df.objectSubType").alias("sensorType"),
                col("df.sensor_id").alias("sensorId"),
                col("df.serialNumber").alias("serialNumber"),
                col("df.scope").alias("scope")
            ) \
            .orderBy(
                col("tenantId").asc(),
                col("enterpriseId").asc(),
                col("siteId").asc(),
                col("areaId").asc(),
                col("unitId").asc(),
                col("equipmentId").asc(),
                col("sensorId").asc()
            )

        if logger:
            logger.info("✅ Asset hierarchy assembled successfully.")
        return df_combined
    
def process_enterprise_assets(spark_session, container, tenant_id: str, enterprise_id: str, table_name: str, logger: Optional[logging.Logger] = None) -> None:
        """
        Main entry point: Fetch and process asset hierarchy for a specific tenant and enterprise.
        
        This function handles the complete workflow:
        1. Fetch sensor and asset data from Cosmos DB
        2. Build complete hierarchy
        3. Compute hash keys for change detection
        4. Update Delta table with safe MERGE operations
        5. Handle auto-incrementing IDs
        
        Args:
            spark_session: Spark session for data processing
            container: Cosmos DB container client
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            logger: Logger instance for tracking
            table_name: Target Delta table name for saving asset hierarchy data
            
        Raises:
            Exception: If processing fails
        """
        if logger:
            logger.info(f"🚀 Starting asset hierarchy fetch for tenant: {tenant_id}, enterprise: {enterprise_id}")
        
        # Fetch sensor and asset data
        df_sensors, df_assets = run_cosmos_queries(spark_session, container, tenant_id, enterprise_id, logger)

        if df_sensors.rdd.isEmpty():
            if logger:
                logger.warning("⚠️ No sensor data found. Exiting process.")
            return
        if df_assets.rdd.isEmpty():
            if logger:
                logger.warning("⚠️ No asset data found. Exiting process.")
            return

        df_hierarchy = full_asset_hierarchy(df_sensors, df_assets, logger)

        # Step 1: Add metadata columns
        df_new = df_hierarchy.withColumn("updated_at", current_timestamp())

        # Step 2: Compute hash_key by excluding updated_at
        business_cols = [c for c in df_new.columns if c != "updated_at"]
        df_new = df_new.withColumn("hash_key", sha2(concat_ws("||", *business_cols), 256))
        try:
            # Step 3: Load existing table if it exists
            if spark_session._jsparkSession.catalog().tableExists(table_name):
                df_existing = spark_session.table(table_name)
                
                # Ensure existing table has a valid hash_key column
                if 'hash_key' not in df_existing.columns:
                    existing_cols = [c for c in df_existing.columns if c != "updated_at"]
                    df_existing = df_existing.withColumn("hash_key", sha2(concat_ws("||", *existing_cols), 256))

                # Rename to avoid collision
                df_existing = df_existing.withColumnRenamed("hash_key", "existing_hash_key")
                
                # CRITICAL: Use business key JOIN for change detection
                df_diff = df_new.alias("new").join(
                    df_existing.alias("old"),
                    on=["tenantId", "enterpriseId", "siteId", "areaId", "unitId", "equipmentId", "sensorId"],
                    how="left"
                ).filter(
                    col("old.existing_hash_key").isNull() | (col("new.hash_key") != col("old.existing_hash_key"))
                ).select("new.*")

                if df_diff.rdd.isEmpty():
                    if logger:
                        logger.info("📦 No changes detected in asset hierarchy. Skipping write.")
                else:
                    if logger:
                        logger.info(f"🆕 Found {df_diff.count()} new or updated rows. Updating table.")
                    try:
                        # Get max existing ID
                        max_id = df_existing.agg({"id": "max"}).collect()[0][0]
                        max_id = max_id if max_id is not None else 0

                        # Assign new ID only to new records
                        window_spec = Window.orderBy(lit(1))
                        df_diff = df_diff.withColumn("id", row_number().over(window_spec) + lit(max_id))

                        # Register temp view
                        df_diff.createOrReplaceTempView("staging_updates")
                        
                        if logger:
                            logger.info(f"🔍 Staging {df_diff.count()} records for merge")

                        # Merge using centralized SQL query
                        merge_sql = AssetHierarchyQueries.get_merge_sql(table_name, "staging_updates")
                        
                        try:
                            spark_session.sql(merge_sql)
                            if logger:
                                logger.info("✅ MERGE operation completed successfully")
                                
                        except Exception as merge_error:
                            if logger:
                                logger.error(f"❌ MERGE operation failed: {merge_error}")
                            raise

                    except Exception as e:
                        if logger:
                            logger.error(f"❌ Error processing changes: {e}")
                        raise

            else:
                if logger:
                    logger.info("📁 Table not found. Creating and inserting all records.")

                desired_order = [
                    "id", "scope", "tenantId", "enterpriseId", "enterpriseName", "siteId", "siteName",
                    "areaId", "areaName", "unitId", "unitName", "equipmentId", "equipmentName", "sensorId", "sensorType",
                    "serialNumber", "updated_at", "hash_key" ]

                # Assign IDs to initial data
                window_spec = Window.orderBy(lit(1))
                df_new = df_new.withColumn("id", row_number().over(window_spec))

                df_reordered = df_new.select(*desired_order)

                # Write partitioned Delta table
                df_reordered.write.mode("overwrite") \
                    .format("delta") \
                    .partitionBy("tenantId", "enterpriseId") \
                    .saveAsTable(table_name)

            if logger:
                logger.info("✅ Asset hierarchy fetch, and storage complete.")

        except Exception as e:
            if logger:
                logger.error(f"❌ Failed to update asset hierarchy: {e}")
            raise


def sync_asset_hierarchy_from_gremlin(tenant_id: str, enterprise_id: str, container, table_name: str, logger: Optional[logging.Logger] = None, spark_session: Optional[Any] = None) -> None:
    """
    Sync complete asset hierarchy from Azure Cosmos DB (GremlinDB) to Delta table.
    
    This function performs a complete ETL process to extract asset hierarchy data from Cosmos DB GremlinDB,
    transform it into a structured format, and sync it into a partitioned Delta table with
    change detection, auto-incrementing IDs, MERGE operations for existing data, and automatic change tracking.
    
    **Process Flow:**
    1. **Extract**: Query sensor and asset data from Cosmos DB GremlinDB
    2. **Transform**: Build complete hierarchy by parsing scope strings and joining data
    3. **Sync**: Update Delta table with MERGE operations, change detection, and auto-incrementing IDs
    4. **Track Updates**: Automatically capture column-level changes for UPDATE operations by comparing old vs new state in asset_changes table for audit purposes
    
    **Data Sources:**
    - **Sensors**: Query Cosmos DB GremlinDB for sensor metadata with scope parsing
    - **Assets**: Query Cosmos DB GremlinDB for non-sensor assets (enterprise, site, area, unit, equipment)
    - **Hierarchy**: Join sensor and asset data to create complete asset hierarchy
    
    **Output Table Schema:**
    - tenantId, enterpriseId, enterpriseName
    - siteId, siteName, areaId, areaName
    - unitId, unitName, equipmentId, equipmentName
    - sensorId, sensorType, serialNumber, scope
    - id (auto-incrementing), updated_at, hash_key (for change detection)
    
    **Features:**
    - ✅ **Change Detection**: Hash-based comparison to detect new/updated records
    - ✅ **Auto-incrementing IDs**: Maintains unique IDs across updates
    - ✅ **Partitioned Storage**: Partitioned by tenantId and enterpriseId
    - ✅ **MERGE Operations**: Safe upsert with conflict resolution for existing data
    - ✅ **Schema Evolution**: Handles schema changes automatically
    - ✅ **Comprehensive Logging**: Detailed logging throughout the process
    - ✅ **Sync Capability**: Updates existing records and adds new ones
    - ✅ **Automatic UPDATE Tracking**: Captures column-level changes for UPDATE operations only (internal)
    
    Args:
        tenant_id: Tenant identifier (required for data filtering and partitioning)
        enterprise_id: Enterprise identifier (required for data filtering and partitioning)
        logger: Logger instance for comprehensive process tracking (optional, will create basic logger if not provided)
        container: Cosmos DB container client (must be provided from outside using db_connector)
        table_name: Target Delta table name (default: "asset_master.assets_heirarchy")
        spark_session: Spark session for data processing (if not provided, will be created)
        
    Raises:
        ImportError: If PySpark or Azure Cosmos DB dependencies are not available
        ValueError: If required parameters are missing or invalid
        Exception: If Cosmos DB GremlinDB queries fail or Delta table operations fail
        
    Example:
        >>> from data_foundation import asset_hierarchy, config_loader, db_connector
        >>> 
        >>> # Load config using config_loader
        >>> config = config_loader.load_config("/lakehouse/default/Files/env/app_config.json")
        >>> 
        >>> # Create container using db_connector (automatically extracts cosmos section)
        >>> container = db_connector.get_cosmos_container(config, logger_instance)
        >>> 
        >>> # Sync asset hierarchy from Gremlin DB (UPDATE change tracking happens automatically)
        >>> asset_hierarchy.sync_asset_hierarchy_from_gremlin(
        ...     tenant_id="tenant_123",
        ...     enterprise_id="enterprise_456",
        ...     logger=logger_instance,
        ...     container=container,
        ...     table_name="asset_master.assets_hierarchy"
        ... )
        >>> 
        >>> # Save logs
        >>> logger.save_log_to_lakehouse(logger_instance)
    """
    # Create logger if not provided
    if logger is None:
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
    
    try:
        # ────────────────────────────────────────────────────────────────────────────────
        # 🚀 Initialize Spark session
        # ────────────────────────────────────────────────────────────────────────────────
        if spark_session is None:
            if not PYSPARK_AVAILABLE:
                raise ImportError("PySpark is not available. Please install pyspark and delta-spark.")
            from pyspark.sql import SparkSession
            spark_session = SparkSession.builder.appName("fetch_from_gremlin").getOrCreate()
        
        logger.info("🔄 Triggered job to fetch asset hierarchy from Cosmos DB GremlinDB.")
        # ────────────────────────────────────────────────────────────────────────────────
        # 🔐 Container is provided from outside (created using db_connector)
        # ────────────────────────────────────────────────────────────────────────────────
        logger.info("🔐 Using provided Cosmos Gremlin DB container.")
        
        # Capture existing data BEFORE sync for change tracking
        df_existing = None
        if spark_session._jsparkSession.catalog().tableExists(table_name):
            df_existing = spark_session.table(table_name)
            # Convert to Pandas DataFrame to persist the BEFORE state
            df_existing_pandas = df_existing.toPandas()
        else:
            logger.info("📁 Table doesn't exist yet, no existing data to compare")
        
        # Process enterprise assets using function-based approach
        process_enterprise_assets(
            spark_session=spark_session,
            container=container,
            tenant_id=tenant_id,
            enterprise_id=enterprise_id,
            table_name=table_name,
            logger=logger
        )
        
        # ────────────────────────────────────────────────────────────────────────────────
        # 🔍 Automatic UPDATE Change Tracking (Internal - Not exposed to users)
        # ────────────────────────────────────────────────────────────────────────────────
        try:
            logger.info("🔍 Starting automatic UPDATE change tracking...")
            
            # Extract schema from main table name for changes table
            if "." in table_name:
                schema_name = table_name.split(".")[0]
                changes_table_name = f"{schema_name}.asset_changes"
            else:
                changes_table_name = "asset_master.asset_changes"
            
            logger.info(f"📋 Using changes table: {changes_table_name}")
            
            # Get the current timestamp for change tracking
            change_timestamp = spark_session.sql("SELECT current_timestamp() as ts").collect()[0]["ts"]
            
            # Load the data that was just synced (new state)
            df_new = spark_session.table(table_name)
            # Convert to Pandas DataFrame to persist the AFTER state
            df_new_pandas = df_new.toPandas()
            
            # Create changes table if it doesn't exist
            create_asset_changes_table(spark_session, changes_table_name, logger)
            
            # Capture changes automatically
            capture_asset_changes(
                spark_session=spark_session,
                df_new=df_new_pandas,  # Use the Pandas DataFrame
                df_existing=df_existing_pandas,  # Use the Pandas DataFrame
                change_timestamp=change_timestamp,
                table_name=changes_table_name,
                logger=logger
            )
            
            logger.info("✅ Automatic UPDATE change tracking completed successfully")
            
        except Exception as change_error:
            logger.error(f"⚠️ Change tracking encountered an error (sync continues): {change_error}")
            raise
        
        logger.info("✅ Asset hierarchy sync completed with automatic UPDATE change tracking.")
        
    except Exception as e:
        if logger:
            logger.error(f"❌ Error in sync_asset_hierarchy_from_gremlin: {e}", exc_info=True)
        raise


def create_asset_changes_table(spark_session, table_name: str, logger: Optional[logging.Logger] = None) -> None:
    """
    Create the asset changes tracking table if it doesn't exist.
    
    This table tracks all changes to asset hierarchy records including:
    - UPDATE operations (modified assets)
    - Column-level change tracking (old value vs new value)
    
    Args:
        spark_session: Spark session for data processing
        table_name: Target Delta table name for change tracking (required)
        logger: Logger instance for tracking
        
    Returns:
        None
    """
    if logger:
        logger.info(f"🏗️ Creating asset changes tracking table: {table_name}")
    
    try:
        # Check if table exists
        if not spark_session._jsparkSession.catalog().tableExists(table_name):
            create_table_sql = f"""
            CREATE TABLE IF NOT EXISTS {table_name} (
                change_id BIGINT,
                change_timestamp TIMESTAMP,
                asset_id BIGINT,
                column_name STRING,
                old_value STRING,
                new_value STRING
            ) USING DELTA
            """
            
            spark_session.sql(create_table_sql)
            
            if logger:
                logger.info(f"✅ Asset changes table created: {table_name}")
        else:
            if logger:
                logger.info(f"📋 Asset changes table already exists: {table_name}")
                
    except Exception as e:
        if logger:
            logger.error(f"❌ Failed to create asset changes table: {e}")
        raise


def capture_asset_changes(spark_session, df_new, df_existing, 
                         change_timestamp, table_name: str, 
                         logger: Optional[logging.Logger] = None) -> None:
    """
    Capture and store asset changes in the changes tracking table.
    
    This function compares new and existing data to identify:
    1. Modified records (UPDATE operations) with column-level changes
    2. Stores changes in the asset_changes table
    
    Note: INSERT operations are not captured as they can be identified by updated_at column.
    Only UPDATE operations with old_value vs new_value are tracked.
    
    Args:
        spark_session: Spark session for data processing
        df_new: New/updated asset data (can be PySpark DataFrame or Pandas DataFrame)
        df_existing: Existing asset data from the table (can be PySpark DataFrame or Pandas DataFrame)
        change_timestamp: Timestamp when the change occurred
        table_name: Target changes tracking table name (required)
        logger: Logger instance for tracking
        
    Returns:
        None
    """
    if logger:
        logger.info("🔍 Capturing asset UPDATE changes for tracking...")
    
    try:
        changes_data = []
        
        # Convert Pandas DataFrames back to PySpark DataFrames for processing
        if hasattr(df_new, 'toPandas'):  # It's already a PySpark DataFrame
            df_new_spark = df_new
        else:  # It's a Pandas DataFrame
            df_new_spark = spark_session.createDataFrame(df_new)
            
        if hasattr(df_existing, 'toPandas'):  # It's already a PySpark DataFrame
            df_existing_spark = df_existing
        else:  # It's a Pandas DataFrame
            df_existing_spark = spark_session.createDataFrame(df_existing)
        
        # Get business columns (exclude metadata columns)
        business_columns = [c for c in df_new_spark.columns if c not in ["updated_at", "hash_key", "id"]]
        
        # Only handle UPDATE operations (modified records) if we have existing data to compare
        if df_existing_spark is not None:
            if logger:
                logger.info(f"🔍 Comparing {df_new_spark.count()} new records with {df_existing_spark.count()} existing records")
            
            # Fix: Use proper column selection with aliases
            df_updates = df_new_spark.alias("new").join(
                df_existing_spark.alias("old"),
                on=["id"],
                how="inner"
            ).select(
                col("new.id"),
                *[col(f"old.{c}").alias(f"old_{c}") for c in business_columns],
                *[col(f"new.{c}").alias(f"new_{c}") for c in business_columns],
                col("old.hash_key").alias("old_hash_key"),
                col("new.hash_key").alias("new_hash_key")
            )
            
            df_updates = df_updates.filter(col("new_hash_key") != col("old_hash_key"))
            
            if logger:
                logger.info(f"🔍 Found {df_updates.count()} records with hash differences")
                
            if not df_updates.rdd.isEmpty():
                update_count = df_updates.count()
                if logger:
                    logger.info(f"🔄 Found {update_count} modified records (UPDATE operations)")
                
                # For each updated record, compare column values
                for row in df_updates.collect():
                    asset_id = row["id"]
                    
                    for col_name in business_columns:
                        old_col = f"old_{col_name}"
                        new_col = f"new_{col_name}"
                        
                        if old_col in row and new_col in row:
                            old_value = row[old_col]
                            new_value = row[new_col]
                            
                            # Only track if values actually changed
                            if old_value != new_value:
                                changes_data.append({
                                    "change_id": None,  # Will be auto-generated
                                    "change_timestamp": change_timestamp,
                                    "asset_id": asset_id,
                                    "column_name": col_name,
                                    "old_value": str(old_value) if old_value is not None else "NULL",
                                    "new_value": str(new_value) if new_value is not None else "NULL"
                                })
            else:
                if logger:
                    logger.info("📝 No UPDATE operations detected to track")
        else:
            if logger:
                logger.info("📝 No existing data to compare - skipping UPDATE tracking")
        
        if logger:
            logger.info(f"📊 Total changes detected: {len(changes_data)}")
        
        # Save changes to the tracking table
        if changes_data:
            if logger:
                logger.info(f"💾 Saving {len(changes_data)} column changes to tracking table")
            
            # Define explicit schema that matches the table creation SQL exactly
            # BUT exclude change_id since we're not providing it (Lakehouse handles it)
            from pyspark.sql.types import StructType, StructField, LongType, TimestampType, StringType
            
            changes_schema = StructType([
                # StructField("change_id", LongType(), True),           # BIGINT - NOT INCLUDED
                StructField("change_timestamp", TimestampType(), True), # TIMESTAMP
                StructField("asset_id", LongType(), True),            # BIGINT
                StructField("column_name", StringType(), True),       # STRING
                StructField("old_value", StringType(), True),         # STRING
                StructField("new_value", StringType(), True)          # STRING
            ])
            
            # Prepare data with proper type conversion (exclude change_id)
            prepared_changes_data = []
            for change in changes_data:
                prepared_change = {
                    # "change_id": None,  # NOT INCLUDED - Lakehouse handles this
                    "change_timestamp": change["change_timestamp"],
                    "asset_id": int(change["asset_id"]) if change["asset_id"] is not None else 0,  # Convert to int
                    "column_name": str(change["column_name"]),
                    "old_value": str(change["old_value"]),
                    "new_value": str(change["new_value"])
                }
                prepared_changes_data.append(prepared_change)
            
            # Create DataFrame with explicit schema
            changes_df = spark_session.createDataFrame(prepared_changes_data, schema=changes_schema)
            
            # Get max change_id from existing changes table for lakehouse environment (no auto-increment)
            try:
                if spark_session._jsparkSession.catalog().tableExists(table_name):
                    max_change_id_result = spark_session.table(table_name).agg({"change_id": "max"}).collect()[0][0]
                    max_change_id = max_change_id_result if max_change_id_result is not None else 0
                else:
                    max_change_id = 0
            except Exception:
                max_change_id = 0
            
            # Add sequential change_id for lakehouse environment (max + 1, max + 2, etc.)
            window_spec = Window.orderBy(lit(1))
            changes_df = changes_df.withColumn("change_id", row_number().over(window_spec) + lit(max_change_id))
            
            # CRITICAL: We need the change_id values but can't have column conflicts
            # Solution: Use INSERT SQL instead of DataFrame.write to avoid schema merging
            changes_df.createOrReplaceTempView("temp_changes")
            
            # Insert using SQL to avoid schema conflicts
            insert_sql = f"""
            INSERT INTO {table_name} 
            SELECT change_id, change_timestamp, asset_id, column_name, old_value, new_value
            FROM temp_changes
            """
            
            spark_session.sql(insert_sql)
            
            if logger:
                logger.info(f"✅ Successfully saved {len(changes_data)} column changes to {table_name}")
        else:
            if logger:
                logger.info("📝 No column changes detected to track")
                
    except Exception as e:
        if logger:
            logger.error(f"❌ Failed to capture asset changes: {e}")
        raise

 