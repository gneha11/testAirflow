import logging
from typing import List, Optional
#from notebookutils import mssparkutils, lakehouse
from pyspark.sql import SparkSession

class LakehouseSetup:
    def __init__(self, spark: SparkSession, logger: Optional[logging.Logger] = None) -> None:
        self.spark = spark
        self.logger = logger if logger is not None else self._configure_logger()

    # ──────────────────────────────────────────────────────────────
    # 🔧 Configure Logger
    # ──────────────────────────────────────────────────────────────
    def _configure_logger(self) -> logging.Logger:
        logger = logging.getLogger("lakehouse_setup")
        logger.setLevel(logging.INFO)
        logger.propagate = False

        if not logger.handlers:
            console_handler = logging.StreamHandler()
            formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)

        return logger

    # ──────────────────────────────────────────────────────────────
    # 📁 Check if folder exists
    # ──────────────────────────────────────────────────────────────
    def folder_exists(self, path: str) -> bool:
        try:
            from notebookutils import mssparkutils
            mssparkutils.fs.ls(path)
            return True
        except Exception as e:
            # Check if it's a "path not found" error (expected for non-existent folders)
            if "PathNotFound" in str(e) or "FileNotFoundException" in str(e) or "Not Found" in str(e):
                # This is expected - folder doesn't exist yet
                return False
            else:
                # This is an unexpected error
                self.logger.error(f"Unexpected error checking folder {path}: {e}")
                raise

    # ──────────────────────────────────────────────────────────────
    # 🏗️ Create Schemas
    # ──────────────────────────────────────────────────────────────
    def create_schemas(self, schemas: List[str]) -> None:
        for s in schemas:
            try:
                self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {s}")
                self.logger.info(f"✅ Schema '{s}' created or already exists.")
            except Exception as e:
                self.logger.error(f"❌ Failed to create schema '{s}': {str(e)}")

    # ──────────────────────────────────────────────────────────────
    # 📂 Create Base Folders
    # ──────────────────────────────────────────────────────────────
    def create_base_folder_structures(self, base_folders: List[str]) -> None:
        for artifact in base_folders:
            base_path = f"Files/{artifact}"
            try:
                from notebookutils import mssparkutils
                if not self.folder_exists(base_path):
                    mssparkutils.fs.mkdirs(base_path)
                    self.logger.info(f"✅ Created {artifact} folder: {base_path}")
                else:
                    self.logger.info(f"ℹ️ {artifact.capitalize()} folder already exists: {base_path}")
            except Exception as e:
                self.logger.error(f"❌ Failed to create folder '{artifact}': {e}")
                raise

    # ──────────────────────────────────────────────────────────────
    # 🏠 Create Lakehouse
    # ──────────────────────────────────────────────────────────────
    def create_lakehouse(self, lakehouse_name: str, description: str = "") -> bool:

        try:
            # Check if lakehouse already exists
            from notebookutils import lakehouse
            lakehouse.get(lakehouse_name)
            self.logger.info(f"ℹ️ Lakehouse '{lakehouse_name}' already exists.")
            return True
        except:
            # Lakehouse doesn't exist, create it
            from notebookutils import lakehouse
            try:
                lakehouse.create(lakehouse_name, description=description)
                self.logger.info(f"✅ Lakehouse '{lakehouse_name}' created successfully.")
                return True
            except Exception as e:
                self.logger.error(f"❌ Failed to create lakehouse '{lakehouse_name}': {str(e)}")
                return False


# ──────────────────────────────────────────────────────────────
# 🚀 Convenience Functions (Outside Class)
# ──────────────────────────────────────────────────────────────

def create_schemas(spark: SparkSession, schemas: List[str], logger: Optional[logging.Logger] = None) -> None:
    """Convenience function to create schemas"""
    setup = LakehouseSetup(spark, logger)
    setup.create_schemas(schemas)


def create_lakehouse(lakehouse_name: str, description: str = "", spark: Optional[SparkSession] = None, logger: Optional[logging.Logger] = None) -> bool:
    """Convenience function to create lakehouse"""
    setup = LakehouseSetup(spark, logger)
    return setup.create_lakehouse(lakehouse_name, description)


def create_base_folders(spark: SparkSession, base_folders: List[str], logger: Optional[logging.Logger] = None) -> None:
    """Convenience function to create base folders"""
    setup = LakehouseSetup(spark, logger)
    setup.create_base_folder_structures(base_folders)

