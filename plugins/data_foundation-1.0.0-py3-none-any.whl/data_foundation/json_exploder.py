"""
Fabric JSON Exploder Module.

This module provides functionality to flatten deeply nested JSON structures and save the output 
to a Fabric Lakehouse table, supporting schema evolution and optional partitioning with 
duplicate detection capabilities.
"""

from typing import List, Optional, Union
import logging

# PySpark imports
try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql.functions import col, explode_outer, lit, when
    from pyspark.sql.types import StructType, ArrayType
    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    DataFrame = None
    SparkSession = None


def flatten_json(df: DataFrame, logger: Optional[logging.Logger] = None) -> DataFrame:
    """
    Recursively flattens any nested JSON DataFrame by expanding structs and exploding arrays.

    This function iteratively processes the DataFrame until all nested structures (structs and arrays)
    are flattened into a single level. It handles deeply nested sensor or IoT data formats.

    Args:
        df: Input DataFrame with nested JSON structure.
        logger: Logger instance for tracking. If None, prints to console.

    Returns:
        Fully flattened DataFrame with all nested structures expanded.

    Raises:
        Exception: If flattening process fails.

    Example:
        >>> # Input DataFrame with nested structure
        >>> # {
        >>> #   "sensor": {
        >>> #     "id": "sensor1",
        >>> #     "readings": [{"temp": 25, "humidity": 60}]
        >>> #   }
        >>> # }
        >>> flattened_df = flatten_json(input_df, logger)
        >>> # Result: sensor_id, sensor_readings_temp, sensor_readings_humidity columns
    """
    if not PYSPARK_AVAILABLE:
        raise ImportError("PySpark is required for JSON flattening functionality")

    try:
        iteration = 0
        while True:
            # 🔍 Identify nested Structs or Arrays
            complex_fields = [
                (field.name, field.dataType)
                for field in df.schema.fields
                if isinstance(field.dataType, (StructType, ArrayType))
            ]

            # ✅ No more nested fields — exit loop
            if not complex_fields:
                msg = f"✅ JSON fully flattened in {iteration} iterations."
                if logger:
                    logger.info(msg)
                else:
                    print(msg)
                break

            # 🔁 Expand struct fields and explode arrays
            for col_name, data_type in complex_fields:
                if isinstance(data_type, StructType):
                    if logger:
                        logger.debug(f"Expanding struct column: {col_name}")
                    
                    # Expand struct by creating new columns for each subfield
                    expanded = [
                        col(f"{col_name}.{subfield.name}").alias(f"{col_name}_{subfield.name}")
                        for subfield in data_type.fields
                    ]
                    df = df.select("*", *expanded).drop(col_name)

                elif isinstance(data_type, ArrayType):
                    if logger:
                        logger.debug(f"Exploding array column: {col_name}")
                    
                    # Explode array to create separate rows for each element
                    df = df.withColumn(col_name, explode_outer(col(col_name)))

            iteration += 1

        return df

    except Exception as e:
        error_msg = f"❌ Failed to flatten JSON: {e}"
        if logger:
            logger.error(error_msg)
        else:
            print(error_msg)
        raise


def save_with_schema_evolution(
    df: DataFrame, 
    table_name: str, 
    partition_cols: Optional[List[str]] = None, 
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Saves a DataFrame to a Fabric Lakehouse Delta table with schema evolution and optional partitioning.

    This function handles both creating new tables and appending to existing tables with automatic
    schema evolution. It supports optional partitioning for better query performance.

    Args:
        df: The DataFrame to write.
        table_name: Target table name (e.g., bronze.sensor_data).
        partition_cols: Columns to partition by. Default is None.
        logger: Logger instance. If None, prints to console.

    Raises:
        Exception: If saving to table fails.

    Example:
        >>> save_with_schema_evolution(
        ...     df=flattened_df,
        ...     table_name="bronze.sensor_data",
        ...     partition_cols=["tenant_id", "date"],
        ...     logger=logger
        ... )
    """
    if not PYSPARK_AVAILABLE:
        raise ImportError("PySpark is required for table saving functionality")

    try:
        # Get Spark session from DataFrame
        spark = df.sparkSession

        if not spark.catalog.tableExists(table_name):
            # 🆕 Table does not exist — create it
            writer = df.write.format("delta").option("mergeSchema", "true")
            if partition_cols:
                writer = writer.partitionBy(*partition_cols)
            writer.mode("overwrite").saveAsTable(table_name)

            msg = f"✅ Created new table '{table_name}' with schema evolution."
            if logger:
                logger.info(msg)
            else:
                print(msg)

        else:
            # 🔁 Table exists — append with schema evolution
            df.write \
                .format("delta") \
                .mode("append") \
                .option("mergeSchema", "true") \
                .saveAsTable(table_name)

            msg = f"✅ Appended to existing table '{table_name}' with schema evolution."
            if logger:
                logger.info(msg)
            else:
                print(msg)

    except Exception as e:
        error_msg = f"❌ Failed to save DataFrame to table '{table_name}': {e}"
        if logger:
            logger.error(error_msg)
        else:
            print(error_msg)
        raise


def save_with_schema_evolution_deduplication(
    df: DataFrame, 
    table_name: str, 
    partition_cols: Optional[List[str]] = None, 
    dedup_cols: Optional[List[str]] = None, 
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Saves a DataFrame to a Fabric Lakehouse Delta table with schema evolution and duplicate detection.

    This function performs duplicate checking before writing data to prevent duplicate records.
    It optimizes the duplicate check using timestamp range filtering when possible.
    Only key fields are checked for duplicates, not the entire record.

    Args:
        df: DataFrame to write.
        table_name: Delta table name (e.g., bronze.sensor_data).
        partition_cols: Columns to partition by.
        dedup_cols: Columns to check for duplicates (e.g., ["sensorId", "timestamp"]).
        logger: Logger instance. If None, prints to console.

    Raises:
        ValueError: If duplicate records are found for the specified key columns.
        Exception: If saving to table fails.

    Example:
        >>> save_with_schema_evolution_deduplication(
        ...     df=flattened_df,
        ...     table_name="bronze.sensor_data",
        ...     partition_cols=["tenant_id", "date"],
        ...     dedup_cols=["sensorId", "timestamp"],
        ...     logger=logger
        ... )
    """
    if not PYSPARK_AVAILABLE:
        raise ImportError("PySpark is required for table saving functionality")

    try:
        # Get Spark session from DataFrame
        spark = df.sparkSession

        if not spark.catalog.tableExists(table_name):
            msg = f"🆕 Table '{table_name}' does not exist. Creating new table."
            if logger:
                logger.info(msg)
            else:
                print(msg)
            
            writer = df.write.format("delta").option("mergeSchema", "true")
            if partition_cols:
                writer = writer.partitionBy(*partition_cols)
            writer.mode("overwrite").saveAsTable(table_name)
            return

        # Table exists, perform duplicate check
        msg = f"✅ Table '{table_name}' exists. Checking for duplicate keys: {dedup_cols}"
        if logger:
            logger.info(msg)
        else:
            print(msg)

        # Get distinct key combinations from incoming data
        incoming_keys_df = df.select(*dedup_cols).distinct()

        # Optimization: Use timestamp range filter if timestamp is in dedup columns
        if "timestamp" in dedup_cols and "timestamp" in df.columns:
            # Get min/max timestamps and tenant/enterprise IDs for filtering
            min_ts = df.selectExpr("min(timestamp)").collect()[0][0]
            max_ts = df.selectExpr("max(timestamp)").collect()[0][0]
            tenant_id = df.selectExpr("Input_tenantId").distinct().collect()[0][0]
            enterprise_id = df.selectExpr("Input_enterpriseId").distinct().collect()[0][0]
            
            # Filter existing data by timestamp range and tenant/enterprise
            existing_df = (spark.table(table_name).filter(
                (col("timestamp") >= lit(min_ts)) &
                (col("timestamp") <= lit(max_ts)) &
                (col("Input_tenantId") == lit(tenant_id)) &
                (col("Input_enterpriseId") == lit(enterprise_id))
            ))
        else:
            # No timestamp optimization, use full table
            existing_df = spark.table(table_name)

        # Find existing records with same key combination
        existing_matched = existing_df.alias("existing") \
            .join(incoming_keys_df.alias("incoming_keys"), on=dedup_cols, how="inner")

        if existing_matched.count() > 0:
            raise ValueError(f"❌ Duplicate record found for key: [{dedup_cols}]. Aborting save.")

        # Safe to write - no duplicates found
        msg = f"💾 Writing data to table '{table_name}' (schema evolution enabled)."
        if logger:
            logger.info(msg)
        else:
            print(msg)
        
        writer = df.write.format("delta").option("mergeSchema", "true")
        if partition_cols:
            writer = writer.partitionBy(*partition_cols)
        writer.mode("append").saveAsTable(table_name)

        success_msg = f"✅ Successfully wrote to table '{table_name}'."
        if logger:
            logger.info(success_msg)
        else:
            print(success_msg)

    except Exception as e:
        error_msg = f"❌ Failed to save to table '{table_name}': {e}"
        if logger:
            logger.error(error_msg)
        else:
            print(error_msg)
        raise


 