"""
Configuration Refresh Module for Classification Engine
This module automatically refreshes configuration tables from Excel files stored in Fabric Lakehouse to PostgreSQL database.

Uses pandas with openpyxl to read Excel files and converts to Spark DataFrame for processing.
"""

import logging
from typing import Optional, Dict, Any
from pyspark.sql import SparkSession
import psycopg2
from psycopg2.extras import RealDictCursor
import pandas as pd


class ConfigRefresher:
    """
    Automatically refresh configuration tables from Excel files in Fabric Lakehouse to PostgreSQL database
    """
    
    def __init__(self, spark_session: SparkSession, postgres_connection, excel_file_path: str, logger_instance: Optional[logging.Logger] = None):
        """
        Initialize ConfigRefresher
        
        Args:
            spark_session: Active Spark session (for reading Excel from Lakehouse)
            postgres_connection: Active PostgreSQL connection from db_connector
            excel_file_path: Path to Excel file in Lakehouse
            logger_instance: Logger instance (optional)
        """
        self.spark = spark_session
        self.pg_conn = postgres_connection
        self.logger = logger_instance or self._create_basic_logger()
        
        # Excel file path in Fabric Lakehouse
        self.excel_file_path = excel_file_path
        
        # Table names in PostgreSQL (with schema)
        self.config_tables = {
            'config_master': 'df_config_master',
            'fault_simulator': 'df_config_fault_simulator',
            'sensor_metadata': 'df_config_sensor_metadata', 
            'data_collection': 'df_config_data_collection_report',
            'data_generation': 'df_config_data_generation_timings'
        }
    
    def _create_basic_logger(self) -> logging.Logger:
        """Create a basic logger instance"""
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def refresh_simulator_configs(self) -> Dict[str, str]:
        """
        Refresh all simulator configuration tables from Excel file to PostgreSQL
        
        Returns:
            Dictionary with refresh status for each table ('Success', 'Warning', or 'Failed')
        """
        self.logger.info("🔄 Starting configuration refresh from Excel to PostgreSQL...")
        
        try:
            # Check if Excel file exists
            if not self._excel_file_exists():
                raise FileNotFoundError(f"Excel file not found: {self.excel_file_path}")
            
            # Verify Excel structure first
            self.logger.info("🔍 Verifying Excel structure before refresh...")
            verification_results = self.verify_excel_structure()
            
            # Check if all expected sheets are found
            missing_sheets = [sheet for sheet, result in verification_results.items() if result['status'] != 'Found']
            if missing_sheets:
                self.logger.warning(f"⚠️ Missing sheets: {missing_sheets}")
                self.logger.warning("Proceeding with available sheets only...")
            
            # Create PostgreSQL tables if they don't exist
            self._ensure_postgres_tables_exist()
            
            # Get current status before refresh
            summary_before = self.get_config_summary()
            
            results = {}
            
            # Refresh each configuration table
            for table_key, table_name in self.config_tables.items():
                try:
                    self.logger.info(f"📊 Refreshing {table_name}...")
                    success, had_duplicates, new_records, duplicates_skipped = self._refresh_single_config(table_key, table_name)
                    
                    # Store detailed counts for audit logging
                    if not hasattr(self, 'detailed_counts'):
                        self.detailed_counts = {}
                    
                    self.detailed_counts[table_key] = {
                        'new_records': new_records,
                        'duplicates_skipped': duplicates_skipped
                    }
                    
                    # Determine the actual status based on what happened
                    if success:
                        if new_records > 0:
                            if duplicates_skipped > 0:
                                results[table_key] = 'Warning'
                                self.logger.warning(f"⚠️ {table_name} refreshed with some duplicates ({new_records} new records, {duplicates_skipped} duplicates skipped)")
                            else:
                                results[table_key] = 'Success'
                                self.logger.info(f"✅ {table_name} refreshed successfully ({new_records} new records)")
                        else:
                            if duplicates_skipped > 0:
                                results[table_key] = 'Warning'
                                self.logger.warning(f"⚠️ {table_name} processed but no new records inserted ({duplicates_skipped} duplicates found)")
                            else:
                                results[table_key] = 'Warning'
                                self.logger.warning(f"⚠️ {table_name} processed but no new records inserted")
                    else:
                        results[table_key] = 'Failed'
                        self.logger.error(f"❌ {table_name} refresh failed")
                        # Stop the entire refresh process for critical failures
                        raise ValueError(f"Critical failure in {table_name} refresh. Stopping entire process.")
                        
                except Exception as e:
                    results[table_key] = 'Failed'
                    self.logger.error(f"❌ Critical error refreshing {table_name}: {e}")
                    # Stop the entire refresh process for critical errors
                    raise
            
            # Get status after refresh
            summary_after = self.get_config_summary()
            
            # Store audit information
            self.store_config_audit(summary_after, results)
            
            # Log summary
            success_count = sum(1 for status in results.values() if status == 'Success')
            warning_count = sum(1 for status in results.values() if status == 'Warning')
            failed_count = sum(1 for status in results.values() if status == 'Failed')
            total_tables = len(results)
            
            self.logger.info(f"📊 Configuration refresh completed: {success_count}/{total_tables} tables updated successfully")
            
            # Log detailed status for each table
            for table_key, status in results.items():
                table_name = self.config_tables[table_key]
                if status == 'Success':
                    self.logger.info(f"  {table_key}: ✅ Success")
                elif status == 'Warning':
                    self.logger.info(f"  {table_key}: ⚠️ Warning (some duplicates)")
                elif status == 'Failed':
                    self.logger.info(f"  {table_key}: ❌ Failed")
            
            if warning_count > 0:
                self.logger.warning(f"⚠️ {warning_count} tables processed with some duplicate records")
            if failed_count > 0:
                self.logger.error(f"❌ {failed_count} tables failed to refresh")
            
            self.logger.info(f"📝 Audit information stored in df_config_audit_log")
            
            # Function completes successfully - no return needed
            
        except Exception as e:
            self.logger.error(f"❌ Configuration refresh failed: {e}")
            
            # Log detailed error information
            if "Critical timestamp parsing error" in str(e):
                self.logger.error("❌ Critical error: Timestamp parsing failed. Please check Excel data format.")
                self.logger.error("❌ Expected formats: YYYY-MM-DD HH:MM:SS, YYYY-MM-DD, MM/DD/YYYY, DD/MM/YYYY")
            elif "Critical failure" in str(e):
                self.logger.error("❌ Critical error: One or more tables failed to refresh. Process stopped.")
            elif "Data conversion failed" in str(e):
                self.logger.error("❌ Critical error: Data conversion failed. Process stopped.")
            else:
                self.logger.error("❌ Critical error: Unexpected system error. Process stopped.")
            
            raise
    
    def _excel_file_exists(self) -> bool:
        """Check if Excel file exists in Lakehouse using direct file access"""
        try:
            # Try to open the file directly (same approach as config_loader.py)
            with open(self.excel_file_path, 'rb') as f:
                # Just check if we can open it, don't need to read content
                pass
            self.logger.info(f"✅ Excel file found: {self.excel_file_path}")
            return True
        except FileNotFoundError:
            self.logger.warning(f"⚠️ Excel file not found: {self.excel_file_path}")
            return False
        except Exception as e:
            self.logger.error(f"❌ Error checking file existence: {e}")
            return False
    
    def _ensure_postgres_tables_exist(self) -> None:
        """Create PostgreSQL tables if they don't exist"""
        try:
            with self.pg_conn.cursor() as cursor:
                # Create config master table (first table - used for tag mapping)
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS df_config_master (
                        config_id INTEGER PRIMARY KEY,
                        config_name VARCHAR(255),
                        fault_name VARCHAR(255),
                        sensor_consideration VARCHAR(255)
                    )
                """)
                
                # Create fault simulator table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS df_config_fault_simulator (
                        config_id INTEGER,
                        config_name VARCHAR(255),
                        section VARCHAR(255),
                        parameter VARCHAR(255),
                        value TEXT,
                        PRIMARY KEY (config_id, parameter),
                        FOREIGN KEY (config_id) REFERENCES df_config_master(config_id)
                    )
                """)
                
                # Create sensor metadata table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS df_config_sensor_metadata (
                        sensor_config_id INTEGER,
                        sensor_name VARCHAR(255),
                        environment VARCHAR(255),
                        gateway_serial_number VARCHAR(255),
                        sensor_serial_number VARCHAR(255) PRIMARY KEY,
                        channel INTEGER,
                        couple VARCHAR(50),
                        volts_per_unit FLOAT,
                        unit VARCHAR(50),
                        icp VARCHAR(50),
                        sensor_type VARCHAR(255),
                        legend VARCHAR(255),
                        location VARCHAR(255),
                        direction VARCHAR(255),
                        range VARCHAR(255),
                        x_axis VARCHAR(255),
                        y_axis VARCHAR(255),
                        z_axis VARCHAR(255)
                    )
                """)
                
                # Create data collection report table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS df_config_data_collection_report (
                        report_id INTEGER PRIMARY KEY,
                        case_name VARCHAR(255),
                        simulator_config_id INTEGER,
                        simulator_config_name VARCHAR(255),
                        simulator_speed_hz INTEGER
                    )
                """)
                
                # Create data generation table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS df_config_data_generation_timings (
                        run_id INTEGER PRIMARY KEY,
                        report_id INTEGER,
                        run_number VARCHAR(255),
                        sensor_config_id INTEGER,
                        sensor_name VARCHAR(255),
                        measurement_interval_min INTEGER,
                        start_datetime TIMESTAMP,
                        end_datetime TIMESTAMP,
                        duration_hrs INTEGER,
                        FOREIGN KEY (report_id) REFERENCES df_config_data_collection_report(report_id),
                        UNIQUE (report_id, run_number, sensor_config_id),
                        UNIQUE (report_id, sensor_config_id, start_datetime),
                        UNIQUE (start_datetime),
                        UNIQUE (end_datetime)
                    )
                """)
                
                # Create audit log table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS df_config_audit_log (
                        id SERIAL PRIMARY KEY,
                        config_name VARCHAR(255),
                        table_name VARCHAR(255),
                        record_count INTEGER,
                        last_modified TIMESTAMP,
                        refresh_status VARCHAR(50),
                        additional_detail TEXT,
                        audit_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                self.pg_conn.commit()
                self.logger.info("✅ PostgreSQL tables created/verified successfully")
                
        except Exception as e:
            self.logger.error(f"❌ Error creating PostgreSQL tables: {e}")
            self.pg_conn.rollback()
            raise
    
    def _check_existing_records(self, table_key: str, data_to_insert: list) -> tuple:
        """
        Check for existing records to provide better duplicate warnings
        
        Args:
            table_key: Key identifier for the table
            data_to_insert: List of records to be inserted
            
        Returns:
            Tuple of (existing_count, duplicate_keys)
        """
        try:
            existing_count = 0
            duplicate_keys = []
            
            with self.pg_conn.cursor() as cursor:
                for record in data_to_insert:
                    try:
                        if table_key == 'config_master':
                            # For config_master, check primary key (config_id)
                            config_id = record.get('config_id')
                            if config_id is not None:
                                cursor.execute("SELECT config_id FROM df_config_master WHERE config_id = %s", (config_id,))
                                if cursor.fetchone():
                                    existing_count += 1
                                    duplicate_keys.append(config_id)
                        elif table_key == 'fault_simulator':
                            # For fault_simulator, check composite key (config_id + parameter)
                            config_id = record.get('config_id')
                            parameter = record.get('parameter')
                            if config_id is not None and parameter is not None:
                                cursor.execute("SELECT config_id FROM df_config_fault_simulator WHERE config_id = %s AND parameter = %s", (config_id, parameter))
                                if cursor.fetchone():
                                    existing_count += 1
                                    duplicate_keys.append(f"{config_id}:{parameter}")
                        elif table_key == 'sensor_metadata':
                            # For sensor_metadata, check primary key (sensor_serial_number)
                            sensor_serial = record.get('sensor_serial_number')
                            if sensor_serial is not None:
                                cursor.execute("SELECT sensor_serial_number FROM df_config_sensor_metadata WHERE sensor_serial_number = %s", (sensor_serial,))
                                if cursor.fetchone():
                                    existing_count += 1
                                    duplicate_keys.append(sensor_serial)
                        elif table_key == 'data_collection':
                            # For data_collection, check primary key (report_id)
                            report_id = record.get('report_id')
                            if report_id is not None:
                                cursor.execute("SELECT report_id FROM df_config_data_collection_report WHERE report_id = %s", (report_id,))
                                if cursor.fetchone():
                                    existing_count += 1
                                    duplicate_keys.append(report_id)
                        elif table_key == 'data_generation':
                            # For data_generation, check all unique constraints
                            report_id = record.get('report_id')
                            run_number = record.get('run_number')
                            sensor_config_id = record.get('sensor_config_id')
                            start_datetime = record.get('start_datetime')
                            end_datetime = record.get('end_datetime')
                            
                            if all(v is not None for v in [report_id, run_number, sensor_config_id, start_datetime, end_datetime]):
                                # Check first unique constraint: (report_id, run_number, sensor_config_id)
                                cursor.execute("SELECT run_id FROM df_config_data_generation_timings WHERE report_id = %s AND run_number = %s AND sensor_config_id = %s", 
                                             (report_id, run_number, sensor_config_id))
                                if cursor.fetchone():
                                    existing_count += 1
                                    duplicate_keys.append(f"Run duplicate: {report_id}:{run_number}:{sensor_config_id}")
                                    continue
                                
                                # Check second unique constraint: (report_id, sensor_config_id, start_datetime)
                                cursor.execute("SELECT run_id FROM df_config_data_generation_timings WHERE report_id = %s AND sensor_config_id = %s AND start_datetime = %s", 
                                             (report_id, sensor_config_id, start_datetime))
                                if cursor.fetchone():
                                    existing_count += 1
                                    duplicate_keys.append(f"Time duplicate: {report_id}:{sensor_config_id}:{start_datetime}")
                                    continue
                                
                                # Check third unique constraint: start_datetime (no two configs can start at same time)
                                cursor.execute("SELECT run_id FROM df_config_data_generation_timings WHERE start_datetime = %s", (start_datetime,))
                                if cursor.fetchone():
                                    existing_count += 1
                                    duplicate_keys.append(f"Start time conflict: {start_datetime}")
                                    continue
                                
                                # Check fourth unique constraint: end_datetime (no two configs can end at same time)
                                cursor.execute("SELECT run_id FROM df_config_data_generation_timings WHERE end_datetime = %s", (end_datetime,))
                                if cursor.fetchone():
                                    existing_count += 1
                                    duplicate_keys.append(f"End time conflict: {end_datetime}")
                                    continue
                    except Exception as e:
                        self.logger.warning(f"⚠️ Error checking record for {table_key}: {e}")
                        continue
            
            return existing_count, duplicate_keys
            
        except Exception as e:
            self.logger.error(f"❌ Error checking existing records: {e}")
            return 0, []
    
    def _validate_required_columns(self, table_key: str, data_to_insert: list) -> bool:
        """
        Validate that required columns are present in the data
        
        Args:
            table_key: Key identifier for the table
            data_to_insert: List of records to be inserted
            
        Returns:
            True if all required columns are present, False otherwise
        """
        if not data_to_insert:
            return False
        
        # Get the first record to check columns
        first_record = data_to_insert[0]
        
        # Debug: Log the actual columns in the data
        self.logger.info(f"🔍 Data columns for {table_key}: {list(first_record.keys())}")
        
        # Define required columns for each table type
        required_columns = {
            'config_master': ['config_id', 'config_name', 'fault_name', 'sensor_consideration'],
            'fault_simulator': ['config_id', 'config_name', 'section', 'parameter', 'value'],
            'sensor_metadata': ['sensor_config_id', 'sensor_name', 'sensor_serial_number'],
            'data_collection': ['report_id', 'case_name', 'simulator_config_id', 'simulator_config_name', 'simulator_speed_hz'],
            'data_generation': ['run_id', 'report_id', 'run_number', 'sensor_config_id', 'sensor_name', 'measurement_interval_min', 'start_datetime', 'end_datetime', 'duration_hrs']
        }
        
        required = required_columns.get(table_key, [])
        
        # Debug: Log what we're looking for vs what we have
        self.logger.info(f"🔍 Required columns for {table_key}: {required}")
        
        # Check if all required columns are present
        missing_columns = [col for col in required if col not in first_record]
        
        if missing_columns:
            self.logger.error(f"❌ Missing required columns for {table_key}: {missing_columns}")
            return False
        
        return True
    
    def _refresh_single_config(self, table_key: str, table_name: str) -> tuple:
        """
        Refresh a single configuration table
        
        Args:
            table_key: Key identifier for the table
            table_name: Table name in PostgreSQL
            
        Returns:
            Tuple of (success: bool, had_duplicates: bool, new_records: int, duplicates_skipped: int)
        """
        try:
            # Read data from Excel tab
            df = self._read_excel_tab(table_key)
            
            if df is None or df.count() == 0:
                self.logger.warning(f"⚠️ No data found in Excel tab for {table_key}")
                return False, False, 0, 0 # No data, no duplicates
            
            # Convert Spark DataFrame to list of dictionaries for PostgreSQL
            data_to_insert = self._convert_spark_to_postgres_data(df, table_key)
            
            # If data conversion failed (returned None or empty), stop the process
            if not data_to_insert:
                self.logger.error(f"❌ Critical error: Data conversion failed for {table_name}")
                raise ValueError(f"Data conversion failed for {table_name}. Cannot proceed with refresh.")
            
            # Validate required columns for each table type
            if not self._validate_required_columns(table_key, data_to_insert):
                self.logger.error(f"❌ Critical error: Required columns missing for {table_name}")
                raise ValueError(f"Schema mismatch: Required columns missing for {table_name}. Cannot proceed with refresh.")
            
            # Check for existing records
            existing_count, duplicate_keys = self._check_existing_records(table_key, data_to_insert)
            
            if existing_count > 0:
                self.logger.warning(f"⚠️ Found {existing_count} existing records for {table_name}. Duplicate keys: {duplicate_keys}")
                self.logger.info(f"📝 Will skip duplicates and continue with insertion of {len(data_to_insert) - existing_count} new records")
            else:
                self.logger.info(f"📝 {len(data_to_insert)} new records to insert for {table_name}")
            
            # Insert data with duplicate PK handling
            with self.pg_conn.cursor() as cursor:
                inserted_count = 0
                skipped_count = 0
                
                for record in data_to_insert:
                    try:
                        # Check if this specific record is a duplicate before attempting insert
                        is_duplicate = False
                        if table_key == 'config_master':
                            config_id = record.get('config_id')
                            if config_id is not None:
                                cursor.execute("SELECT config_id FROM df_config_master WHERE config_id = %s", (config_id,))
                                is_duplicate = cursor.fetchone() is not None
                        elif table_key == 'fault_simulator':
                            config_id = record.get('config_id')
                            parameter = record.get('parameter')
                            if config_id is not None and parameter is not None:
                                cursor.execute("SELECT config_id FROM df_config_fault_simulator WHERE config_id = %s AND parameter = %s", (config_id, parameter))
                                is_duplicate = cursor.fetchone() is not None
                        elif table_key == 'sensor_metadata':
                            sensor_serial = record.get('sensor_serial_number')
                            if sensor_serial is not None:
                                cursor.execute("SELECT sensor_serial_number FROM df_config_sensor_metadata WHERE sensor_serial_number = %s", (sensor_serial,))
                                is_duplicate = cursor.fetchone() is not None
                        elif table_key == 'data_collection':
                            report_id = record.get('report_id')
                            if report_id is not None:
                                cursor.execute("SELECT report_id FROM df_config_data_collection_report WHERE report_id = %s", (report_id,))
                                is_duplicate = cursor.fetchone() is not None
                        elif table_key == 'data_generation':
                            # Check all unique constraints for data_generation
                            report_id = record.get('report_id')
                            run_number = record.get('run_number')
                            sensor_config_id = record.get('sensor_config_id')
                            start_datetime = record.get('start_datetime')
                            end_datetime = record.get('end_datetime')
                            
                            if all(v is not None for v in [report_id, run_number, sensor_config_id, start_datetime, end_datetime]):
                                # Check first unique constraint: (report_id, run_number, sensor_config_id)
                                cursor.execute("SELECT run_id FROM df_config_data_generation_timings WHERE report_id = %s AND run_number = %s AND sensor_config_id = %s", 
                                             (report_id, run_number, sensor_config_id))
                                if cursor.fetchone():
                                    is_duplicate = True
                                else:
                                    # Check second unique constraint: (report_id, sensor_config_id, start_datetime)
                                    cursor.execute("SELECT run_id FROM df_config_data_generation_timings WHERE report_id = %s AND sensor_config_id = %s AND start_datetime = %s", 
                                                 (report_id, sensor_config_id, start_datetime))
                                    if cursor.fetchone():
                                        is_duplicate = True
                                    else:
                                        # Check third unique constraint: start_datetime
                                        cursor.execute("SELECT run_id FROM df_config_data_generation_timings WHERE start_datetime = %s", (start_datetime,))
                                        if cursor.fetchone():
                                            is_duplicate = True
                                        else:
                                            # Check fourth unique constraint: end_datetime
                                            cursor.execute("SELECT run_id FROM df_config_data_generation_timings WHERE end_datetime = %s", (end_datetime,))
                                            is_duplicate = cursor.fetchone() is not None
                            else:
                                is_duplicate = False
                        
                        if is_duplicate:
                            skipped_count += 1
                            # Log which specific record is being skipped
                            if table_key == 'config_master':
                                self.logger.debug(f"⚠️ Skipping duplicate config_master: config_id={record.get('config_id')}")
                            elif table_key == 'fault_simulator':
                                self.logger.debug(f"⚠️ Skipping duplicate fault simulator config: config_id={record.get('config_id')}, parameter={record.get('parameter')}")
                            elif table_key == 'sensor_metadata':
                                self.logger.debug(f"⚠️ Skipping duplicate sensor: sensor_serial_number={record.get('sensor_serial_number')}")
                            elif table_key == 'data_collection':
                                self.logger.debug(f"⚠️ Skipping duplicate report: report_id={record.get('report_id')}")
                            elif table_key == 'data_generation':
                                self.logger.debug(f"⚠️ Skipping duplicate run: report_id={record.get('report_id')}, run_number={record.get('run_number')}, sensor_config_id={record.get('sensor_config_id')}, start_datetime={record.get('start_datetime')}")
                            continue
                        
                        # Insert the record if it's not a duplicate
                        if table_key == 'config_master':
                            cursor.execute("""
                                INSERT INTO df_config_master (config_id, config_name, fault_name, sensor_consideration)
                                VALUES (%(config_id)s, %(config_name)s, %(fault_name)s, %(sensor_consideration)s)
                                ON CONFLICT (config_id) DO NOTHING
                            """, record)
                        elif table_key == 'fault_simulator':
                            cursor.execute("""
                                INSERT INTO df_config_fault_simulator (config_id, config_name, section, parameter, value)
                                VALUES (%(config_id)s, %(config_name)s, %(section)s, %(parameter)s, %(value)s)
                                ON CONFLICT (config_id, parameter) DO NOTHING
                            """, record)
                        elif table_key == 'sensor_metadata':
                            cursor.execute("""
                                INSERT INTO df_config_sensor_metadata (sensor_config_id, sensor_name, environment, gateway_serial_number, 
                                                                  sensor_serial_number, channel, couple, volts_per_unit, unit, icp, 
                                                                  sensor_type, legend, location, direction, range, x_axis, y_axis, z_axis)
                                VALUES (%(sensor_config_id)s, %(sensor_name)s, %(environment)s, %(gateway_serial_number)s,
                                        %(sensor_serial_number)s, %(channel)s, %(couple)s, %(volts_per_unit)s, %(unit)s, %(icp)s,
                                        %(sensor_type)s, %(legend)s, %(location)s, %(direction)s, %(range)s, %(x_axis)s, %(y_axis)s, %(z_axis)s)
                                ON CONFLICT (sensor_serial_number) DO NOTHING
                            """, record)
                        elif table_key == 'data_collection':
                            cursor.execute("""
                                INSERT INTO df_config_data_collection_report (report_id, case_name, simulator_config_id, simulator_config_name, simulator_speed_hz)
                                VALUES (%(report_id)s, %(case_name)s, %(simulator_config_id)s, %(simulator_config_name)s, %(simulator_speed_hz)s)
                                ON CONFLICT (report_id) DO NOTHING
                            """, record)
                        elif table_key == 'data_generation':
                            cursor.execute("""
                                INSERT INTO df_config_data_generation_timings (run_id, report_id, run_number, sensor_config_id, sensor_name, 
                                                                          measurement_interval_min, start_datetime, end_datetime, duration_hrs)
                                VALUES (%(run_id)s, %(report_id)s, %(run_number)s, %(sensor_config_id)s, %(sensor_name)s,
                                        %(measurement_interval_min)s, %(start_datetime)s, %(end_datetime)s, %(duration_hrs)s)
                            """, record)
                        
                        # Check if record was inserted
                        if cursor.rowcount > 0:
                            inserted_count += 1
                        else:
                            # This shouldn't happen with our duplicate checking, but log it just in case
                            self.logger.warning(f"⚠️ Unexpected: Record not inserted in {table_name}")
                            
                    except KeyError as e:
                        # Critical error: Missing required column
                        self.logger.error(f"❌ Critical error: Missing required column '{e}' in {table_name}")
                        raise ValueError(f"Schema mismatch: Column '{e}' not found in Excel data for {table_name}")
                    except TypeError as e:
                        # Critical error: Data type conversion failed
                        self.logger.error(f"❌ Critical error: Data type conversion failed in {table_name}: {e}")
                        raise ValueError(f"Data type error in {table_name}: {e}")
                    except Exception as e:
                        # Critical error: Unexpected system error
                        self.logger.error(f"❌ Critical error in {table_name}: {e}")
                        raise  # Re-raise to stop the entire refresh process
                
                self.pg_conn.commit()
                
                if skipped_count > 0:
                    self.logger.info(f"📝 {inserted_count} new records inserted, {skipped_count} duplicates skipped in {table_name}")
                else:
                    self.logger.info(f"📝 {inserted_count} records written to {table_name}")
                
                return True, skipped_count > 0, inserted_count, skipped_count # Return success status, had duplicates, new records count, and duplicates count
                
        except Exception as e:
            self.logger.error(f"❌ Error refreshing {table_name}: {e}")
            self.pg_conn.rollback()
            return False, False, 0, 0 # Indicate failure and no duplicates
    
    def _convert_spark_to_postgres_data(self, df, table_key: str) -> list:
        """Convert Spark DataFrame to list of dictionaries for PostgreSQL insertion"""
        try:
            # Collect data as list of rows
            rows = df.collect()
            data_list = []
            
            for row in rows:
                row_dict = row.asDict()
                
                # Handle None values and data type conversions
                for key, value in row_dict.items():
                    if value == '':
                        row_dict[key] = None
                    elif key in ['start_datetime', 'end_datetime'] and value:
                        # Convert string to proper timestamp format
                        try:
                            from datetime import datetime
                            if isinstance(value, str):
                                # Handle different date formats
                                if value.strip() == '' or value.lower() == 'unknown':
                                    row_dict[key] = None
                                else:
                                    # Try multiple date formats
                                    for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y']:
                                        try:
                                            row_dict[key] = datetime.strptime(value.strip(), fmt)
                                            break
                                        except ValueError:
                                            continue
                                    else:
                                        # If no format matches, this is a critical error - stop the process
                                        self.logger.error(f"❌ Critical error: Could not parse timestamp '{value}' for column {key}")
                                        raise ValueError(f"Critical timestamp parsing error: Column '{key}' has unparseable value '{value}'. Please fix the Excel data format.")
                        except Exception as e:
                            if "Critical timestamp parsing error" in str(e):
                                raise  # Re-raise critical timestamp errors
                            self.logger.error(f"❌ Critical error converting timestamp '{value}' for column {key}: {e}")
                            raise ValueError(f"Critical timestamp conversion error in {key}: {e}")
                
                data_list.append(row_dict)
            
            return data_list
            
        except Exception as e:
            self.logger.error(f"❌ Error converting Spark data: {e}")
            raise  # Re-raise to stop the process
    
    def _read_excel_tab(self, table_key: str):
        """
        Read data from specific Excel tab using pandas and convert to Spark DataFrame
        
        Args:
            table_key: Key identifier for the table
            
        Returns:
            DataFrame with data from Excel tab
        """
        try:
            # Map table keys to Excel sheet names
            sheet_mapping = {
                'config_master': 'config_master',
                'fault_simulator': 'config_fault_simulator',
                'sensor_metadata': 'config_sensor_metadata',
                'data_collection': 'config_data_collection_report', 
                'data_generation': 'config_data_generation_timings'
            }
            
            sheet_name = sheet_mapping.get(table_key)
            if not sheet_name:
                raise ValueError(f"Unknown table key: {table_key}")
            
            # Read Excel using pandas (which is already a dependency)
            import pandas as pd
            df_excel = pd.read_excel(self.excel_file_path, sheet_name=sheet_name)
            
            # Debug: Log the actual column names from Excel
            self.logger.info(f"🔍 Excel columns for {sheet_name}: {list(df_excel.columns)}")
            
            # Fix data types to prevent Arrow conversion issues
            for col in df_excel.columns:
                if df_excel[col].dtype == 'object':  # String/object columns
                    df_excel[col] = df_excel[col].astype(str)
                elif df_excel[col].dtype == 'int64':  # Integer columns
                    df_excel[col] = df_excel[col].fillna(0).astype('Int64')  # Handle NaN
                elif df_excel[col].dtype == 'float64':  # Float columns
                    df_excel[col] = df_excel[col].fillna(0.0)
            
            # Convert pandas DataFrame to Spark DataFrame
            spark_df = self.spark.createDataFrame(df_excel)
            
            self.logger.info(f"✅ Successfully read {sheet_name}: {len(df_excel)} rows, {len(df_excel.columns)} columns")
            return spark_df
            
        except Exception as e:
            self.logger.error(f"❌ Error reading Excel tab {table_key}: {e}")
            return None
    
    def get_config_summary(self) -> Dict[str, Any]:
        """
        Get summary of current configuration tables in PostgreSQL
        
        Returns:
            Dictionary with table counts and last refresh info
        """
        summary = {}
        
        try:
            with self.pg_conn.cursor(cursor_factory=RealDictCursor) as cursor:
                for table_key, table_name in self.config_tables.items():
                    try:
                        # Get record count
                        cursor.execute(f"SELECT COUNT(*) as count FROM {table_name}")
                        count_result = cursor.fetchone()
                        count = count_result['count'] if count_result else 0
                        
                        # Get last modified timestamp (if available)
                        try:
                            cursor.execute(f"SELECT MAX(audit_timestamp) as last_modified FROM df_config_audit_log WHERE table_name = %s", (table_name,))
                            last_modified_result = cursor.fetchone()
                            last_modified = last_modified_result['last_modified'] if last_modified_result and last_modified_result['last_modified'] else None
                        except:
                            last_modified = None
                        
                        summary[table_key] = {
                            'table_name': table_name,
                            'record_count': count,
                            'last_modified': last_modified
                        }
                        
                    except Exception as e:
                        summary[table_key] = {
                            'table_name': table_name,
                            'error': str(e)
                        }
            
            return summary
            
        except Exception as e:
            self.logger.error(f"❌ Error getting config summary: {e}")
            return {}
    
    def store_config_audit(self, summary: Dict[str, Any], refresh_results: Dict[str, str]) -> None:
        """
        Store configuration summary in audit table for tracking
        
        Args:
            summary: Configuration summary from get_config_summary
            refresh_results: Results from refresh operation (now with string statuses)
        """
        try:
            with self.pg_conn.cursor() as cursor:
                for table_key, info in summary.items():
                    if 'error' in info:
                        # Table has error
                        cursor.execute("""
                            INSERT INTO df_config_audit_log (config_name, table_name, record_count, last_modified, refresh_status, additional_detail)
                            VALUES (%s, %s, %s, %s, %s, %s)
                        """, (table_key, info['table_name'], 0, None, 'Failed', info['error']))
                    else:
                        # Table is healthy - store detailed message based on status
                        refresh_status = refresh_results.get(table_key, 'Not Refreshed')
                        
                        # Handle "Unknown" timestamp - convert to None for PostgreSQL
                        last_modified = info.get('last_modified')
                        if last_modified == "Unknown":
                            last_modified = None
                        
                        # Create detailed message for additional_detail column
                        if refresh_status == 'Success':
                            # Get detailed counts for success message
                            detailed_counts = getattr(self, 'detailed_counts', {}).get(table_key, {})
                            new_records = detailed_counts.get('new_records', 0)
                            additional_detail = f"Successfully refreshed with {new_records} new records"
                        elif refresh_status == 'Warning':
                            # Get detailed counts for warning message
                            detailed_counts = getattr(self, 'detailed_counts', {}).get(table_key, {})
                            new_records = detailed_counts.get('new_records', 0)
                            duplicates_skipped = detailed_counts.get('duplicates_skipped', 0)
                            if new_records > 0:
                                additional_detail = f"Processed with some duplicates - {new_records} new records inserted, {duplicates_skipped} duplicates skipped"
                            else:
                                additional_detail = f"Processed with duplicates only - {duplicates_skipped} duplicates found, no new records inserted"
                        elif refresh_status == 'Failed':
                            additional_detail = "Table refresh failed"
                        else:
                            additional_detail = "Not refreshed during this session"
                        
                        cursor.execute("""
                            INSERT INTO df_config_audit_log (config_name, table_name, record_count, last_modified, refresh_status, additional_detail)
                            VALUES (%s, %s, %s, %s, %s, %s)
                        """, (table_key, info['table_name'], info['record_count'], last_modified, refresh_status, additional_detail))
                
                self.pg_conn.commit()
                self.logger.info("📝 Configuration audit stored in df_config_audit_log")
                
        except Exception as e:
            self.logger.error(f"❌ Error storing config audit: {e}")
            self.pg_conn.rollback()
            raise  # Re-raise to stop the process
    
    def verify_excel_structure(self) -> Dict[str, Any]:
        """
        Verify Excel file structure and return verification results
        
        Returns:
            Dictionary with verification results for each expected sheet
        """
        try:
            self.logger.info(f"🔍 Verifying Excel structure: {self.excel_file_path}")
            
            # Expected sheet names
            expected_sheets = [
                'config_master',
                'config_fault_simulator',
                'config_sensor_metadata', 
                'config_data_collection_report',
                'config_data_generation_timings'
            ]
            
            verification_results = {}
            
            for sheet_name in expected_sheets:
                try:
                    # Read Excel using pandas (which is already a dependency)
                    df_excel = pd.read_excel(self.excel_file_path, sheet_name=sheet_name)
                    
                    # Get column count and row count
                    column_count = len(df_excel.columns)
                    row_count = len(df_excel)
                    
                    verification_results[sheet_name] = {
                        'status': 'Found',
                        'columns': column_count,
                        'rows': row_count,
                        'column_names': list(df_excel.columns)
                    }
                    
                    self.logger.info(f"✅ {sheet_name}: {column_count} columns, {row_count} rows")
                    
                except Exception as e:
                    verification_results[sheet_name] = {
                        'status': 'Missing/Error',
                        'error': str(e),
                        'columns': 0,
                        'rows': 0,
                        'column_names': []
                    }
                    
                    self.logger.error(f"❌ {sheet_name}: {e}")
            
            # Summary
            found_sheets = sum(1 for result in verification_results.values() if result['status'] == 'Found')
            total_sheets = len(expected_sheets)
            
            self.logger.info(f"📊 Excel verification: {found_sheets}/{total_sheets} sheets found")
            
            return verification_results
            
        except Exception as e:
            self.logger.error(f"❌ Error verifying Excel structure: {e}")
            return {} 

# Convenience function for direct access
def refresh_simulator_configs(spark_session: SparkSession, postgres_connection, excel_file_path: str, logger_instance: Optional[logging.Logger] = None) -> None:
    """
    Refresh all simulator configuration tables from Excel file to PostgreSQL database
    
    Args:
        spark_session: Active Spark session (for reading Excel from Lakehouse)
        postgres_connection: Active PostgreSQL connection from db_connector
        excel_file_path: Path to Excel file in Lakehouse
        logger_instance: Logger instance (optional, creates basic logger if not provided)
        
    Note:
        This function performs all operations internally and logs results.
        No return value is provided as all information is logged and stored in audit tables.
    """
    refresher = ConfigRefresher(spark_session, postgres_connection, excel_file_path, logger_instance)
    refresher.refresh_simulator_configs() 