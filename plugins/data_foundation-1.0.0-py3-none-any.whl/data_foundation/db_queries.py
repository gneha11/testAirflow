"""
Centralized SQL Queries for Data Foundation Package
All SQL queries are organized by module for easy maintenance

This file contains all SQL queries used across the data_foundation package,
organized by module to maintain clarity and ease of maintenance.
"""


class BronzeToSilverQueries:
    """SQL queries for bronze to silver data transformation"""
    
    @staticmethod
    def get_raw_waveform_data(input_table: str, start_epoch: int, end_epoch: int, data_category: str, tenant_id: str, enterprise_id: str) -> str:
        """
        Get raw waveform data from bronze layer
        
        Args:
            input_table: Source bronze table name
            start_epoch: Start timestamp in epoch format
            end_epoch: End timestamp in epoch format
            data_category: Data category filter
            tenant_id: Tenant identifier for data isolation
            enterprise_id: Enterprise identifier for data isolation
            
        Returns:
            SQL query string for raw waveform data
        """
        return f"""
        SELECT Input_tenantId, Input_enterpriseId, asset_metadata_id, file_modified_time, 
               config_accelRange_g, config_sampleRate_Hz, sensorId, timestamp, 
               16384/config_sampleRate_Hz AS measurement_time, 
               from_unixtime(CAST(timestamp AS BIGINT)) AS utc_datetime, 
               null as Tag_Health, null as Tag_ModelConsideration, null as Tag_Speed, 
               null as Tag_Config,'Incoming' as Data_Label ,null as sensor_location,
               date_format(from_utc_timestamp(from_unixtime(CAST(timestamp AS BIGINT)), 'America/Chicago'), 'yyyy-MM-dd HH:mm:ss') AS cst_datetime,
               sensorParameters_rawHoriz AS rawHoriz, 
               sensorParameters_rawVert AS rawVert, 
               sensorParameters_rawAxial AS rawAxial
        FROM {input_table}
        WHERE file_modified_time >= {start_epoch} AND file_modified_time <= {end_epoch}
            AND measurementType = '{data_category}'
            AND Input_tenantId = '{tenant_id}'
            AND Input_enterpriseId = '{enterprise_id}'
        """
    
    @staticmethod
    def get_raw_waveform_simulator_data(input_table: str, start_epoch: int, end_epoch: int, data_category: str, tenant_id: str, enterprise_id: str) -> str:
        """
        Get raw waveform simulator data from bronze layer with classification tags from config tables
        
        Args:
            input_table: Source bronze table name
            start_epoch: Start timestamp in epoch format (from shared utils)
            end_epoch: End timestamp in epoch format (from shared utils)
            data_category: Data category filter
            tenant_id: Tenant identifier for data isolation
            enterprise_id: Enterprise identifier for data isolation
            
        Returns:
            SQL query string for raw waveform simulator data with classification tags
        """
        return f"""
        SELECT 
            b.Input_tenantId, b.Input_enterpriseId, b.asset_metadata_id, b.file_modified_time, 
            b.config_accelRange_g, b.config_sampleRate_Hz, b.sensorId, b.timestamp, 
            16384/b.config_sampleRate_Hz AS measurement_time, 
            from_unixtime(CAST(b.timestamp AS BIGINT)) AS utc_datetime, 
            CASE 
                WHEN cm.sensor_consideration IS NOT NULL AND cm.sensor_consideration != '' AND array_contains(split(cm.sensor_consideration, ','), CAST(b.sensorId AS STRING)) THEN cm.fault_name
                ELSE 'IGNORE'
            END as Tag_Health, 
            CASE 
                WHEN cm.sensor_consideration IS NOT NULL AND cm.sensor_consideration != '' AND array_contains(split(cm.sensor_consideration, ','), CAST(b.sensorId AS STRING)) THEN 'Y'
                ELSE 'N'
            END as Tag_ModelConsideration, 
            dcr.simulator_speed_hz as Tag_Speed, 
            concat('Config_', CAST(dcr.simulator_config_id AS STRING)) as Tag_Config,
            sm.location as sensor_location,
            date_format(from_utc_timestamp(from_unixtime(CAST(b.timestamp AS BIGINT)), 'America/Chicago'), 'yyyy-MM-dd HH:mm:ss') AS cst_datetime,
            b.sensorParameters_rawHoriz AS rawHoriz, 
            b.sensorParameters_rawVert AS rawVert, 
            b.sensorParameters_rawAxial AS rawAxial
        FROM {input_table} b
        INNER JOIN df_config_data_generation_timings dgt 
            ON b.timestamp BETWEEN 
                unix_timestamp(to_utc_timestamp(dgt.start_datetime, 'America/Chicago')) 
                AND unix_timestamp(to_utc_timestamp(dgt.end_datetime, 'America/Chicago'))
            AND b.file_modified_time >= {start_epoch}
            AND b.file_modified_time <= {end_epoch}
            AND b.measurementType = '{data_category}'
            AND b.Input_tenantId = '{tenant_id}'
            AND b.Input_enterpriseId = '{enterprise_id}'
        INNER JOIN df_config_data_collection_report dcr 
            ON dgt.report_id = dcr.report_id
        INNER JOIN df_config_master cm 
            ON dcr.simulator_config_id = cm.config_id
        INNER JOIN df_config_sensor_metadata sm 
            ON b.sensorId = sm.sensor_serial_number
        """
    
    @staticmethod
    def get_raw_waveform_simulator_data_with_labels(input_table: str, start_epoch: int, end_epoch: int, data_category: str, tenant_id: str, enterprise_id: str) -> str:
        """
        Get raw waveform simulator data with classification labels using UNION ALL approach.
        
        This query separates IGNORE records (with NULL Data_Label) from non-IGNORE records
        (with NTILE-based 'Trained'/'Test' labels) to ensure proper partitioning.
        
        Args:
            input_table: Source bronze table name
            start_epoch: Start epoch timestamp for filtering
            end_epoch: End epoch timestamp for filtering
            data_category: Data category filter
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            
        Returns:
            SQL query string
        """
        return f"""
        -- First: Get IGNORE records with NULL Data_Label
        SELECT a.*, NULL as Data_Label
        FROM (
            {BronzeToSilverQueries.get_raw_waveform_simulator_data(input_table, start_epoch, end_epoch, data_category, tenant_id, enterprise_id)}
        ) a
        WHERE a.Tag_Health = 'IGNORE'
        
        UNION ALL
        
        -- Second: Get non-IGNORE records with NTILE logic for Training/Test split
        SELECT a.*,
            CASE 
                WHEN ntile(10) OVER (
                    PARTITION BY a.Tag_Health, a.Tag_Config, a.Tag_Speed, a.sensorId, a.sensor_location 
                    ORDER BY a.Tag_Health, a.Tag_Config, a.Tag_Speed, a.sensorId, a.sensor_location, a.timestamp, a.utc_datetime
                ) <= 8 THEN 'Trained'
                ELSE 'Test'
            END as Data_Label
        FROM (
            {BronzeToSilverQueries.get_raw_waveform_simulator_data(input_table, start_epoch, end_epoch, data_category, tenant_id, enterprise_id)}
        ) a
        WHERE a.Tag_Health != 'IGNORE'
        """

    @staticmethod
    def get_calculated_waveform_data(input_table: str, start_epoch: int, end_epoch: int, tenant_id: str, enterprise_id: str) -> str:
        """
        Get calculated waveform data from bronze layer
        
        Args:
            input_table: Source bronze table name
            start_epoch: Start timestamp in epoch format
            end_epoch: End timestamp in epoch format
            tenant_id: Tenant identifier for data isolation
            enterprise_id: Enterprise identifier for data isolation
            
        Returns:
            SQL query string for calculated waveform data
        """
        return f"""
        SELECT * FROM {input_table}
        WHERE timestamp >= {start_epoch} AND timestamp <= {end_epoch}
            AND Input_tenantId = '{tenant_id}'
            AND Input_enterpriseId = '{enterprise_id}'
        """

    @staticmethod
    def get_calculated_waveform_simulator_data_with_labels(input_table: str, start_epoch: int, end_epoch: int, tenant_id: str, enterprise_id: str) -> str:
        """
        Get calculated waveform simulator data with classification labels using UNION ALL approach.
        
        This query separates IGNORE records (with NULL Data_Label) from non-IGNORE records
        (with NTILE-based 'Trained'/'Test' labels) to ensure proper partitioning.
        
        Args:
            input_table: Source bronze table name
            start_epoch: Start epoch timestamp for filtering
            end_epoch: End epoch timestamp for filtering
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            
        Returns:
            SQL query string
        """
        return f"""
        -- First: Get IGNORE records with NULL Data_Label
        SELECT a.*, NULL as Data_Label
        FROM (
            {BronzeToSilverQueries.get_calculated_waveform_simulator_data_base(input_table, start_epoch, end_epoch, tenant_id, enterprise_id)}
        ) a
        WHERE a.Tag_Health = 'IGNORE'
        
        UNION ALL
        
        -- Second: Get non-IGNORE records with NTILE logic for Training/Test split
        SELECT a.*,
            CASE 
                WHEN ntile(10) OVER (
                    PARTITION BY a.Tag_Health, a.Tag_Config, a.Tag_Speed, a.sensorId, a.sensor_location 
                    ORDER BY a.Tag_Health, a.Tag_Config, a.Tag_Speed, a.sensorId, a.sensor_location, a.timestamp
                ) <= 8 THEN 'Trained'
                ELSE 'Test'
            END as Data_Label
        FROM (
            {BronzeToSilverQueries.get_calculated_waveform_simulator_data_base(input_table, start_epoch, end_epoch, tenant_id, enterprise_id)}
        ) a
        WHERE a.Tag_Health != 'IGNORE'
        """

    @staticmethod
    def get_calculated_waveform_simulator_data_base(input_table: str, start_epoch: int, end_epoch: int, tenant_id: str, enterprise_id: str) -> str:
        """
        Get calculated waveform simulator data base for labels.
        
        Args:
            input_table: Source bronze table name
            start_epoch: Start epoch timestamp for filtering
            end_epoch: End epoch timestamp for filtering
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            
        Returns:
            SQL query string for calculated simulator data base
        """
        return f"""
        SELECT 
            c.Input_tenantId, c.Input_enterpriseId, c._id, c.asset_metadata_id, 
            c.cloudTimestamp, c.`co-relationId`, c.createdDate, c.firmwareVer, 
            c.gatewayId, c.gwTime, c.objectClass, c.objectSubType, c.objectType, 
            c.previousHealthStatus, c.schemaVersion, c.scope, c.sensorId, 
            c.sensorType, c.spanId, c.tags, c.tenantId, c.timestamp, 
            c.traceId, c.traceParentId, c.config_accelRange_g, c.config_sampleRate_Hz,
            c.sensorParameters_batteryStatus_V, c.sensorParameters_batteryVoltage_V,
            c.sensorParameters_crestFactorAxial_g, c.sensorParameters_crestFactorHoriz_g,
            c.sensorParameters_crestFactorVert_g, c.sensorParameters_peakAxial_g,
            c.sensorParameters_peakHoriz_g, c.sensorParameters_peakToPeakAxial_g,
            c.sensorParameters_peakToPeakAxial_inps, c.sensorParameters_peakToPeakHoriz_g,
            c.sensorParameters_peakToPeakHoriz_inps, c.sensorParameters_peakToPeakVert_g,
            c.sensorParameters_peakToPeakVert_inps, c.sensorParameters_peakVert_g,
            c.sensorParameters_rmsAxial_g, c.sensorParameters_rmsAxial_inps,
            c.sensorParameters_rmsHoriz_g, c.sensorParameters_rmsHoriz_inps,
            c.sensorParameters_rmsVert_g, c.sensorParameters_rmsVert_inps,
            c.sensorParameters_sensorSignalStrength_dBm, c.sensorParameters_temperature_C,
            CASE 
                WHEN cm.sensor_consideration IS NOT NULL AND cm.sensor_consideration != '' AND array_contains(split(cm.sensor_consideration, ','), CAST(c.sensorId AS STRING)) THEN cm.fault_name
                ELSE 'IGNORE'
            END as Tag_Health, 
            CASE 
                WHEN cm.sensor_consideration IS NOT NULL AND cm.sensor_consideration != '' AND array_contains(split(cm.sensor_consideration, ','), CAST(c.sensorId AS STRING)) THEN 'Y'
                ELSE 'N'
            END as Tag_ModelConsideration, 
            dcr.simulator_speed_hz as Tag_Speed, 
            concat('Config_', CAST(dcr.simulator_config_id AS STRING)) as Tag_Config,
            sm.location as sensor_location
        FROM {input_table} c
        INNER JOIN df_config_data_generation_timings dgt 
            ON c.timestamp BETWEEN 
                unix_timestamp(to_utc_timestamp(dgt.start_datetime, 'America/Chicago')) 
                AND unix_timestamp(to_utc_timestamp(dgt.end_datetime, 'America/Chicago'))
            AND c.timestamp >= {start_epoch}
            AND c.timestamp <= {end_epoch}
            AND c.Input_tenantId = '{tenant_id}'
            AND c.Input_enterpriseId = '{enterprise_id}'
        INNER JOIN df_config_data_collection_report dcr 
            ON dgt.report_id = dcr.report_id
        INNER JOIN df_config_master cm 
            ON dcr.simulator_config_id = cm.config_id
        INNER JOIN df_config_sensor_metadata sm 
            ON c.sensorId = sm.sensor_serial_number
        """


class AssetHierarchyQueries:
    """SQL queries for asset hierarchy management"""
    
    @staticmethod
    def get_sensor_data(tenant_id: str, enterprise_id: str) -> str:
        """
        Get sensor data from Cosmos DB
        
        Args:
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            
        Returns:
            SQL query string for sensor data
        """
        return f"""
        SELECT 
            g.scope[0]._value AS scope, 
            g.serialNumber[0]._value AS serialNumber, 
            g.tenantId AS tenantId, 
            g.objectSubType[0]._value AS objectSubType, 
            g.id AS id
        FROM g 
        WHERE g.objectType[0]._value = 'sensor' 
        AND g.tenantId = '{tenant_id}'
        AND STARTSWITH(g.scope[0]._value, '/{enterprise_id}')
        """
    
    @staticmethod
    def get_asset_data(tenant_id: str, enterprise_id: str) -> str:
        """
        Get non-sensor asset data from Cosmos DB
        
        Args:
            tenant_id: Tenant identifier
            enterprise_id: Enterprise identifier
            
        Returns:
            SQL query string for asset data
        """
        return f"""
        SELECT 
            g.scope[0]._value AS scope, 
            g.tenantId AS tenantId, 
            g.objectType[0]._value AS objectType,
            g.label AS label,
            g.objectSubType[0]._value AS objectSubType, 
            g.id AS id
        FROM g 
        WHERE g.tenantId = '{tenant_id}'
        AND STARTSWITH(g.scope[0]._value, '/{enterprise_id}')
        AND g.objectType[0]._value <> 'sensor'
        """
    
    @staticmethod
    def get_merge_sql(target_table: str, source_table: str) -> str:
        """
        Get MERGE SQL for asset hierarchy
        
        Args:
            target_table: Target table name for merge
            source_table: Source table name for merge
            
        Returns:
            SQL MERGE statement string
        """
        return f"""
        MERGE INTO {target_table} AS target
        USING {source_table} AS source
        ON
            target.tenantId = source.tenantId AND
            target.enterpriseId = source.enterpriseId AND
            target.siteId = source.siteId AND
            target.areaId = source.areaId AND
            target.unitId = source.unitId AND
            target.equipmentId = source.equipmentId AND
            target.sensorId = source.sensorId
        -- ✅ DO NOT update id here
        WHEN MATCHED THEN UPDATE SET
            target.enterpriseName = source.enterpriseName,
            target.siteName = source.siteName,
            target.areaName = source.areaName,
            target.unitName = source.unitName,
            target.equipmentName = source.equipmentName,
            target.sensorType = source.sensorType,
            target.serialNumber = source.serialNumber,
            target.scope = source.scope,
            target.updated_at = source.updated_at,
            target.hash_key = source.hash_key

        -- ✅ Only insert id for new records
        WHEN NOT MATCHED THEN INSERT (
            tenantId, enterpriseId, enterpriseName,
            siteId, siteName, areaId, areaName,
            unitId, unitName, equipmentId, equipmentName,
            sensorType, sensorId, serialNumber, scope,
            updated_at, hash_key, id
        )
        VALUES (
            source.tenantId, source.enterpriseId, source.enterpriseName,
            source.siteId, source.siteName, source.areaId, source.areaName,
            source.unitId, source.unitName, source.equipmentId, source.equipmentName,
            source.sensorType, source.sensorId, source.serialNumber, source.scope,
            source.updated_at, source.hash_key, source.id
        )
        """


class TelemetryQueries:
    """SQL queries for telemetry data"""
    
    @staticmethod
    def get_asset_metadata(table_name: str = "asset_master.assets_hierarchy") -> str:
        """
        Get asset metadata from Lakehouse
        
        Args:
            table_name: Asset hierarchy table name (default: "asset_master.assets_hierarchy")
            
        Returns:
            SQL query string for asset metadata
        """
        return f"""
        SELECT id, serialNumber, sensorType, tenantId, enterpriseId
        FROM {table_name}
        """