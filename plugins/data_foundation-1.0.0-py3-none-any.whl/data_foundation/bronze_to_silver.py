"""
Bronze to Silver Data Transformation Module for Microsoft Fabric.

This module provides functionality to transform data from bronze layer to silver layer,
including decoding and expanding raw waveform data, and processing calculated waveform data.
"""

import logging
import base64
from datetime import datetime
from typing import Optional, Any, List
from functools import partial

# Always import these at the top level for test patching
try:
    from pyspark.sql import SparkSession, DataFrame, Row
    from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, LongType, DoubleType, FloatType
    from pyspark.sql.functions import col, expr, year, month, dayofmonth
    import pyspark.sql.functions as F
    from pyspark.sql.window import Window
    from ctypes import c_int16
    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    DataFrame = None
    SparkSession = None
    Row = None
    F = None
    Window = None
    c_int16 = None

# Import centralized SQL queries
from .db_queries import BronzeToSilverQueries


def _decode_sensor_data(data: str, logger: logging.Logger) -> List[int]:
    """
    Decode base64-encoded sensor data to an array of int16 values.
    
    Args:
        data: Base64 encoded sensor data string
        logger: Logger instance for tracking
        
    Returns:
        List of decoded int16 values
    """
    try:
        logger.info("ℹ️ Decoding sensor data...")
        data_bytes = data.encode()
        b64_bytes = base64.b64decode(data_bytes)
        unencoded_str = b64_bytes.hex()
        data_arr = []
        for i in range(0, len(unencoded_str), 4):
            data_arr.append(
                c_int16(
                    int(unencoded_str[i:i+2], 16) + (int(unencoded_str[i+2:i+4], 16) << 8)
                ).value
            )
        logger.info(f"✅ Decoded data array with {len(data_arr)} values")
        return data_arr
    except Exception as e:
        logger.error(f"❌ Error decoding sensor data: {e}")
        return []


def _process_raw_row(row: Row, logger: logging.Logger, scale_factor: float) -> List[Row]:
    """
    Process a single row of raw waveform data, decoding and expanding arrays.
    
    Args:
        row: Spark Row containing raw sensor data
        logger: Logger instance for tracking
        scale_factor: Scale factor for conversion (default: 32.0/32767.0)
        
    Returns:
        List of processed Row objects with expanded x,y,z values
    """
    if isinstance(row.rawHoriz, str) and isinstance(row.rawVert, str) and isinstance(row.rawAxial, str):
        logger.info(f"ℹ️ Processing sensorId={row.sensorId}, timestamp={row.timestamp}")
        x_values = _decode_sensor_data(row.rawHoriz, logger)
        y_values = _decode_sensor_data(row.rawVert, logger)
        z_values = _decode_sensor_data(row.rawAxial, logger)

        min_length = min(len(x_values), len(y_values), len(z_values))
        x_values, y_values, z_values = x_values[:min_length], y_values[:min_length], z_values[:min_length]

        logger.info(f"ℹ️ Trimmed to minimum common length: {min_length} samples")

        # Convert utc_datetime to timestamp before extracting year, month, day
        utc_dt = datetime.strptime(row.utc_datetime, "%Y-%m-%d %H:%M:%S") if isinstance(row.utc_datetime, str) else row.utc_datetime

        return [
            Row(
                Input_tenantId=row.Input_tenantId, 
                Input_enterpriseId=row.Input_enterpriseId, 
                asset_metadata_id=row.asset_metadata_id, 
                file_modified_time=row.file_modified_time,
                config_accelRange_g=row.config_accelRange_g, 
                config_sampleRate_Hz=row.config_sampleRate_Hz,
                sensorId=row.sensorId, 
                timestamp=row.timestamp, 
                measurement_time=row.measurement_time, 
                utc_datetime=row.utc_datetime, 
                cst_datetime=row.cst_datetime, 
                Tag_Health=row.Tag_Health, 
                Tag_Speed=row.Tag_Speed, 
                Tag_Config=row.Tag_Config, 
                Tag_ModelConsideration=row.Tag_ModelConsideration, 
                Data_Label=row.Data_Label,
                sensor_location=row.sensor_location, 
                Raw_Horiz=x, 
                Raw_Vert=y, 
                Raw_Axial=z,
                # Apply scale factor conversion
                Horiz_g=x * scale_factor, 
                Vert_g=y * scale_factor, 
                Axial_g=z * scale_factor,
                # Extract year, month, day correctly
                year=utc_dt.year, 
                month=utc_dt.month, 
                day=utc_dt.day
            )
            for x, y, z in zip(x_values, y_values, z_values)
        ]
    else:
        return []

def load_silver_raw_waveform_data(
    tenant_id: str,
    enterprise_id: str,
    logger_instance: logging.Logger,
    input_table_name: str,
    output_table_name: str,
    data_category: str,
    start_ts: Optional[datetime],
    end_ts: datetime,
    spark_session: Optional[Any] = None,
    scale_factor: float = 32.0 / 32767.0,
    is_simulator_data: bool = False,
    conn = None
) -> None:
    """
    Load and transform raw waveform data from bronze to silver layer.
    
    This function performs the following operations:
    1. Fetch raw encrypted data from bronze layer
    2. Decode base64-encoded sensor data
    3. Expand arrays into individual x,y,z vibration values
    4. Apply scale factor conversion
    5. Add time-based columns
    6. Write to silver layer with partitioning
    
    Args:
        tenant_id: Tenant identifier
        enterprise_id: Enterprise identifier
        logger_instance: Logger instance for tracking (required)
        input_table_name: Source bronze table name (required)
        output_table_name: Target silver table name (required)
        data_category: Data category filter (required)
        start_ts: Start timestamp for filtering (optional)
        end_ts: End timestamp for filtering (required)
        spark_session: Spark session for data processing (optional)
        scale_factor: Scale factor for conversion (default: 32.0/32767.0)
        is_simulator_data: Flag to indicate if processing simulator data with classification tags (default: False)
        
    Raises:
        ImportError: If PySpark dependencies are not available
        ValueError: If required parameters are missing or invalid
        Exception: If data processing fails
    """
    if not PYSPARK_AVAILABLE:
        raise ImportError("PySpark is required for bronze to silver transformation")
    
    if not logger_instance:
        raise ValueError("logger_instance is required")
    
    try:
        logger_instance.info("🥈 Data Enrichment Started...")
        logger_instance.info("🚀 Starting Bronze to Silver raw waveform data transformation...")

        # Initialize Spark session if not provided
        if spark_session is None:
            spark_session = SparkSession.builder.appName("bronze_to_silver_raw") \
                .config("spark.rpc.message.maxSize", "512MB") \
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
                .config("spark.advise.divisionExprConvertRule.enable", "true") \
                .getOrCreate()

        # Use passed time window parameters
        logger_instance.info(f"📅 Using provided time window - start_ts: {start_ts}, end_ts: {end_ts}")

        # Convert timestamps to epochs for filtering
        start_epoch = int(start_ts.timestamp()) if start_ts else 0
        end_epoch = int(end_ts.timestamp())
        logger_instance.info(f"🕒 Using file_modified_time >= {start_epoch} AND <= {end_epoch} for querying raw data from bronze data")

        # Query raw data from bronze layer using centralized SQL query
        if is_simulator_data:
            logger_instance.info("🏷️ Using simulator data query with classification tags")
            
            # Create config table views from PostgreSQL if connection is provided
            if conn:
                logger_instance.info("🔗 Creating config table views from PostgreSQL...")
                _create_config_table_views(spark_session, conn, logger_instance)
            
            raw_data_query = BronzeToSilverQueries.get_raw_waveform_simulator_data_with_labels(
                input_table_name, start_epoch, end_epoch, data_category, tenant_id, enterprise_id
            )
            
            # # Log the generated SQL query for debugging
            # logger_instance.info("🔍 Generated SQL Query for Raw Waveform Simulator Data:")
            # logger_instance.info("=" * 80)
            # logger_instance.info(raw_data_query)
            # logger_instance.info("=" * 80)
            
        else:
            logger_instance.info("📊 Using standard raw waveform data query")
            raw_data_query = BronzeToSilverQueries.get_raw_waveform_data(
                input_table_name, start_epoch, end_epoch, data_category, tenant_id, enterprise_id
            )
            
            # # Log the generated SQL query for debugging
            # logger_instance.info("🔍 Generated SQL Query for Standard Raw Waveform Data:")
            # logger_instance.info("=" * 80)
            # logger_instance.info(raw_data_query)
            # logger_instance.info("=" * 80)
        
        raw_data_df = spark_session.sql(raw_data_query)

        # Cache the DataFrame to avoid re-executing the query multiple times
        raw_data_df.cache()
        
        # Get count once and store it
        record_count = raw_data_df.count()
        
        # Log the actual row count for debugging
        logger_instance.info(f"🔍 Query returned {record_count} rows from bronze table")
        
        if record_count > 0:  
            # Process rows with decoding and expansion
            process_row_with_logger = partial(_process_raw_row, logger=logger_instance, scale_factor=scale_factor)
            processed_rdd = raw_data_df.rdd.flatMap(process_row_with_logger)

            # Define schema for processed data
            schema = StructType([
                StructField("Input_tenantId", StringType(), True),
                StructField("Input_enterpriseId", StringType(), True),
                StructField("asset_metadata_id", LongType(), True),
                StructField("file_modified_time", LongType(), True),   
                StructField("config_accelRange_g", LongType(), True),
                StructField("config_sampleRate_Hz", DoubleType(), True),  
                StructField("sensorId", StringType(), True),
                StructField("timestamp", LongType(), True), 
                StructField("measurement_time", FloatType(), True),     
                StructField("utc_datetime", StringType(), True),
                StructField("cst_datetime", StringType(), True),
                StructField("Tag_Health", StringType(), True),
                StructField("Tag_Speed", StringType(), True),
                StructField("Tag_Config", StringType(), True),    
                StructField("Tag_ModelConsideration", StringType(), True),   
                StructField("Data_Label", StringType(), True),    
                StructField("sensor_location", StringType(), True),
                StructField("Raw_Horiz", LongType(), True),  
                StructField("Raw_Vert", LongType(), True),   
                StructField("Raw_Axial", LongType(), True),  
                StructField("Horiz_g", DoubleType(), True),  
                StructField("Vert_g", DoubleType(), True),   
                StructField("Axial_g", DoubleType(), True),  
                StructField("year", LongType(), True),       
                StructField("month", LongType(), True),      
                StructField("day", LongType(), True)        
            ])

            decoded_df = spark_session.createDataFrame(processed_rdd, schema=schema)

            logger_instance.info(f"✅ Adding time interval based on measurement duration")

            # Add time-based columns
            window_spec = Window.partitionBy("Input_tenantId", "Input_enterpriseId", "sensorId", "timestamp").orderBy("utc_datetime")
            count_col = F.count("utc_datetime").over(window_spec)
            time_interval_col = (F.col("measurement_time") / count_col) * F.expr("INTERVAL 1 SECOND")

            decoded_df = decoded_df.withColumn("micro_datetime", 
                F.when(F.row_number().over(window_spec) == 1, F.date_format(F.col("utc_datetime"), "yyyy-MM-dd HH:mm:ss.SSSSSS")).otherwise(
                    F.col("utc_datetime") + (time_interval_col * (F.row_number().over(window_spec) - 1)))).withColumn("micro_datetime", F.col("micro_datetime").cast("string"))

            increment_factor = F.col("measurement_time") / F.lit(16384.0)

            decoded_df = decoded_df.withColumn("time", F.when(F.row_number().over(window_spec) == 1, F.lit(0.000000)).otherwise(increment_factor * (F.row_number().over(window_spec) - 1))
                        )#.withColumn("time", F.format_number(F.col("time"), 6))

            # Create a new window spec for velocity calculations
            velocity_window_spec = Window.partitionBy("Input_tenantId", "Input_enterpriseId", "sensorId", "timestamp").orderBy("time")

            logger_instance.info("✅ Adding velocity calculations...")

            # Calculate velocity using trapezoidal integration approach
            # For each row, calculate the velocity increment and use cumulative sum
            decoded_df = decoded_df.withColumn(
                "vel_increment_horiz",
                F.when(F.col("time") == 0, F.lit(0.0))
                .otherwise(
                    (F.lit(0.5) * (F.col("Horiz_g") + F.lag("Horiz_g", 1, 0.0).over(velocity_window_spec)) * 
                     F.lit(386.089) * increment_factor)
                ).cast("double"))

            decoded_df = decoded_df.withColumn(
                "vel_increment_vert",
                F.when(F.col("time") == 0, F.lit(0.0))
                .otherwise(
                    (F.lit(0.5) * (F.col("Vert_g") + F.lag("Vert_g", 1, 0.0).over(velocity_window_spec)) * 
                     F.lit(386.089) * increment_factor)
                ).cast("double"))

            decoded_df = decoded_df.withColumn(
                "vel_increment_axial",
                F.when(F.col("time") == 0, F.lit(0.0))
                .otherwise(
                    (F.lit(0.5) * (F.col("Axial_g") + F.lag("Axial_g", 1, 0.0).over(velocity_window_spec)) * 
                     F.lit(386.089) * increment_factor)
                ).cast("double"))

            # Now calculate cumulative velocity using sum over ordered window
            # This will give us velocity in inches per second
            decoded_df = decoded_df.withColumn(
                "horiz_in_per_s",
                F.sum("vel_increment_horiz").over(velocity_window_spec.orderBy("time").rowsBetween(Window.unboundedPreceding, Window.currentRow)).cast("double")
            )

            decoded_df = decoded_df.withColumn(
                "vert_in_per_s",
                F.sum("vel_increment_vert").over(velocity_window_spec.orderBy("time").rowsBetween(Window.unboundedPreceding, Window.currentRow)).cast("double")
            )

            decoded_df = decoded_df.withColumn(
                "axial_in_per_s",
                F.sum("vel_increment_axial").over(velocity_window_spec.orderBy("time").rowsBetween(Window.unboundedPreceding, Window.currentRow)).cast("double")
            )

            logger_instance.info("✅ Velocity calculations completed")

            # Final column selection and renaming
            final_df = decoded_df.select(
                col("Input_tenantId").alias("tenantId"), 
                col("Input_enterpriseId").alias("enterpriseId"),
                col("asset_metadata_id").alias("assetMetadataId"), 
                col("config_sampleRate_Hz").alias("sampleRate_Hz"),
                "sensorId", 
                "timestamp", 
                col("utc_datetime").alias("utcDatetime"), 
                col("micro_datetime").alias("microDatetime"), 
                "time", 
                col("Raw_Horiz").alias("rawHoriz"), 
                col("Raw_Vert").alias("rawVert"),  
                col("Raw_Axial").alias("rawAxial"),  
                col("Horiz_g").alias("horiz_g"), 
                col("Vert_g").alias("vert_g"), 
                col("Axial_g").alias("axial_g"), 
                col("horiz_in_per_s").alias("horiz_in_per_s"),
                col("vert_in_per_s").alias("vert_in_per_s"),
                col("axial_in_per_s").alias("axial_in_per_s"),   
                col("measurement_time").alias("measurementTime"),  
                "year", "month", "day", 
                col("file_modified_time").alias("fileModifiedTime"),  
                col("config_accelRange_g").alias("configAccelRange_g"), 
                col("cst_datetime").alias("cstDatetime"),  
                col("Tag_Health").alias("tagHealth"),  
                col("Tag_Speed").alias("tagSpeed_Hz"),  
                col("Tag_Config").alias("tagConfig"),
                col("Tag_ModelConsideration").alias("tagModelConsideration"),  
                col("Data_Label").alias("dataLabel"),  
                col("sensor_location").alias("sensorLocation"))

            # Cache the final DataFrame to avoid re-executing transformations
            final_df.cache()
            
            # Get count once before writing
            final_count = final_df.count()

            # Write to silver layer
            final_df.write.format("delta").option("mergeSchema", "true").mode("append").partitionBy("tenantId", "enterpriseId", "sensorId", "year", "month", "day").saveAsTable(output_table_name)
            
            logger_instance.info(f"✅ Successfully wrote {final_count} records to {output_table_name}")

        else:
            logger_instance.warning("⚠️ No data found for the given parameters.")
            
        # Unpersist the cached DataFrames to free memory
        if record_count > 0:
            raw_data_df.unpersist()
            final_df.unpersist()
        logger_instance.info("✅ Raw waveform transformation completed")

    except Exception as e:
        logger_instance.error(f"🔥 Exception occurred during Bronze to Silver raw waveform transformation: {str(e)}", exc_info=True)
        raise


def load_silver_calculated_waveform_data(
    tenant_id: str,
    enterprise_id: str,
    logger_instance: logging.Logger,
    input_table_name: str,
    output_table_name: str,
    start_ts: Optional[datetime],
    end_ts: datetime,
    spark_session: Optional[Any] = None,
    is_simulator_data: bool = False,
    conn = None
) -> None:
    """
    Load and transform calculated waveform data from bronze to silver layer.
    
    This function performs the following operations:
    1. Fetch calculated waveform data from bronze layer
    2. Add time-based columns (utc_datetime, cst_datetime, year, month, day)
    3. Add default tag columns
    4. Rename and restructure columns
    5. Write to silver layer with partitioning
    
    Args:
        tenant_id: Tenant identifier
        enterprise_id: Enterprise identifier
        logger_instance: Logger instance for tracking (required)
        input_table_name: Source bronze table name (required)
        output_table_name: Target silver table name (required)
        start_ts: Start timestamp for filtering (optional)
        end_ts: End timestamp for filtering (required)
        spark_session: Spark session for data processing (optional)
        is_simulator_data: Flag to indicate if processing simulator data with classification tags (default: False)
        
    Raises:
        ImportError: If PySpark dependencies are not available
        ValueError: If required parameters are missing or invalid
        Exception: If data processing fails
    """
    if not PYSPARK_AVAILABLE:
        raise ImportError("PySpark is required for bronze to silver transformation")
    
    if not logger_instance:
        raise ValueError("logger_instance is required")
    
    try:
        logger_instance.info("🚀 Starting Bronze to Silver calculated waveform data transformation...")

        # Initialize Spark session if not provided
        if spark_session is None:
            spark_session = SparkSession.builder.appName("bronze_to_silver_calculated") \
                .config("spark.rpc.message.maxSize", "512MB") \
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
                .config("spark.advise.divisionExprConvertRule.enable", "true") \
                .getOrCreate()

        # Use passed time window parameters for Cosmos-style filtering
        logger_instance.info(f"📅 Using provided time window - start_ts: {start_ts}, end_ts: {end_ts}")
        
        # Convert timestamps to epochs for filtering
        start_epoch = int(start_ts.timestamp()) if start_ts else 0
        end_epoch = int(end_ts.timestamp())
        logger_instance.info(f"🕒 Using timestamp >= {start_epoch} AND <= {end_epoch} for querying calculated bronze data")
        
        logger_instance.info(f"📥 Reading {input_table_name} using centralized SQL query with time filtering...")
        
        # Query calculated data using centralized SQL query
        if is_simulator_data:
            logger_instance.info("🏷️ Using simulator data query with classification tags")
            
            # Create config table views from PostgreSQL if connection is provided
            if conn:
                logger_instance.info("🔗 Creating config table views from PostgreSQL...")
                _create_config_table_views(spark_session, conn, logger_instance)
            
            calculated_data_query = BronzeToSilverQueries.get_calculated_waveform_simulator_data_with_labels(
                input_table_name, start_epoch, end_epoch, tenant_id, enterprise_id
            )
            
            # # Log the generated SQL query for debugging
            # logger_instance.info("🔍 Generated SQL Query for Calculated Waveform Simulator Data:")
            # logger_instance.info("=" * 80)
            # logger_instance.info(calculated_data_query)
            # logger_instance.info("=" * 80)
            
        else:
            logger_instance.info("📊 Using standard calculated waveform data query")
            calculated_data_query = BronzeToSilverQueries.get_calculated_waveform_data(
                input_table_name, start_epoch, end_epoch, tenant_id, enterprise_id
            )
            
            # # Log the generated SQL query for debugging
            # logger_instance.info("🔍 Generated SQL Query for Standard Calculated Waveform Data:")
            # logger_instance.info("=" * 80)
            # logger_instance.info(calculated_data_query)
            # logger_instance.info("=" * 80)
        
        df_bronze = spark_session.sql(calculated_data_query)
        
        # Cache the DataFrame to avoid re-executing the query
        df_bronze.cache()
        
        # Get count once and store it
        bronze_count = df_bronze.count()
        
        logger_instance.info(f"🧪 Bronze table record count: {bronze_count}")

        # Transform calculated data
        if is_simulator_data:
            # For simulator data, tags come from the query - no need to set them to None
            logger_instance.info("🏷️ Using classification tags from simulator data query")
            df_transformed = (
                df_bronze
                .withColumn("utc_datetime", F.date_format(
                    F.from_unixtime(F.col("timestamp").cast("BIGINT")),
                    "yyyy-MM-dd HH:mm:ss"
                ))
                .withColumn("cst_datetime", F.date_format(
                    F.from_utc_timestamp(F.from_unixtime(F.col("timestamp").cast("BIGINT")), "America/Chicago"),
                    "yyyy-MM-dd HH:mm:ss"
                ))
                .withColumn("year", F.year(F.col("utc_datetime")))
                .withColumn("month", F.month(F.col("utc_datetime")))
                .withColumn("day", F.dayofmonth(F.col("utc_datetime")))
            )
        else:
            # For regular data, set tags to None as before
            logger_instance.info("📊 Setting default tags for regular data")
            df_transformed = (
                df_bronze
                .withColumn("utc_datetime", F.date_format(
                    F.from_unixtime(F.col("timestamp").cast("BIGINT")),
                    "yyyy-MM-dd HH:mm:ss"
                ))
                .withColumn("cst_datetime", F.date_format(
                    F.from_utc_timestamp(F.from_unixtime(F.col("timestamp").cast("BIGINT")), "America/Chicago"),
                    "yyyy-MM-dd HH:mm:ss"
                ))
                .withColumn("Tag_Health", F.lit(None).cast("string"))
                .withColumn("Tag_ModelConsideration", F.lit(None).cast("string"))
                .withColumn("Tag_Speed", F.lit(None).cast("string"))
                .withColumn("Tag_Config", F.lit(None).cast("string"))
                .withColumn("Data_Label", F.lit("Incoming"))
                .withColumn("sensor_location", F.lit(None).cast("string"))
                .withColumn("year", F.year(F.col("utc_datetime")))
                .withColumn("month", F.month(F.col("utc_datetime")))
                .withColumn("day", F.dayofmonth(F.col("utc_datetime")))
            )

        # Rename selected columns
        df_final = df_transformed.select(
            col("Input_tenantId").alias("tenantId"),
            col("Input_enterpriseId").alias("enterpriseId"),
            col("_id").cast("string").alias("unifiedMessageId"),
            col("asset_metadata_id").alias("assetMetadataId"),
            col("cloudTimestamp").alias("cloudTimestamp"),
            col("co-relationId").alias("coRelationId"),
            col("createdDate").alias("createdDate"),
            col("firmwareVer").alias("firmwareVer"),
            col("gatewayId").alias("gatewayId"),
            col("gwTime").alias("gwTime"),
            col("objectClass").alias("objectClass"),
            col("objectSubType").alias("objectSubType"),
            col("objectType").alias("objectType"),
            col("previousHealthStatus").alias("previousHealthStatus"),
            col("schemaVersion").alias("schemaVersion"),
            col("scope").alias("scope"),
            col("sensorId").alias("sensorId"),
            col("sensorType").alias("sensorType"),
            col("spanId").alias("spanId"),
            col("tags").alias("tags"),
            col("tenantId").alias("tenantId_from_json"),  # for traceability if needed
            col("timestamp").alias("timestamp"),
            col("traceId").alias("traceId"),
            col("traceParentId").alias("traceParentId"),

            # Config fields
            col("config_accelRange_g").alias("configAccelRange_g"),
            col("config_sampleRate_Hz").alias("configSampleRate_Hz"),

            # Sensor parameters
            col("sensorParameters_batteryStatus_V").alias("batteryStatus_V"),
            col("sensorParameters_batteryVoltage_V").alias("batteryVoltage_V"),
            col("sensorParameters_crestFactorAxial_g").alias("crestFactorAxial_g"),
            col("sensorParameters_crestFactorHoriz_g").alias("crestFactorHoriz_g"),
            col("sensorParameters_crestFactorVert_g").alias("crestFactorVert_g"),
            col("sensorParameters_peakAxial_g").alias("peakAxial_g"),
            col("sensorParameters_peakHoriz_g").alias("peakHoriz_g"),
            col("sensorParameters_peakToPeakAxial_g").alias("peakToPeakAxial_g"),
            col("sensorParameters_peakToPeakAxial_inps").alias("peakToPeakAxial_inps"),
            col("sensorParameters_peakToPeakHoriz_g").alias("peakToPeakHoriz_g"),
            col("sensorParameters_peakToPeakHoriz_inps").alias("peakToPeakHoriz_inps"),
            col("sensorParameters_peakToPeakVert_g").alias("peakToPeakVert_g"),
            col("sensorParameters_peakToPeakVert_inps").alias("peakToPeakVert_inps"),
            col("sensorParameters_peakVert_g").alias("peakVert_g"),
            col("sensorParameters_rmsAxial_g").alias("rmsAxial_g"),
            col("sensorParameters_rmsAxial_inps").alias("rmsAxial_inps"),
            col("sensorParameters_rmsHoriz_g").alias("rmsHoriz_g"),
            col("sensorParameters_rmsHoriz_inps").alias("rmsHoriz_inps"),
            col("sensorParameters_rmsVert_g").alias("rmsVert_g"),
            col("sensorParameters_rmsVert_inps").alias("rmsVert_inps"),
            col("sensorParameters_sensorSignalStrength_dBm").alias("signalStrength_dBm"),
            col("sensorParameters_temperature_C").alias("temperature_C"),

            # Tags & time
            col("utc_datetime").alias("utcDatetime"),
            col("cst_datetime").alias("cstDatetime"),
            col("Tag_Health").alias("tagHealth"),
            col("Tag_ModelConsideration").alias("tagModelConsideration"),
            col("Tag_Speed").alias("tagSpeed_Hz"),
            col("Tag_Config").alias("tagConfig"),
            col("Data_Label").alias("dataLabel"),
            col("sensor_location").alias("sensorLocation"),
            col("year"), col("month"), col("day")
        )

        logger_instance.info("✅ Transformation complete. Writing to Silver table...")

        # Cache the final DataFrame to avoid re-executing transformations
        df_final.cache()
        
        # Get count once before writing
        final_count = df_final.count()

        # Write to silver layer
        (
            df_final
            .write.mode("append")
            .format("delta")
            .partitionBy("tenantId", "enterpriseId", "sensorId", "year", "month", "day")
            .option("mergeSchema", "true")
            .saveAsTable(output_table_name)
        )

        logger_instance.info(f"✅ Successfully wrote {final_count} records to {output_table_name}")
        
        # Unpersist the cached DataFrames to free memory
        df_bronze.unpersist()
        df_final.unpersist()
        
        logger_instance.info("✅ Calculated waveform transformation completed")

    except Exception as e:
        logger_instance.error(f"❌ Error in load_silver_calculated_waveform_data: {str(e)}", exc_info=True)
        raise


def _create_config_table_views(spark_session: SparkSession, conn, logger_instance: logging.Logger) -> None:
    """
    Create temporary views in Spark from PostgreSQL config tables.
    
    Args:
        spark_session: Active Spark session
        conn: PostgreSQL connection
        logger_instance: Logger instance
    """
    try:
        import pandas as pd
        
        # Use psycopg2 cursor instead of pandas.read_sql
        cursor = conn.cursor()
        
        # List of config tables to create views for
        config_tables = [
            'df_config_master',
            'df_config_fault_simulator', 
            'df_config_sensor_metadata',
            'df_config_data_collection_report',
            'df_config_data_generation_timings'
        ]
        
        for table_name in config_tables:
            try:
                # Use cursor instead of pandas.read_sql
                cursor.execute(f"SELECT * FROM {table_name}")
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                
                if rows:
                    # Convert to pandas DataFrame
                    df_pg = pd.DataFrame(rows, columns=columns)
                    # Convert to Spark DataFrame and create temporary view
                    spark_df = spark_session.createDataFrame(df_pg)
                    spark_df.createOrReplaceTempView(table_name)
                    logger_instance.info(f"✅ Created view for {table_name} with {len(rows)} records")
                else:
                    logger_instance.warning(f"⚠️ No data found in {table_name}")
                    
            except Exception as e:
                logger_instance.error(f"❌ Failed to create view for {table_name}: {e}")
                # Continue with other tables
                continue
                
        logger_instance.info("✅ Config table views created successfully")
        
    except Exception as e:
        logger_instance.error(f"❌ Error creating config table views: {e}")
        raise 