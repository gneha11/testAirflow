"""
Telemetry Ingestion Module for Microsoft Fabric.

This module provides functionality to fetch telemetry data from dual sources:
1. Raw encrypted data from Azure Data Lake Storage (ADLS)
2. Calculated waveform data from Cosmos MongoDB

Supports multi-source ingestion, dynamic schema parsing, deduplication,
and metadata enrichment with asset information.
"""

import json
import logging
import pandas as pd
from functools import reduce
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
from pyspark.sql import SparkSession, DataFrame, Row
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, ArrayType
from pyspark.sql.functions import to_timestamp, col, from_json
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pymongo.errors import PyMongoError
from bson import json_util
import math

# Import centralized SQL queries
from .db_queries import TelemetryQueries


def fetch_assets(tenant_id: str, enterprise_id: str, spark: SparkSession, asset_hierarchy_table_name: str = "asset_master.assets_hierarchy") -> List[Row]:
    """
    Fetch asset metadata from Lakehouse table for given tenant and enterprise.
    
    Args:
        tenant_id: Tenant identifier
        enterprise_id: Enterprise identifier
        spark: Spark session
        asset_hierarchy_table_name: Asset hierarchy table name for metadata lookup (default: "asset_master.assets_hierarchy")
        
    Returns:
        List of Row objects containing asset metadata
        
    Raises:
        ValueError: If no assets found for the given tenant/enterprise
    """
    logger_instance = logging.getLogger(__name__)
    logger_instance.info("🔍 Fetching asset metadata from Lakehouse")
    
    # Use centralized SQL query for asset metadata
    asset_metadata_query = TelemetryQueries.get_asset_metadata(asset_hierarchy_table_name)
    df_assets = spark.sql(asset_metadata_query).filter(
        (F.lower(F.col("tenantId")) == tenant_id) & (F.lower(F.col("enterpriseId")) == enterprise_id)
    ).select("id", "serialNumber", "sensorType", "tenantId", "enterpriseId").distinct()

    if df_assets.limit(1).count() == 0:
        raise ValueError(f"❌ No asset metadata found for tenant_id={tenant_id}, enterprise_id={enterprise_id}")

    return df_assets.collect()


def fetch_telemetry_data(tenant_id: str, 
                        enterprise_id: str, 
                        data_category: str,
                        config: Dict[str, Any],
                        start_ts: Optional[datetime],
                        end_ts: datetime,
                        collection=None,
                        adls_table_name: str = None,
                        cosmos_table_name: str = None,
                        fetch_adls: bool = True,
                        fetch_cosmos: bool = True,
                        spark_session: Optional[SparkSession] = None,
                        logger_instance: Optional[logging.Logger] = None,
                        adls_batch_size: int = 10,
                        cosmos_batch_size: int = 50,
                        flatten_json_func=None,
                        save_with_schema_evolution_deduplication_func=None,
                        asset_hierarchy_table_name: str = "asset_master.assets_hierarchy",
                        # NEW: Schema tracking parameters
                        run_id: Optional[int] = None,
                        execution_detail_table_name: Optional[str] = None,
                        capture_schema_func = None,
                        load_execution_details_func = None,
                        compare_schemas_func = None,
                        postgres_conn = None) -> None:
    """
    Fetch telemetry data from ADLS and/or Cosmos MongoDB and load to Lakehouse.
    
    This function performs the following operations:
    1. Fetches asset metadata for the given tenant/enterprise
    2. Based on flags, fetches data from ADLS and/or Cosmos MongoDB
    3. Processes data in parallel batches
    4. Performs schema inference and flattening
    5. Saves to bronze Delta table with deduplication
    6. NEW: Optional schema change tracking and execution detail logging
    
    Args:
        tenant_id: Tenant identifier
        enterprise_id: Enterprise identifier
        data_category: Data category for ADLS path resolution (required)
        config: Configuration dictionary (from config_loader)
        start_ts: Start timestamp for data ingestion window
        end_ts: End timestamp for data ingestion window
        collection: MongoDB collection object (from db_connector)
        adls_table_name: Target table name for ADLS data (required if fetch_adls=True)
        cosmos_table_name: Target table name for Cosmos data (required if fetch_cosmos=True)
        fetch_adls: Whether to fetch ADLS data (default: True)
        fetch_cosmos: Whether to fetch Cosmos data (default: True)
        spark_session: Spark session (if not provided, will be created)
        logger_instance: Logger instance (must be provided from outside)
        adls_batch_size: Number of sensors to process per batch for ADLS (default: 10)
        cosmos_batch_size: Number of sensors to process per batch for Cosmos (default: 50)
        flatten_json_func: Function to flatten JSON (from json_exploder)
        save_with_schema_evolution_deduplication_func: Function to save with schema evolution (from json_exploder)
        asset_hierarchy_table_name: Asset hierarchy table name for metadata lookup (default: "asset_master.assets_hierarchy")
        # NEW: Schema tracking parameters
        run_id: Pipeline run identifier for tracking (optional)
        execution_detail_table_name: Table name for storing execution details (optional)
        capture_schema_func: Function to capture table schemas (optional)
        load_execution_details_func: Function to load execution details (optional)
        compare_schemas_func: Function to compare schemas (optional)
        postgres_conn: PostgreSQL connection for execution detail logging (optional)
        
    Raises:
        ValueError: If no assets found for the given tenant/enterprise
        ValueError: If table names are not provided when corresponding fetch flag is True
        ValueError: If partial schema tracking parameters are provided (all 5 or none required)
        Exception: If data processing or loading fails
    """
    if logger_instance is None:
        raise ValueError("logger_instance is mandatory for telemetry ingestion")
    
    # Validate table names based on fetch flags
    if fetch_adls and not adls_table_name:
        raise ValueError("adls_table_name is required when fetch_adls=True")
    if fetch_cosmos and not cosmos_table_name:
        raise ValueError("cosmos_table_name is required when fetch_cosmos=True")
    
    # NEW: Schema tracking parameter validation
    tracking_enabled = all([
        run_id is not None,
        execution_detail_table_name is not None,
        capture_schema_func is not None,
        load_execution_details_func is not None,
        compare_schemas_func is not None,
        postgres_conn is not None
    ])
    
    if not tracking_enabled:
        # Check if some parameters are provided (partial tracking)
        partial_params = [p for p in [run_id, execution_detail_table_name, capture_schema_func, load_execution_details_func, compare_schemas_func, postgres_conn] if p is not None]
        
        if partial_params:
            raise ValueError(f"Missing required parameters for tracking. All 6 must be provided for tracking.")
        else:
            logger_instance.info("⚠️ All tracking parameters missing - skipping execution detail loading")
    
    try:
        # Set Spark tuning config
        if spark_session is None:
            spark_session = SparkSession.builder.appName("telemetry_ingestion").getOrCreate()
        
        spark_session.conf.set("spark.sql.shuffle.partitions", "80")
        
        # Fetch assets
        all_assets = fetch_assets(tenant_id, enterprise_id, spark_session, asset_hierarchy_table_name)
        
        if not all_assets:
            logger_instance.warning("⚠️ No valid assets found. Skipping telemetry ingestion.")
            return

        logger_instance.info("🥉 Triggered Azure-Fabric Bridge...")

        # NEW: BEFORE schema capture (outside processing functions)
        before_adls_schema_df = None
        before_cosmos_schema_df = None
        before_adls_count = 0
        before_cosmos_count = 0
        
        if tracking_enabled:
            logger_instance.info("📊 Capturing BEFORE schemas and record counts for bronze tables...")
            
            # Capture BEFORE schema and count for ADLS table
            if fetch_adls:
                try:
                    # Use fail_if_not_exists=False for first execution scenarios
                    before_adls_schema_df = capture_schema_func(spark_session, adls_table_name, fail_if_not_exists=False)
                    if before_adls_schema_df is not None:
                        logger_instance.info(f"✅ Captured BEFORE schema for {adls_table_name}")
                        # Get BEFORE record count
                        before_adls_count = spark_session.table(adls_table_name).count()
                        logger_instance.info(f"📊 BEFORE record count for {adls_table_name}: {before_adls_count}")
                    else:
                        logger_instance.info(f"🆕 First execution detected for {adls_table_name} - no previous schema")
                        before_adls_count = 0
                except Exception as e:
                    error_msg = f"❌ Failed to capture BEFORE schema for {adls_table_name}: {e}"
                    logger_instance.error(error_msg)
                    raise Exception(error_msg)
            
            # Capture BEFORE schema and count for Cosmos table
            if fetch_cosmos:
                try:
                    # Use fail_if_not_exists=False for first execution scenarios
                    before_cosmos_schema_df = capture_schema_func(spark_session, cosmos_table_name, fail_if_not_exists=False)
                    if before_cosmos_schema_df is not None:
                        logger_instance.info(f"✅ Captured BEFORE schema for {cosmos_table_name}")
                        # Get BEFORE record count
                        before_cosmos_count = spark_session.table(cosmos_table_name).count()
                        logger_instance.info(f"📊 BEFORE record count for {cosmos_table_name}: {before_cosmos_count}")
                    else:
                        logger_instance.info(f"🆕 First execution detected for {cosmos_table_name} - no previous schema")
                        before_cosmos_count = 0
                except Exception as e:
                    error_msg = f"❌ Failed to capture AFTER schema for {cosmos_table_name}: {e}"
                    logger_instance.error(error_msg)
                    raise Exception(error_msg)

        # Process ADLS data if requested (NO schema tracking inside)
        if fetch_adls:
            logger_instance.info("🚀 Starting ADLS data ingestion...")
            _process_adls_data(config, all_assets, data_category, start_ts, end_ts, 
                             spark_session, logger_instance, adls_table_name, adls_batch_size,
                             flatten_json_func, save_with_schema_evolution_deduplication_func)
            logger_instance.info("✅ Raw data ingestion completed.")
        
        # Process Cosmos data if requested (NO schema tracking inside)
        if fetch_cosmos:
            logger_instance.info("🚀 Starting Cosmos data ingestion...")
            _process_cosmos_data(all_assets, start_ts, end_ts, 
                               spark_session, logger_instance, cosmos_table_name, cosmos_batch_size,
                               collection, flatten_json_func, save_with_schema_evolution_deduplication_func)
            logger_instance.info("✅ Calculated data ingestion completed.")

        # NEW: AFTER schema capture and comparison (outside processing functions)
        if tracking_enabled:
            logger_instance.info("📊 Capturing AFTER schemas and comparing changes...")
            
            # Capture AFTER schema for ADLS table and compare
            if fetch_adls:
                try:
                    after_adls_schema_df = capture_schema_func(spark_session, adls_table_name, fail_if_not_exists=False)
                    
                    # Compare schemas and get changes
                    adls_schema_changes = compare_schemas_func(before_adls_schema_df, after_adls_schema_df)
                    
                    # Get AFTER record count and calculate difference
                    after_adls_count = spark_session.table(adls_table_name).count()
                    adls_records_loaded = after_adls_count - before_adls_count
                    
                    # Load execution details for ADLS
                    load_execution_details_func(
                        run_id, 
                        adls_table_name, 
                        f"Records loaded during this execution: {adls_records_loaded} (Before: {before_adls_count}, After: {after_adls_count}), Source: ADLS",
                        adls_schema_changes, 
                        postgres_conn,
                        execution_detail_table_name
                    )
                    logger_instance.info(f"✅ Logged ADLS execution details: {adls_schema_changes}, Records loaded: {adls_records_loaded}")
                except Exception as e:
                    error_msg = f"❌ Failed to capture AFTER schema for {adls_table_name}: {e}"
                    logger_instance.error(error_msg)
                    raise Exception(error_msg)
            
            # Capture AFTER schema for Cosmos table and compare
            if fetch_cosmos:
                try:
                    after_cosmos_schema_df = capture_schema_func(spark_session, cosmos_table_name, fail_if_not_exists=False)
                    
                    # Compare schemas and get changes
                    cosmos_schema_changes = compare_schemas_func(before_cosmos_schema_df, after_cosmos_schema_df)
                    
                    # Get AFTER record count and calculate difference
                    after_cosmos_count = spark_session.table(cosmos_table_name).count()
                    cosmos_records_loaded = after_cosmos_count - before_cosmos_count
                    
                    # Load execution details for Cosmos
                    load_execution_details_func(
                        run_id, 
                        cosmos_table_name, 
                        f"Records loaded during this execution: {cosmos_records_loaded} (Before: {before_cosmos_count}, After: {after_cosmos_count}), Source: COSMOS",
                        cosmos_schema_changes, 
                        postgres_conn,
                        execution_detail_table_name
                    )
                    logger_instance.info(f"✅ Logged Cosmos execution details: {cosmos_schema_changes}, Records loaded: {cosmos_records_loaded}")
                except Exception as e:
                    error_msg = f"❌ Failed to capture AFTER schema for {cosmos_table_name}: {e}"
                    logger_instance.error(error_msg)
                    raise Exception(error_msg)

        logger_instance.info("✅ Data has been successfully loaded from Azure to Fabric lakehouse")
    
    except Exception as e:
        logger_instance.error(f"❌ Telemetry data ingestion failed.")
        raise


def _process_adls_data(config: Dict[str, Any], assets: List[Row], data_category: str,
                      start_ts: Optional[datetime], end_ts: datetime, 
                      spark: SparkSession, logger_instance: logging.Logger,
                      table_name: str, batch_size: int = 10,
                      flatten_json_func=None,
                      save_with_schema_evolution_deduplication_func=None) -> None:
    """
    Process ADLS telemetry data for multiple assets in batches.
    
    Args:
        config: Configuration dictionary containing ADLS settings
        assets: List of asset metadata rows to process
        data_category: Data category for path resolution
        start_ts: Start timestamp for data ingestion window
        end_ts: End timestamp for data ingestion window
        spark: Spark session for data processing
        logger_instance: Logger instance for tracking progress
        table_name: Target table name for saving data
        batch_size: Number of assets to process per batch
        flatten_json_func: Function to flatten JSON data
        save_with_schema_evolution_deduplication_func: Function to save data with deduplication
    """
    end_epoch = int(end_ts.timestamp())
    is_first_run = start_ts is None
    if not is_first_run:
        start_epoch = int(start_ts.timestamp())

    def collect_files_recursive(path, json_files):
        try:
            # Import mssparkutils for Fabric environment
            try:
                from notebookutils import mssparkutils
            except ImportError:
                # For local development/testing, create a mock
                class MockMssparkutils:
                    class fs:
                        @staticmethod
                        def ls(path):
                            return []
                mssparkutils = MockMssparkutils()
            
            entries = mssparkutils.fs.ls(path)
            for e in entries:
                if e.isDir:
                    collect_files_recursive(e.path, json_files)
                elif e.name.endswith(".json"):
                    mod_time = e.modifyTime // 1000
                    if is_first_run and mod_time <= end_epoch:
                        json_files.append((e.path, mod_time))
                    elif not is_first_run and start_epoch < mod_time <= end_epoch:
                        json_files.append((e.path, mod_time))
        except Exception as ex:
            if "not found" in str(ex).lower():
                logger_instance.warning(f"⚠️ Folder not found: {path}")
            elif "specified path does not exist" in str(ex).lower():
                logger_instance.warning(f"⚠️ Path does not exist: {path}")
            elif "permission denied" in str(ex).lower():
                logger_instance.warning(f"⚠️ Permission denied: {path}")
            else:
                logger_instance.warning(f"⚠️ Error accessing path: {path}: {ex}")

    def process_asset(asset):
        sensor_type = asset["sensorType"]
        sensor_id = asset["serialNumber"]
        tenantId = asset["tenantId"]
        enterpriseId = asset["enterpriseId"]
        id = asset["id"]

        adls_conf = config["adls"]["sensorType_mappings"].get(sensor_type)
        if not adls_conf:
            logger_instance.warning(f"❌ sensorType '{sensor_type}' not in config.")
            return None

        path_template = adls_conf["path_template"]
        container = adls_conf["container"]
        account = config["adls"]["ACCOUNT_NAME"]
        base_url = f"abfss://{container}@{account}.dfs.core.windows.net/"

        base_folder_path = path_template.split("/{year}")[0].format(sensor_id=sensor_id, category=data_category)
        full_base_path = f"{base_url}{base_folder_path}"
        
        json_files = []
        logger_instance.info(f"🔍 Starting recursive scan for sensor_id={sensor_id}")
        collect_files_recursive(full_base_path, json_files)

        if not json_files:
            logger_instance.info(f"⚠️ No JSON files found for sensor_id={sensor_id}")
            return None

        try:
            logger_instance.info(f"🚀 Reading {len(json_files)} files in batch for sensor_id={sensor_id}")
                
            # Extract just the file paths for batch reading
            file_paths = [file_path for file_path, _ in json_files]
            
            # Read all files in a single operation - use multiple paths for precision
            df = spark.read.text(file_paths)
            
            # Add metadata columns efficiently
            df = df.withColumn("Input_tenantId", F.lit(tenantId)) \
                    .withColumn("Input_enterpriseId", F.lit(enterpriseId)) \
                    .withColumn("asset_metadata_id", F.lit(id))
            
            # Add file modification time information using input_file_name() for mapping
            from pyspark.sql.functions import input_file_name, when, udf
            from pyspark.sql.types import LongType
            
            # # Debug logging: Print file paths to verify format (moved outside loop)
            # logger_instance.info(f"🔍 Debug: Collected file paths for sensor_id={sensor_id}:")
            # for file_path, mod_time in json_files:
            #     logger_instance.info(f"   - {file_path} (mod_time: {mod_time})")
            
            # Create a mapping dictionary for file paths to modification times
            file_mod_time_map = {file_path: mod_time for file_path, mod_time in json_files}
            
            # Create a UDF to map file paths to modification times
            def map_file_mod_time(file_path):
                return file_mod_time_map.get(file_path, 0)  # Default to 0 if not found
            
            # Register the UDF
            map_file_mod_time_udf = udf(map_file_mod_time, LongType())
            
            # Apply the file modification time mapping using the UDF
            df = df.withColumn("file_modified_time", map_file_mod_time_udf(input_file_name()))
            return df
        except Exception as e:
            logger_instance.warning(f"⚠️ Failed to read files for sensor_id={sensor_id}: {e}")
            return None

    total_assets = len(assets)
    num_batches = math.ceil(total_assets / batch_size)
    
    for batch_idx in range(num_batches):
        batch_assets = assets[batch_idx * batch_size : (batch_idx + 1) * batch_size]
        logger_instance.info(f"🚀 Batch {batch_idx+1}/{num_batches} | Assets: {len(batch_assets)}")

        dfs = []
        with ThreadPoolExecutor(max_workers=min(10, len(batch_assets))) as executor:
            futures = [executor.submit(process_asset, asset) for asset in batch_assets]
            for future in as_completed(futures):
                try:
                    df = future.result()
                    if df is not None:
                        dfs.append(df)
                except Exception as e:
                    logger_instance.error(f"❌ Thread failure: {e}", exc_info=True)

        if not dfs:
            logger_instance.warning(f"⚠️ Batch {batch_idx+1} skipped due to no data.")
            continue

        try:
            final_df = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), dfs).repartition(4).cache()

            # Infer schema from full data
            try:
                json_schema = spark.read.json(final_df.rdd.map(lambda r: r["value"])).schema
                logger_instance.info(f"✅ Inferred full schema with {len(json_schema)} fields")
            except Exception as e:
                logger_instance.error(f"❌ Schema inference failed: {str(e)}")
                continue

            # Step 3: Parse using schema
            df_parsed = final_df.withColumn("parsed", from_json(col("value"), json_schema))
            df_clean = df_parsed.filter(col("parsed").isNotNull())

            # Step 4: Combine parsed struct + original metadata
            columns_to_keep = [c for c in final_df.columns if c not in ("value", "_corrupt_record")]
            df_struct = df_clean.select("parsed.*", *columns_to_keep)

            if df_clean.count() == 0:
                logger_instance.warning(f"⚠️ All rows failed JSON parsing.")
                continue

            # Step 4: Flatten
            if flatten_json_func:
                df_flat = flatten_json_func(df_struct, logger=logger_instance)
            else:
                logger_instance.warning("⚠️ flatten_json_func not provided, skipping flattening")
                df_flat = df_struct

            # Step 5: Write to Lakehouse with evolution + dedup
            if save_with_schema_evolution_deduplication_func:
                try:
                    save_with_schema_evolution_deduplication_func(
                        df_flat,
                        table_name=table_name,
                        partition_cols=["Input_tenantId", "Input_enterpriseId"],
                        dedup_cols=["scope", "timestamp"],
                        logger=logger_instance
                    )
                except Exception as e:
                    logger_instance.error("💥 Pipeline failed while loading to table.")
                    raise
            else:
                logger_instance.warning("⚠️ save_with_schema_evolution_deduplication_func not provided, skipping save")
                
            logger_instance.info(f"✅ Batch {batch_idx+1} written successfully.")

        except Exception as e:
            logger_instance.error("❌ Failed to write batch {batch_idx+1}")
            raise 


def _process_cosmos_data(assets: List[Row], start_ts: Optional[datetime], 
                        end_ts: datetime, spark: SparkSession, logger_instance: logging.Logger, 
                        table_name: str, batch_size: int = 50,
                        collection=None,
                        flatten_json_func=None, 
                        save_with_schema_evolution_deduplication_func=None) -> None:
    """
    Internal function to process Cosmos MongoDB data.
    
    Uses the provided MongoDB collection to fetch and process data,
    enriching it with asset metadata and saving to Delta tables.
    """
    try:
        sensor_ids = list(set([row["serialNumber"] for row in assets]))
        logger_instance.info(f"🔄 Fetching Cosmos DB records for {len(sensor_ids)} sensors in batches of {batch_size}")

        if collection is None:
            logger_instance.error("❌ MongoDB collection is required for Cosmos data processing")
            return

        logger_instance.info("✅ Using provided MongoDB collection")

        # Time window
        start_epoch = int(start_ts.timestamp()) if start_ts else 0
        end_epoch = int(end_ts.timestamp())

        sensor_metadata_map = {row["serialNumber"]: row for row in assets}
        enriched_json_strings = []

        # Batch query loop
        for i in range(0, len(sensor_ids), batch_size):
            batch_sensor_ids = sensor_ids[i:i+batch_size]
            query = {
                "sensorId": {"$in": batch_sensor_ids},
                "timestamp": {"$gte": start_epoch, "$lte": end_epoch}
            }
            logger_instance.info(f"🔍 Executing Cosmos query for sensors: {batch_sensor_ids}")
            docs = list(collection.find(query))

            if not docs:
                logger_instance.warning(f"⚠️ No records found in batch {i // batch_size + 1}")
                continue

            for doc in docs:
                try:
                    # Ensure _id is present and convert to string
                    _id = doc.get("_id")
                    if _id is None:
                        logger_instance.warning("⚠️ Skipping document without _id")
                        continue
                    doc["_id"] = str(_id)

                    # Normalize optional fields
                    if "tags" not in doc or not isinstance(doc["tags"], list):
                        doc["tags"] = []
                    if "sensorParameters" in doc and not isinstance(doc["sensorParameters"], dict):
                        doc["sensorParameters"] = {}
                    if "config" in doc and not isinstance(doc["config"], dict):
                        doc["config"] = {}

                    # Enrich with asset metadata
                    sensor_id = doc.get("sensorId")
                    meta = sensor_metadata_map.get(sensor_id)
                    if meta:
                        doc["Input_tenantId"] = meta["tenantId"]
                        doc["Input_enterpriseId"] = meta["enterpriseId"]
                        doc["asset_metadata_id"] = meta["id"]
                    else:
                        logger_instance.warning(f"⚠️ Metadata not found for sensor ID: {sensor_id}")

                    # Convert to JSON string using bson-safe serializer
                    enriched_json_strings.append(json_util.dumps(doc))

                except Exception as e:
                    logger_instance.error(f"❌ Skipping invalid document due to error: {e}")

        if not enriched_json_strings:
            logger_instance.warning("⚠️ No documents collected after batching.")
            return

        # Log sample enriched JSONs
        sample_count = min(3, len(enriched_json_strings))
        logger_instance.info(f"📦 Sample enriched Cosmos docs (before DataFrame):")
        for i in range(sample_count):
            logger_instance.info(enriched_json_strings[i])

        # Create RDD of raw JSON strings
        json_rdd = spark.sparkContext.parallelize(enriched_json_strings)

        # Step 1: Infer schema from all JSON rows
        inferred_df = spark.read.json(json_rdd)
        inferred_schema = inferred_df.schema
        logger_instance.info("📘 Schema inferred from Cosmos JSON")

        # Step 2: Re-parse using from_json + inferred schema
        df_value = spark.createDataFrame(json_rdd.map(lambda x: Row(value=x)))
        df_parsed = df_value.withColumn("parsed", from_json(F.col("value"), inferred_schema))

        # Step 3: Flatten parsed struct
        df_struct = df_parsed.select("parsed.*")
        
        if flatten_json_func:
            df_flat = flatten_json_func(df_struct, logger=logger_instance)
        else:
            logger_instance.warning("⚠️ flatten_json_func not provided, skipping flattening")
            df_flat = df_struct

        logger_instance.info(f"✅ Flattened Cosmos columns: {', '.join(df_flat.columns)}")
        if df_flat.count() > 0:
            if save_with_schema_evolution_deduplication_func:
                save_with_schema_evolution_deduplication_func(
                    df_flat,
                    table_name=table_name,
                    partition_cols=["Input_tenantId", "Input_enterpriseId"],
                    dedup_cols=["scope", "timestamp"],
                    logger=logger_instance
                )
                logger_instance.info("✅ Cosmos DB data saved to Lakehouse")
            else:
                logger_instance.warning("⚠️ save_with_schema_evolution_deduplication_func not provided, skipping save")
        else:
            logger_instance.warning("⚠️ No data to write after flattening.")

    except Exception as e:
        logger_instance.error(f"❌ Error in batched fetch_cosmos_data: {str(e)}")
        raise  # Re-raise the exception to abort the pipeline 