# Data Foundation

Data Foundation utilities for Microsoft Fabric - JSON flattening, logging, and Lakehouse integration.

## Project Structure

```
data_foundation/
├── data_foundation/          # Source code directory
│   ├── __init__.py          # Package initialization
│   ├── logger.py            # Structured logging utilities
│   ├── json_exploder.py     # JSON flattening utilities
│   └── asset_hierarchy.py   # Asset hierarchy processing
├── tests/                   # Unit tests
├── notebooks/               # Jupyter notebooks
├── docs/                    # Documentation
├── data/                    # Data files
├── models/                  # Model files
├── config.yaml              # Configuration
├── pyproject.toml          # Project metadata and dependencies
└── README.md               # This file
```

## Usage

### Basic Usage

```python
from data_foundation import logger, json_exploder, fetch_enterprise_assets

# Setup logger
logger_instance = logger.get_logger(
    tenant_id="tenant_123",
    enterprise_id="enterprise_456",
    log_session_id="20231201_143022",
    log_to_file=True
)

# Flatten JSON data
flattened_df = json_exploder.flatten_json(input_df, logger_instance)

# Save with schema evolution
json_exploder.save_with_schema_evolution(
    df=flattened_df,
    table_name="my_schema.flattened_data",
    partition_cols=["tenant_id", "date"],
    logger=logger_instance
)

# Process asset hierarchy
fetch_enterprise_assets(
    tenant_id="tenant_123",
    enterprise_id="enterprise_456",
    table_name="asset_master.assets_heirarchy"
)
```

### Future Shared Utilities Integration

The code is designed to work seamlessly when `logger` and `json_exploder` modules are moved to a separate `shared_utilities` repository. The functions will automatically detect and use the shared utilities when available:

```python
# Current usage (local modules)
from data_foundation import fetch_enterprise_assets

# Future usage (shared utilities)
import sharedutils.logger
from data_foundation import fetch_enterprise_assets

# Both will work the same way!
fetch_enterprise_assets(
    tenant_id="tenant_123",
    enterprise_id="enterprise_456"
)
```

The `fetch_enterprise_assets` function automatically:
- Tries to import from `sharedutils.logger` first
- Falls back to local `data_foundation.logger` if shared utilities aren't available
- Maintains the same functionality regardless of import source

## Installation

```bash
# Install dependencies
uv sync

# Run tests
uv run pytest

# Build package
uv run build
```

## Development

```bash
# Install in development mode
uv run pip install -e .

# Run linting
uv run ruff check .

# Run type checking
uv run mypy data_foundation/
``` 